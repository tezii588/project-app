// jobController.js (Final Clean Version)
import pool from '../config/database.js';

import nodemailer from 'nodemailer';




// GET /api/applications
export const getAllApplications= async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT a.id, a.status, a.cover_letter, a.resume_url, a.ai_score, a.applied_at,
             u.name as applicant_name, j.title as job_title
      FROM applications a
      JOIN users u ON a.user_id = u.id
      JOIN jobs j ON a.job_id = j.id
      ORDER BY a.applied_at DESC;
    `);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch applications" });
  }
};


// PUT /api/applications/:id/status
// export const updateJobStatus= async (req, res) => {
//   const { id } = req.params;
//   const { status } = req.body; // expected values: "accepted" or "rejected"

//   if (!["accepted", "rejected"].includes(status)) {
//     return res.status(400).json({ error: "Invalid status" });
//   }

//   try {
//     await pool.query(
//       `UPDATE applications SET status = $1, updated_at = NOW() WHERE id = $2`,
//       [status, id]
//     );
//     res.json({ message: `Application ${id} ${status}` });
//   } catch (error) {
//     res.status(500).json({ error: "Failed to update application status" });
//   }
// };




export const updateJobStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!["accepted", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  try {
    // Step 1: Update status
    await pool.query(
      `UPDATE applications SET status = $1, updated_at = NOW() WHERE id = $2`,
      [status, id]
    );

    // Step 2: Get user's email and job title
    const result = await pool.query(`
      SELECT u.email, u.name, j.title
      FROM applications a
      JOIN users u ON a.user_id = u.id
      JOIN jobs j ON a.job_id = j.id
      WHERE a.id = $1
    `, [id]);

    const { email, name, title } = result.rows[0];

    // Step 3: Send email
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user:  process.env.EMAIL_USER,
        pass:   process.env.EMAIL_PASS 
      }
    });

    const mailOptions = {
      from: '"HR Team" <yourcompanyemail@gmail.com>',
      to: email,
      subject: `Your application for ${title} has been ${status}`,
      html: `
        <p>Hi ${name},</p>
        <p>Your application for <strong>${title}</strong> has been <strong>${status.toUpperCase()}</strong>.</p>
        <p>Thank you for applying!</p>
        <br/>
        <p>Regards,</p>
        <p>HR Team</p>
      `
    };

    await transporter.sendMail(mailOptions);

    res.json({ message: `Application ${id} updated to ${status}, email sent.` });

  } catch (error) {
    console.error("Update error:", error.message);
    res.status(500).json({ error: "Failed to update status and send email" });
  }
};
