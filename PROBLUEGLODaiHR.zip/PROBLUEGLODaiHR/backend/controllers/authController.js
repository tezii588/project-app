// // // // // // // backend/controllers/authController.js
// // // // // // import bcrypt from 'bcryptjs';
// // // // // // import jwt from 'jsonwebtoken';
// // // // // // import pool from '../db.js';

// // // // // // const JWT_SECRET = process.env.JWT_SECRET;

// // // // // // // Register Candidate
// // // // // // export const registerUser = async (req, res) => {
// // // // // //   const { email, password } = req.body;

// // // // // //   try {
// // // // // //     const exists = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // // // // //     if (exists.rows.length > 0) {
// // // // // //       return res.status(400).json({ message: 'Email already exists' });
// // // // // //     }

// // // // // //     const hashedPassword = await bcrypt.hash(password, 10);
// // // // // //     await pool.query('INSERT INTO candidates (email, password) VALUES ($1, $2)', [email, hashedPassword]);

// // // // // //     return res.status(201).json({ message: 'User registered successfully' });
// // // // // //   } catch (err) {
// // // // // //     return res.status(500).json({ message: 'Server error', error: err.message });
// // // // // //   }
// // // // // // };

// // // // // // // Login Candidate or Recruiter
// // // // // // export const loginUser = async (req, res) => {
// // // // // //   const { email, password } = req.body;

// // // // // //   try {
// // // // // //     // Static recruiter login
// // // // // //     if (email === 'recruiter@visys.com' && password === '1234') {
// // // // // //       const token = jwt.sign({ email, role: 'recruiter' }, JWT_SECRET, { expiresIn: '1h' });
// // // // // //       return res.json({ token, role: 'recruiter' });
// // // // // //     }

// // // // // //     // Candidate login
// // // // // //     const user = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // // // // //     if (user.rows.length === 0) return res.status(404).json({ message: 'User not found' });

// // // // // //     const isMatch = await bcrypt.compare(password, user.rows[0].password);
// // // // // //     if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

// // // // // //     const token = jwt.sign({ email, role: 'candidate' }, JWT_SECRET, { expiresIn: '1h' });
// // // // // //     return res.json({ token, role: 'candidate' });

// // // // // //   } catch (err) {
// // // // // //     return res.status(500).json({ message: 'Server error', error: err.message });
// // // // // //   }
// // // // // // };

// // // // // // controllers/authController.js
// // // // // const pool = require('../db');
// // // // // const bcrypt = require('bcryptjs');
// // // // // const jwt = require('jsonwebtoken');


// // // // // // Candidate: Sign Up
// // // // // export const registerCandidate = async (req, res) => {
// // // // //   const { email, password } = req.body;

// // // // //   try {
// // // // //     const check = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // // // //     if (check.rows.length > 0) {
// // // // //       return res.status(400).json({ message: 'Candidate already exists' });
// // // // //     }

// // // // //     const hashed = await bcrypt.hash(password, 10);
// // // // //     await pool.query('INSERT INTO candidates (email, password) VALUES ($1, $2)', [email, hashed]);

// // // // //     res.status(201).json({ message: 'Candidate registered successfully' });
// // // // //   } catch (err) {
// // // // //     res.status(500).json({ error: 'Registration failed' });
// // // // //   }
// // // // // };

// // // // // // Candidate: Sign In
// // // // // export const loginCandidate = async (req, res) => {
// // // // //   const { email, password } = req.body;

// // // // //   try {
// // // // //     const result = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // // // //     if (result.rows.length === 0) {
// // // // //       return res.status(404).json({ message: 'Candidate not found' });
// // // // //     }

// // // // //     const user = result.rows[0];
// // // // //     const valid = await bcrypt.compare(password, user.password);
// // // // //     if (!valid) return res.status(401).json({ message: 'Invalid password' });

// // // // //     const token = jwt.sign({ id: user.id, role: 'candidate' }, process.env.JWT_SECRET, { expiresIn: '1d' });
// // // // //     res.json({ token, user: { id: user.id, email: user.email } });
// // // // //   } catch (err) {
// // // // //     res.status(500).json({ error: 'Login failed' });
// // // // //   }
// // // // // };

// // // // // // Recruiter: Login Only
// // // // // export const loginRecruiter = async (req, res) => {
// // // // //   const { email, password } = req.body;

// // // // //   try {
// // // // //     const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
// // // // //     if (result.rows.length === 0) {
// // // // //       return res.status(404).json({ message: 'Recruiter not found' });
// // // // //     }

// // // // //     const recruiter = result.rows[0];
// // // // //     const valid = await bcrypt.compare(password, recruiter.password);
// // // // //     if (!valid) return res.status(401).json({ message: 'Invalid recruiter password' });

// // // // //     const token = jwt.sign({ id: recruiter.id, role: 'recruiter' }, process.env.JWT_SECRET, { expiresIn: '1d' });
// // // // //     res.json({ token, user: { id: recruiter.id, email: recruiter.email } });
// // // // //   } catch (err) {
// // // // //     res.status(500).json({ error: 'Recruiter login failed' });
// // // // //   }
// // // // // };
// // // // // controllers/authController.js
// // // // const pool = require('../db');
// // // // const bcrypt = require('bcryptjs');
// // // // const jwt = require('jsonwebtoken');

// // // // const registerCandidate = async (req, res) => {
// // // //   const { email, password } = req.body;
// // // //   try {
// // // //     const check = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // // //     if (check.rows.length > 0) {
// // // //       return res.status(400).json({ message: 'Candidate already exists' });
// // // //     }

// // // //     const hashed = await bcrypt.hash(password, 10);
// // // //     await pool.query('INSERT INTO candidates (email, password) VALUES ($1, $2)', [email, hashed]);
// // // //     res.status(201).json({ message: 'Candidate registered successfully' });
// // // //   } catch (err) {
// // // //     res.status(500).json({ error: 'Registration failed' });
// // // //   }
// // // // };

// // // // const loginCandidate = async (req, res) => {
// // // //   const { email, password } = req.body;
// // // //   try {
// // // //     const result = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // // //     if (result.rows.length === 0) {
// // // //       return res.status(404).json({ message: 'Candidate not found' });
// // // //     }

// // // //     const candidate = result.rows[0];
// // // //     const valid = await bcrypt.compare(password, candidate.password);
// // // //     if (!valid) return res.status(401).json({ message: 'Invalid password' });

// // // //     const token = jwt.sign({ id: candidate.id, role: 'candidate' }, process.env.JWT_SECRET, { expiresIn: '1d' });
// // // //     res.json({ token, user: { id: candidate.id, email: candidate.email } });
// // // //   } catch (err) {
// // // //     res.status(500).json({ error: 'Login failed' });
// // // //   }
// // // // };

// // // // const loginRecruiter = async (req, res) => {
// // // //   const { email, password } = req.body;
// // // //   try {
// // // //     const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
// // // //     if (result.rows.length === 0) {
// // // //       return res.status(404).json({ message: 'Recruiter not found' });
// // // //     }

// // // //     const recruiter = result.rows[0];
// // // //     const valid = await bcrypt.compare(password, recruiter.password);
// // // //     if (!valid) return res.status(401).json({ message: 'Invalid recruiter password' });

// // // //     const token = jwt.sign({ id: recruiter.id, role: 'recruiter' }, process.env.JWT_SECRET, { expiresIn: '1d' });
// // // //     res.json({ token, user: { id: recruiter.id, email: recruiter.email } });
// // // //   } catch (err) {
// // // //     res.status(500).json({ error: 'Recruiter login failed' });
// // // //   }
// // // // };

// // // // module.exports = {
// // // //   registerCandidate,
// // // //   loginCandidate,
// // // //   loginRecruiter
// // // // };

// // // import pool from '../db.js';
// // // import bcrypt from 'bcryptjs';
// // // import jwt from 'jsonwebtoken';

// // // export const registerCandidate = async (req, res) => {
// // //   const { email, password } = req.body;

// // //   try {
// // //     const existing = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // //     if (existing.rows.length > 0) return res.status(400).json({ message: 'Candidate already exists' });

// // //     const hashedPassword = await bcrypt.hash(password, 10);
// // //     await pool.query('INSERT INTO candidates (email, password) VALUES ($1, $2)', [email, hashedPassword]);

// // //     const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1h' });
// // //     res.status(201).json({ token });
// // //   } catch (err) {
// // //     res.status(500).json({ message: 'Register failed' });
// // //   }
// // // };

// // // export const loginCandidate = async (req, res) => {
// // //   const { email, password } = req.body;

// // //   try {
// // //     // Recruiter shortcut
// // //     if (email === 'recruiter@visys.com' && password === 'pass1234') {
// // //       const token = jwt.sign({ email, role: 'recruiter' }, process.env.JWT_SECRET, { expiresIn: '1h' });
// // //       return res.status(200).json({ token });
// // //     }

// // //     const result = await pool.query('SELECT * FROM candidates WHERE email = $1', [email]);
// // //     if (result.rows.length === 0) return res.status(404).json({ message: 'Candidate not found' });

// // //     const user = result.rows[0];
// // //     const isMatch = await bcrypt.compare(password, user.password);
// // //     if (!isMatch) return res.status(401).json({ message: 'Invalid password' });

// // //     const token = jwt.sign({ email, role: 'candidate' }, process.env.JWT_SECRET, { expiresIn: '1h' });
// // //     res.status(200).json({ token });
// // //   } catch (err) {
// // //     res.status(500).json({ message: 'Login failed' });
// // //   }
// // // };
// // // import pool from '../db.js';
// // // import bcrypt from 'bcryptjs';
// // // import jwt from 'jsonwebtoken';

// // const db = require('../db');
// // const bcrypt = require('bcrypt');

// // const signup = async (req, res) => {
// //   const { email, password, role } = req.body;
// //   if (role !== 'candidate') {
// //     return res.status(400).json({ message: 'Only candidates can sign up' });
// //   }

// //   try {
// //     const hashed = await bcrypt.hash(password, 10);
// //     await db.query('INSERT INTO candidates (email, password) VALUES ($1, $2)', [email, hashed]);
// //     res.json({ message: 'Candidate registered successfully' });
// //   } catch (err) {
// //     res.status(500).json({ message: 'Error during signup', error: err.message });
// //   }
// // };

// // const login = async (req, res) => {
// //   const { email, password, role } = req.body;

// //   try {
// //     if (role === 'recruiter') {
// //       if (
// //         email === process.env.RECRUITER_EMAIL &&
// //         password === process.env.RECRUITER_PASSWORD
// //       ) {
// //         return res.json({ message: 'Recruiter login successful' });
// //       } else {
// //         return res.status(401).json({ message: 'Invalid recruiter credentials' });
// //       }
// //     }

// //     // Candidate login
// //     const result = await db.query('SELECT * FROM candidates WHERE email = $1', [email]);
// //     const user = result.rows[0];
// //     if (!user) return res.status(404).json({ message: 'User not found' });

// //     const match = await bcrypt.compare(password, user.password);
// //     if (!match) return res.status(401).json({ message: 'Incorrect password' });

// //     res.json({ message: 'Candidate login successful' });

// //   } catch (err) {
// //     res.status(500).json({ message: 'Login error', error: err.message });
// //   }
// // };

// // module.exports = { signup, login };
// // authController.js
// import db from './db.js';

// export async function signup(req, res) {
//   try {
//     const { email, password, role } = req.body;

//     if (!email || !password || !role) {
//       return res.status(400).json({ message: "Missing required fields" });
//     }

//     // Optional: hash password here before storing

//     const query = `
//       INSERT INTO users (email, password, role)
//       VALUES ($1, $2, $3)
//       RETURNING id, email, role
//     `;

//     const values = [email, password, role];

//     const result = await db.query(query, values);

//     res.status(201).json({
//       message: "Signup successful",
//       user: result.rows[0],
//     });
//   } catch (error) {
//     console.error("Signup error:", error);
//     res.status(500).json({
//       message: "Error during signup",
//       error: error.message,
//     });
//   }
// }
