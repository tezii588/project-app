// jobController.js (Final Clean Version)
import pool from '../config/database.js';
import nodemailer from 'nodemailer';

// Create Job
// export const createJob = async (req, res) => {
//   const job = req.body;

//   try {
//     const result = await pool.query(
//       `INSERT INTO jobs (title, description, skills, experience, location, type, salary, department, requirements)
//        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
//       [
//         job.title,
//         job.description,
//         job.skills,
//         job.experience,
//         job.location,
//         job.type,
//         job.salary,
//         job.department,
//         job.requirements
//       ]
//     );

//     res.status(201).json(result.rows[0]);
//   } catch (err) {
//     console.error('Create Job Error:', err);
//     res.status(500).json({ error: 'Failed to create job' });
//   }
// };

// Get All Jobs
export const getAllJobs = async (req, res) => {
  console.log("triggered")
  try {
    const result = await pool.query('SELECT * FROM jobs ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Post Job
export const postJob = async (req, res) => {
  console.log("triggered");

  const {
    title,
    company,
    location,
    type = 'full-time',
    salary_min,
    salary_max,
    description,
    requirements = [],
    benefits = [],
    posted_by = 1,
    status = 'active',
  } = req.body;

  try {
    const result = await pool.query(
      `INSERT INTO jobs 
        (title, company, location, type, salary_min, salary_max, description, requirements, benefits, posted_by, status)
       VALUES 
        ($1, $2, $3, $4, $5, $6, $7, $8::jsonb, $9::jsonb, $10, $11)
       RETURNING *`,
      [title, company, location, type, salary_min, salary_max, description, JSON.stringify(requirements), JSON.stringify(benefits), posted_by, status]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};





// Update Job
export const updateJob = async (req, res) => {
  const { id } = req.params;
  const {
    title,
    company,
    location,
    type,
    salary_min,
    salary_max,
    description,
    requirements = [],
    benefits = [],
    status
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE jobs SET
        title = $1,
        company = $2,
        location = $3,
        type = $4,
        salary_min = $5,
        salary_max = $6,
        description = $7,
        requirements = $8::jsonb,
        benefits = $9::jsonb,
        status = $10,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $11
      RETURNING *`,
      [
        title, 
        company, 
        location, 
        type, 
        salary_min, 
        salary_max, 
        description,
        JSON.stringify(requirements),
        JSON.stringify(benefits),
        status,
        id
      ]
    );
    
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Delete Job
export const deleteJob = async (req, res) => {
  const { id } = req.params;
  
  try {
    const result = await pool.query(
      'DELETE FROM jobs WHERE id = $1 RETURNING *',
      [id]
    );
    
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    res.json({ message: 'Job deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};





// Get a single job by ID
export const getJobById = async (req, res) => {
  try {
    const { id } = req.params;


    const numericId = Number(id);
    if (isNaN(numericId)) {
     
      return res.status(400).json({ error: 'Invalid job ID format' });
    }

    const result = await pool.query('SELECT * FROM jobs WHERE id = $1', [numericId]);
    console.log('Database Query Result:', result.rows);

    if (result.rows.length === 0) {
    
      return res.status(404).json({ error: 'Job not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Database Error in getJobById:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
};


// Apply for a job



export const applyForJob = async (req, res) => {
  try {
    console.log("🔁 Incoming payload:", req.body);

    const { job_id, user_id, cover_letter, resume_url } = req.body;

    if (!job_id || !user_id || !cover_letter || !resume_url) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // 1. Insert into applications
    const result = await pool.query(
      'INSERT INTO applications (job_id, user_id, cover_letter, resume_url) VALUES ($1, $2, $3, $4) RETURNING *',
      [job_id, user_id, cover_letter, resume_url]
    );
    const application = result.rows[0];

    // 2. Fetch company (job poster) email and job title
    const jobInfo = await pool.query(`
      SELECT j.title, u.email as company_email, u.name as company_name
      FROM jobs j
      JOIN users u ON j.posted_by = u.id
      WHERE j.id = $1
    `, [job_id]);

    const { title, company_email, company_name } = jobInfo.rows[0];

    // 3. Fetch applicant name and email
    const userInfo = await pool.query(`SELECT name, email FROM users WHERE id = $1`, [user_id]);
    const { name: applicant_name, email: applicant_email } = userInfo.rows[0];

    // 4. Send email to company
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user:  process.env.EMAIL_USER,
        pass:   process.env.EMAIL_PASS 
      }
    });

    const mailOptions = {
      // from: applicant_email,
      from: "malleshmudigir91@gmail.com",
      to: company_email,
      subject: `New Job Application: ${title}`,
      html: `
        <p>Hello ${company_name},</p>
        <p><strong>${applicant_name}</strong> has applied for the job <strong>${title}</strong>.</p>
        <p><strong>Email:</strong> ${applicant_email}</p>
        <p><strong>Cover Letter:</strong></p>
        <p>${cover_letter}</p>
        <p><a href="${resume_url}" target="_blank">View Resume</a></p>
        <br/>
        <p>Best regards,<br/>Job Portal System</p>
      `
    };

    await transporter.sendMail(mailOptions);

    console.log("📩 Application email sent to company:", company_email);
    res.status(201).json(application);

  } catch (err) {
    console.error("🔥 Error in applyForJob:", err.message);
    res.status(500).json({ error: "Internal server error" });
  }
};



// Get user's applications
export const getUserApplications = async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await pool.query(
      'SELECT a.*, j.title as job_title, j.company FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.user_id = $1',
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};



// controllers/jobController.js


export const getAllJobsForRecommendations = async (req, res) => {
  console.log("triggered");
  try {
    const result = await pool.query(`
      SELECT 
        id, title, company, location, type, 
        salary_min, salary_max, description,
        requirements, benefits, created_at
      FROM jobs
      ORDER BY created_at DESC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};



// Get user details
export const getUser= async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const user = result.rows[0];
    res.json({
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      location: user.location,
      bio: user.bio,
      avatar: user.avatar,
      skills: user.skills || [],
      experience: user.experience || [],
      education: user.education || []
    });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update user details
export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name,
      phone,
      location,
      bio,
      avatar,
      skills,
      experience,
      education
    } = req.body;

    const result = await pool.query(
      `UPDATE users 
       SET name = $1, phone = $2, location = $3, bio = $4, avatar = $5, 
           skills = $6, experience = $7, education = $8, updated_at = NOW()
       WHERE id = $9
       RETURNING *`,
      [name, phone, location, bio, avatar, skills, experience, education, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const updatedUser = result.rows[0];
    res.json({
      id: updatedUser.id,
      name: updatedUser.name,
      email: updatedUser.email,
      phone: updatedUser.phone,
      location: updatedUser.location,
      bio: updatedUser.bio,
      avatar: updatedUser.avatar,
      skills: updatedUser.skills || [],
      experience: updatedUser.experience || [],
      education: updatedUser.education || []
    });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

