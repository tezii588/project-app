
import express from 'express';
import {
updateJobStatus,
getAllApplications
} from '../controllers/RecruiterController.js'; 

const router = express.Router();


router.get("/applications",getAllApplications);


router.put("/applications/:id/status",updateJobStatus);


export default router;