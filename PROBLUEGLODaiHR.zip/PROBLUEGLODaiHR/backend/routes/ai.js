import express from 'express';
import { body, validationResult } from 'express-validator';
import OpenAI from 'openai';
import pool from '../config/database.js';        // ✅

import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Get AI recommendations for a job
router.post('/recommendations', authenticateToken, requireRole(['recruiter']), [
  body('job_id').isUUID(),
  body('limit').optional().isInt({ min: 1, max: 50 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { job_id, limit = 10 } = req.body;

    // Get job details
    const jobResult = await pool.query(
      'SELECT * FROM jobs WHERE id = $1 AND recruiter_id = $2 AND is_active = true',
      [job_id, req.user.id]
    );

    if (jobResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Job not found or unauthorized'
      });
    }

    const job = jobResult.rows[0];

    // Get all candidates with profiles
    const candidatesResult = await pool.query(`
      SELECT u.id, u.first_name, u.last_name, u.email,
             cp.skills, cp.experience_years, cp.current_position, 
             cp.current_company, cp.summary, cp.resume_url
      FROM users u
      JOIN candidate_profiles cp ON u.id = cp.user_id
      WHERE u.role = 'candidate' AND u.is_active = true
      AND cp.skills IS NOT NULL AND array_length(cp.skills, 1) > 0
    `);

    if (candidatesResult.rows.length === 0) {
      return res.json({
        success: true,
        data: {
          recommendations: [],
          message: 'No candidates found in the database'
        }
      });
    }

    const candidates = candidatesResult.rows;

    // Prepare job description for AI
    const jobDescription = `
      Job Title: ${job.title}
      Description: ${job.description}
      Required Skills: ${job.skills.join(', ')}
      Experience Level: ${job.experience_level}
      Location: ${job.location}
      Job Type: ${job.job_type}
      ${job.requirements ? `Requirements: ${job.requirements}` : ''}
    `;

    // Process candidates in batches to avoid token limits
    const batchSize = 5;
    const recommendations = [];

    for (let i = 0; i < candidates.length; i += batchSize) {
      const batch = candidates.slice(i, i + batchSize);
      
      // Prepare candidate profiles for AI
      const candidateProfiles = batch.map(candidate => `
        Candidate ID: ${candidate.id}
        Name: ${candidate.first_name} ${candidate.last_name}
        Skills: ${candidate.skills.join(', ')}
        Experience: ${candidate.experience_years} years
        Current Position: ${candidate.current_position || 'Not specified'}
        Current Company: ${candidate.current_company || 'Not specified'}
        Summary: ${candidate.summary || 'No summary provided'}
      `).join('\n\n');

      try {
        const completion = await openai.chat.completions.create({
          model: "gpt-4",
          messages: [
            {
              role: "system",
              content: `You are an AI recruitment assistant. Analyze the job requirements and candidate profiles to provide match scores and reasoning. 

              For each candidate, provide a JSON response with:
              - candidate_id: The candidate's ID
              - match_score: A number between 0-100 representing how well they match
              - reasoning: A detailed explanation of why they match or don't match
              - skills_match: Array of matching skills
              - experience_match: Assessment of experience level fit

              Be objective and consider:
              1. Skills alignment (technical and soft skills)
              2. Experience level appropriateness
              3. Career progression and relevance
              4. Overall profile fit

              Return only valid JSON array format.`
            },
            {
              role: "user",
              content: `Job Requirements:\n${jobDescription}\n\nCandidate Profiles:\n${candidateProfiles}\n\nAnalyze each candidate and provide match scores with detailed reasoning.`
            }
          ],
          temperature: 0.3,
          max_tokens: 2000
        });

        const aiResponse = completion.choices[0].message.content;
        
        try {
          const batchRecommendations = JSON.parse(aiResponse);
          
          if (Array.isArray(batchRecommendations)) {
            recommendations.push(...batchRecommendations);
          }
        } catch (parseError) {
          console.error('Error parsing AI response:', parseError);
          // Fallback: create basic recommendations for this batch
          batch.forEach(candidate => {
            const skillsMatch = candidate.skills.filter(skill => 
              job.skills.some(jobSkill => 
                skill.toLowerCase().includes(jobSkill.toLowerCase()) ||
                jobSkill.toLowerCase().includes(skill.toLowerCase())
              )
            );
            
            const matchScore = Math.min(100, (skillsMatch.length / job.skills.length) * 100);
            
            recommendations.push({
              candidate_id: candidate.id,
              match_score: Math.round(matchScore),
              reasoning: `Skills match: ${skillsMatch.length}/${job.skills.length} required skills. Experience: ${candidate.experience_years} years.`,
              skills_match: skillsMatch,
              experience_match: `${candidate.experience_years} years of experience`
            });
          });
        }
      } catch (aiError) {
        console.error('OpenAI API error:', aiError);
        // Fallback: create basic recommendations for this batch
        batch.forEach(candidate => {
          const skillsMatch = candidate.skills.filter(skill => 
            job.skills.some(jobSkill => 
              skill.toLowerCase().includes(jobSkill.toLowerCase()) ||
              jobSkill.toLowerCase().includes(skill.toLowerCase())
            )
          );
          
          const matchScore = Math.min(100, (skillsMatch.length / job.skills.length) * 100);
          
          recommendations.push({
            candidate_id: candidate.id,
            match_score: Math.round(matchScore),
            reasoning: `Basic skills matching analysis. ${skillsMatch.length} matching skills found.`,
            skills_match: skillsMatch,
            experience_match: `${candidate.experience_years} years of experience`
          });
        });
      }
    }

    // Sort by match score and limit results
    const sortedRecommendations = recommendations
      .sort((a, b) => b.match_score - a.match_score)
      .slice(0, limit);

    // Save recommendations to database
    for (const rec of sortedRecommendations) {
      try {
        await pool.query(
          `INSERT INTO ai_recommendations (job_id, candidate_id, match_score, reasoning, skills_match, experience_match)
           VALUES ($1, $2, $3, $4, $5, $6)
           ON CONFLICT (job_id, candidate_id) DO UPDATE SET
           match_score = EXCLUDED.match_score,
           reasoning = EXCLUDED.reasoning,
           skills_match = EXCLUDED.skills_match,
           experience_match = EXCLUDED.experience_match,
           created_at = CURRENT_TIMESTAMP`,
          [job_id, rec.candidate_id, rec.match_score, rec.reasoning, rec.skills_match, rec.experience_match]
        );
      } catch (dbError) {
        console.error('Error saving recommendation:', dbError);
      }
    }

    // Get full candidate details for response
    const candidateIds = sortedRecommendations.map(r => r.candidate_id);
    const fullCandidatesResult = await pool.query(`
      SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.profile_image,
             cp.skills, cp.experience_years, cp.current_position, cp.current_company,
             cp.summary, cp.resume_url, cp.portfolio_url, cp.linkedin_url,
             cp.expected_salary, cp.preferred_location
      FROM users u
      JOIN candidate_profiles cp ON u.id = cp.user_id
      WHERE u.id = ANY($1)
    `, [candidateIds]);

    // Combine candidate data with AI recommendations
    const finalRecommendations = sortedRecommendations.map(rec => {
      const candidate = fullCandidatesResult.rows.find(c => c.id === rec.candidate_id);
      return {
        ...candidate,
        ai_match_score: rec.match_score,
        ai_reasoning: rec.reasoning,
        skills_match: rec.skills_match,
        experience_match: rec.experience_match
      };
    }).filter(rec => rec.id); // Filter out any null candidates

    res.json({
      success: true,
      data: {
        job_title: job.title,
        total_candidates_analyzed: candidates.length,
        recommendations: finalRecommendations
      }
    });

  } catch (error) {
    console.error('AI recommendations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate AI recommendations'
    });
  }
});

// Get saved recommendations for a job
router.get('/recommendations/:jobId', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const { page = 1, limit = 10, min_score = 0 } = req.query;
    const offset = (page - 1) * limit;

    // Verify job belongs to recruiter
    const jobResult = await pool.query(
      'SELECT id, title FROM jobs WHERE id = $1 AND recruiter_id = $2',
      [req.params.jobId, req.user.id]
    );

    if (jobResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Job not found or unauthorized'
      });
    }

    const result = await pool.query(`
      SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.profile_image,
             cp.skills, cp.experience_years, cp.current_position, cp.current_company,
             cp.summary, cp.resume_url, cp.portfolio_url, cp.linkedin_url,
             cp.expected_salary, cp.preferred_location,
             ar.match_score as ai_match_score, ar.reasoning as ai_reasoning,
             ar.skills_match, ar.experience_match, ar.created_at as recommendation_date
      FROM ai_recommendations ar
      JOIN users u ON ar.candidate_id = u.id
      JOIN candidate_profiles cp ON u.id = cp.user_id
      WHERE ar.job_id = $1 AND ar.match_score >= $2
      ORDER BY ar.match_score DESC
      LIMIT $3 OFFSET $4
    `, [req.params.jobId, parseInt(min_score), parseInt(limit), offset]);

    // Get total count
    const countResult = await pool.query(
      'SELECT COUNT(*) as total FROM ai_recommendations WHERE job_id = $1 AND match_score >= $2',
      [req.params.jobId, parseInt(min_score)]
    );

    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        job_title: jobResult.rows[0].title,
        recommendations: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_recommendations: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Saved recommendations fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recommendations'
    });
  }
});

// Analyze resume with AI
router.post('/analyze-resume', authenticateToken, requireRole(['recruiter']), [
  body('candidate_id').isUUID(),
  body('job_id').optional().isUUID()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { candidate_id, job_id } = req.body;

    // Get candidate profile
    const candidateResult = await pool.query(`
      SELECT u.first_name, u.last_name, u.email,
             cp.skills, cp.experience_years, cp.current_position, 
             cp.current_company, cp.summary, cp.resume_url, cp.education
      FROM users u
      JOIN candidate_profiles cp ON u.id = cp.user_id
      WHERE u.id = $1 AND u.role = 'candidate'
    `, [candidate_id]);

    if (candidateResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }

    const candidate = candidateResult.rows[0];

    // Get job details if job_id provided
    let job = null;
    if (job_id) {
      const jobResult = await pool.query(
        'SELECT * FROM jobs WHERE id = $1 AND recruiter_id = $2',
        [job_id, req.user.id]
      );
      
      if (jobResult.rows.length > 0) {
        job = jobResult.rows[0];
      }
    }

    // Prepare candidate profile for AI analysis
    const candidateProfile = `
      Name: ${candidate.first_name} ${candidate.last_name}
      Skills: ${candidate.skills ? candidate.skills.join(', ') : 'Not specified'}
      Experience: ${candidate.experience_years} years
      Current Position: ${candidate.current_position || 'Not specified'}
      Current Company: ${candidate.current_company || 'Not specified'}
      Education: ${candidate.education || 'Not specified'}
      Summary: ${candidate.summary || 'No summary provided'}
    `;

    let prompt = `Analyze this candidate profile and provide insights:

${candidateProfile}

Please provide:
1. Strengths and key skills
2. Experience assessment
3. Areas for improvement
4. Overall profile summary
5. Recommended roles or industries`;

    if (job) {
      prompt += `

Job Requirements:
Title: ${job.title}
Description: ${job.description}
Required Skills: ${job.skills.join(', ')}
Experience Level: ${job.experience_level}

Also provide:
6. Fit for this specific job (1-10 scale)
7. Specific recommendations for this role`;
    }

    try {
      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "You are an expert HR analyst and career counselor. Provide detailed, constructive, and professional analysis of candidate profiles. Be objective and helpful."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 1500
      });

      const analysis = completion.choices[0].message.content;

      res.json({
        success: true,
        data: {
          candidate: {
            name: `${candidate.first_name} ${candidate.last_name}`,
            email: candidate.email,
            current_position: candidate.current_position,
            experience_years: candidate.experience_years
          },
          job: job ? {
            title: job.title,
            required_skills: job.skills
          } : null,
          ai_analysis: analysis
        }
      });

    } catch (aiError) {
      console.error('OpenAI API error:', aiError);
      res.status(500).json({
        success: false,
        message: 'Failed to analyze resume with AI'
      });
    }

  } catch (error) {
    console.error('Resume analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to analyze resume'
    });
  }
});

// Generate job description with AI
router.post('/generate-job-description', authenticateToken, requireRole(['recruiter']), [
  body('job_title').trim().isLength({ min: 1 }),
  body('company_description').optional().trim(),
  body('key_requirements').optional().isArray()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { job_title, company_description, key_requirements = [] } = req.body;

    const prompt = `Generate a comprehensive job description for the following position:

Job Title: ${job_title}
${company_description ? `Company Description: ${company_description}` : ''}
${key_requirements.length > 0 ? `Key Requirements: ${key_requirements.join(', ')}` : ''}

Please provide:
1. Job Summary (2-3 sentences)
2. Key Responsibilities (5-7 bullet points)
3. Required Qualifications (education, experience, skills)
4. Preferred Qualifications
5. Benefits and Perks (generic but appealing)

Make it professional, engaging, and industry-appropriate.`;

    try {
      const completion = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "You are an expert HR professional and job description writer. Create compelling, accurate, and professional job descriptions that attract top talent."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.4,
        max_tokens: 1200
      });

      const jobDescription = completion.choices[0].message.content;

      res.json({
        success: true,
        data: {
          job_title,
          generated_description: jobDescription
        }
      });

    } catch (aiError) {
      console.error('OpenAI API error:', aiError);
      res.status(500).json({
        success: false,
        message: 'Failed to generate job description with AI'
      });
    }

  } catch (error) {
    console.error('Job description generation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate job description'
    });
  }
});

export default router;