import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../config/database.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import upload from '../middleware/upload.js';
import { sendEmailToRecruiter } from '../utils/mailer.js';
const router = express.Router();

// Apply for job (Candidates only)
// routes/applications.js
router.post('/', authenticateCandidate, async (req, res) => {
  const { job_id, resume_url, cover_letter } = req.body;
  const application = await pool.query(`
    INSERT INTO applications (job_id, candidate_id, resume_url, cover_letter, status)
    VALUES ($1, $2, $3, $4, 'applied') RETURNING *`,
    [job_id, req.user.id, resume_url, cover_letter]);

  // Notify recruiter by email or notification
  sendEmailToRecruiter(job_id, req.user.id);

  res.status(201).json(application.rows[0]);
});

    }

    const { job_id, cover_letter } = req.body;
    const resume_url = req.file ? `/uploads/resumes/${req.file.filename}` : null;

    // Check if job exists and is active
    const jobResult = await pool.query(
      'SELECT id, title, recruiter_id FROM jobs WHERE id = $1 AND is_active = true',
      [job_id]
    );

    if (jobResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Job not found or inactive'
      });
    }

    // Check if already applied
    const existingApplication = await pool.query(
      'SELECT id FROM applications WHERE job_id = $1 AND candidate_id = $2',
      [job_id, req.user.id]
    );

    if (existingApplication.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'You have already applied for this job'
      });
    }

    // Create application
    const result = await pool.query(
      `INSERT INTO applications (job_id, candidate_id, cover_letter, resume_url)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [job_id, req.user.id, cover_letter, resume_url]
    );

    res.status(201).json({
      success: true,
      message: 'Application submitted successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Application error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit application'
    });
  }
});

// Get candidate's applications
router.get('/my-applications', authenticateToken, requireRole(['candidate']), async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const offset = (page - 1) * limit;

    let whereClause = 'a.candidate_id = $1';
    let queryParams = [req.user.id];

    if (status) {
      whereClause += ' AND a.status = $2';
      queryParams.push(status);
    }

    const result = await pool.query(
      `SELECT a.*, j.title as job_title, j.location, j.job_type, j.salary_min, j.salary_max,
              u.first_name as recruiter_first_name, u.last_name as recruiter_last_name,
              u.company as recruiter_company
       FROM applications a
       JOIN jobs j ON a.job_id = j.id
       JOIN users u ON j.recruiter_id = u.id
       WHERE ${whereClause}
       ORDER BY a.applied_at DESC
       LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}`,
      [...queryParams, parseInt(limit), offset]
    );

    // Get total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as total FROM applications a WHERE ${whereClause}`,
      queryParams
    );

    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        applications: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_applications: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Applications fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch applications'
    });
  }
});

// Get applications for a job (Recruiters only)
router.get('/job/:jobId', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const offset = (page - 1) * limit;

    // Verify job belongs to recruiter
    const jobResult = await pool.query(
      'SELECT id FROM jobs WHERE id = $1 AND recruiter_id = $2',
      [req.params.jobId, req.user.id]
    );

    if (jobResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Job not found or unauthorized'
      });
    }

    let whereClause = 'a.job_id = $1';
    let queryParams = [req.params.jobId];

    if (status) {
      whereClause += ' AND a.status = $2';
      queryParams.push(status);
    }

    const result = await pool.query(
      `SELECT a.*, 
              u.first_name, u.last_name, u.email, u.phone, u.profile_image,
              cp.skills, cp.experience_years, cp.current_position, cp.current_company,
              cp.summary, cp.expected_salary, cp.resume_url
       FROM applications a
       JOIN users u ON a.candidate_id = u.id
       LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
       WHERE ${whereClause}
       ORDER BY a.applied_at DESC
       LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}`,
      [...queryParams, parseInt(limit), offset]
    );

    // Get total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as total FROM applications a WHERE ${whereClause}`,
      queryParams
    );

    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        applications: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_applications: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Job applications fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch applications'
    });
  }
});

// Update application status (Recruiters only)
router.put('/:id/status', authenticateRecruiter, async (req, res) => {
  const { status } = req.body;
  await pool.query(`UPDATE applications SET status = $1 WHERE id = $2`, [status, req.params.id]);

  // Notify candidate
  sendEmailToCandidate(req.params.id, status);

  res.json({ success: true, status });
});

    }

    const { status, recruiter_notes } = req.body;

    // Verify application belongs to recruiter's job
    const applicationResult = await pool.query(
      `SELECT a.id, a.candidate_id, a.job_id, j.recruiter_id
       FROM applications a
       JOIN jobs j ON a.job_id = j.id
       WHERE a.id = $1 AND j.recruiter_id = $2`,
      [req.params.id, req.user.id]
    );

    if (applicationResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Application not found or unauthorized'
      });
    }

    const result = await pool.query(
      `UPDATE applications 
       SET status = $1, recruiter_notes = $2, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [status, recruiter_notes, req.params.id]
    );

    res.json({
      success: true,
      message: 'Application status updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Application status update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update application status'
    });
  }
});

// Get single application
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    let query, queryParams;

    if (req.user.role === 'candidate') {
      // Candidates can only see their own applications
      query = `
        SELECT a.*, j.title as job_title, j.description, j.location, j.job_type,
               j.salary_min, j.salary_max, j.skills as job_skills,
               u.first_name as recruiter_first_name, u.last_name as recruiter_last_name,
               u.company as recruiter_company
        FROM applications a
        JOIN jobs j ON a.job_id = j.id
        JOIN users u ON j.recruiter_id = u.id
        WHERE a.id = $1 AND a.candidate_id = $2
      `;
      queryParams = [req.params.id, req.user.id];
    } else {
      // Recruiters can see applications for their jobs
      query = `
        SELECT a.*, j.title as job_title,
               u.first_name, u.last_name, u.email, u.phone,
               cp.skills, cp.experience_years, cp.current_position, cp.current_company,
               cp.summary, cp.expected_salary, cp.resume_url
        FROM applications a
        JOIN jobs j ON a.job_id = j.id
        JOIN users u ON a.candidate_id = u.id
        LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
        WHERE a.id = $1 AND j.recruiter_id = $2
      `;
      queryParams = [req.params.id, req.user.id];
    }

    const result = await pool.query(query, queryParams);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Application not found or unauthorized'
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Application fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch application'
    });
  }
});

// Withdraw application (Candidates only)
router.delete('/:id', authenticateToken, requireRole(['candidate']), async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM applications WHERE id = $1 AND candidate_id = $2 RETURNING id',
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Application not found or unauthorized'
      });
    }

    res.json({
      success: true,
      message: 'Application withdrawn successfully'
    });

  } catch (error) {
    console.error('Application withdrawal error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to withdraw application'
    });
  }
});

export default router;