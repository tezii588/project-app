import express from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { analyzeResume } from '../services/openai.js';

const router = express.Router();

// Configure multer to upload resumes to temp folder
const upload = multer({ dest: 'uploads/resumes/' });

// POST /apply
router.post('/', upload.single('resume'), async (req, res) => {
  try {
    const { jobDescription } = req.body;

    if (!req.file || !jobDescription) {
      return res.status(400).json({ error: 'Resume and job description are required' });
    }

    // Read uploaded resume content
    const resumePath = path.join(req.file.destination, req.file.filename);
    const resumeText = fs.readFileSync(resumePath, 'utf-8');

    // Analyze using OpenAI
    const analysis = await analyzeResume(resumeText, jobDescription);

    // Cleanup: delete temp file
    fs.unlinkSync(resumePath);

    return res.json({ success: true, analysis });
  } catch (error) {
    console.error('Resume analysis failed:', error);
    return res.status(500).json({ error: 'Resume analysis failed' });
  }
});

export default router;
