// // import express from 'express';
// // import bcrypt from 'bcryptjs';
// // import jwt from 'jsonwebtoken';
// // import pool from '../db.js';
// // const router = express.Router();

// // const RECRUITER_EMAIL = "recruiter@visys.com";
// // const RECRUITER_PASSWORD = "recruiter123"; // Can be hashed and stored securely
// // const JWT_SECRET = process.env.JWT_SECRET;

// // // Candidate Registration
// // router.post('/register', async (req, res) => {
// //   const { email, password, role, name } = req.body;

// //   console.log('[REGISTER] Data:', { email, password, role, name });

// //   if (role !== 'candidate') {
// //     return res.status(400).json({ error: 'Only candidates can register' });
// //   }

// //   try {
// //     const existing = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
// //     if (existing.rows.length > 0) {
// //       return res.status(400).json({ error: 'User already exists' });
// //     }

// //     await pool.query(
// //       'INSERT INTO users (email, password, role, name) VALUES ($1, $2, $3, $4)',
// //       [email, password, role, name || null]
// //     );

// //     res.json({ message: 'Candidate registered successfully' });
// //   } catch (err) {
// //     console.error('[REGISTER ERROR]:', err);
// //     res.status(500).json({ error: 'Server error while registering user' });
// //   }
// // });
// // // Login (Candidate + Recruiter)
// // router.post('/login', async (req, res) => {
// //   const { email, password, role } = req.body;

// //   try {
// //     const userResult = await pool.query(
// //       'SELECT * FROM users WHERE email = $1 AND role = $2',
// //       [email, role]
// //     );

// //     if (userResult.rows.length === 0) {
// //       return res.status(404).json({ error: 'User not found' });
// //     }

// //     const user = userResult.rows[0];

// //     // DEBUGGING OUTPUT
// //     console.log('DB password:', `'${user.password}'`);
// //     console.log('Input password:', `'${password}'`);

// //     // 👇 Add .trim() to avoid space issues
// //     if (user.password.trim() !== password.trim()) {
// //       return res.status(401).json({ error: 'Incorrect password' });
// //     }

// //     res.json({ message: `${role} logged in successfully` });
// //   } catch (err) {
// //     console.error('[LOGIN ERROR]:', err);
// //     res.status(500).json({ error: 'Server error during login' });
// //   }
// // });




// // export default router;


// import express from 'express';
// import jwt from 'jsonwebtoken';
// import pool from '../config/database.js';
// import { authenticateToken, requireRole } from '../middleware/auth.js';
// import { authenticateToken, requireRole } from '../middleware/auth.js';


// const router = express.Router();

// const RECRUITER_EMAIL = "recruiter@visys.com";
// const RECRUITER_PASSWORD = "recruiter123";
// const JWT_SECRET = process.env.JWT_SECRET || 'supersecret123'; // fallback if env not set

// // Candidate Registration
// router.post('/register', async (req, res) => {
//   const { email, password, role, name } = req.body;

//   console.log('[REGISTER] Data:', { email, password, role, name });

//   if (role !== 'candidate') {
//     return res.status(400).json({ error: 'Only candidates can register' });
//   }

//   try {
//     const existing = await pool.query('SELECT * FROM users WHERE email = $1', [email.trim()]);
//     if (existing.rows.length > 0) {
//       return res.status(400).json({ error: 'User already exists' });
//     }

//    await pool.query(
//   'INSERT INTO users (email, password, role, name) VALUES ($1, $2, $3, $4)',
//   [email.trim(), password.trim(), role.trim(), name?.trim() || null]
// );

//     res.json({ message: 'Candidate registered successfully' });
//   } catch (err) {
//     console.error('[REGISTER ERROR]:', err);
//     res.status(500).json({ error: 'Server error while registering user' });
//   }
// });

// // Login (Candidate + Recruiter)
// router.post('/login', async (req, res) => {
//   const { email, password, role } = req.body;

//   try {
//     // Recruiter login (fixed credentials)
//     if (role === 'recruiter') {
//       if (email.trim() === RECRUITER_EMAIL && password.trim() === RECRUITER_PASSWORD) {
//         return res.json({ message: 'Recruiter logged in successfully' });
//       } else {
//         return res.status(401).json({ error: 'Invalid recruiter credentials' });
//       }
//     }

//     // Candidate login from DB
//     const userResult = await pool.query(
//       'SELECT * FROM users WHERE email = $1 AND role = $2',
//       [email.trim(), role.trim()]
//     );

//     if (userResult.rows.length === 0) {
//       return res.status(404).json({ error: 'Candidate not found' });
//     }

//     const user = userResult.rows[0];

//     console.log('DB password:', `'${user.password}'`);
//     console.log('Input password:', `'${password}'`);
//     console.log('== DEBUG LOGIN ==');
//     console.log('INPUT:', { email, password, role });
//     console.log('DB password:', `'${user.password}'`);
//     console.log('Input password:', `'${password}'`);
//     console.log('Match:', user.password.trim() === password.trim());

//     if (user.password.trim() !== password.trim()) {
//       return res.status(401).json({ error: 'Incorrect password' });
//     }

//     res.json({ message: 'Candidate logged in successfully' });
//   } catch (err) {
//     console.error('[LOGIN ERROR]:', err);
//     res.status(500).json({ error: 'Server error during login' });
//   }
// });
// // Update profile
// router.put('/profile', authenticateToken, upload.single('profile_image'), async (req, res) => {
//   // your update profile logic here


//   try {
//     const { first_name, last_name, phone, company } = req.body;
//     const profile_image = req.file ? `/uploads/profiles/${req.file.filename}` : null;

//     let updateQuery = `
//       UPDATE users 
//       SET first_name = $1, last_name = $2, phone = $3, company = $4, updated_at = CURRENT_TIMESTAMP
//     `;
//     let queryParams = [first_name, last_name, phone, company];

//     if (profile_image) {
//       updateQuery += `, profile_image = $5 WHERE id = $6`;
//       queryParams.push(profile_image, req.user.id);
//     } else {
//       updateQuery += ` WHERE id = $5`;
//       queryParams.push(req.user.id);
//     }

//     updateQuery += ` RETURNING id, email, first_name, last_name, role, phone, company, profile_image`;

//     const result = await pool.query(updateQuery, queryParams);

//     res.json({
//       success: true,
//       message: 'Profile updated successfully',
//       data: result.rows[0]
//     });

//   } catch (error) {
//     console.error('Profile update error:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Failed to update profile'
//     });
//   }
// });

// export default router;


import express from 'express';
import jwt from 'jsonwebtoken';
import pool from '../config/database.js'; // ✅ Use correct path
import { authenticateToken, requireRole } from '../middleware/auth.js'; // ✅ Only once
import upload from '../middleware/upload.js'; // ✅ Add this

const router = express.Router();

const RECRUITER_EMAIL = "recruiter@visys.com";
const RECRUITER_PASSWORD = "recruiter123";
const JWT_SECRET = process.env.JWT_SECRET || 'supersecret123'; // fallback if env not set

// ----------------------
// Candidate Registration
// ----------------------
router.post('/register', async (req, res) => {
  const { email, password, role, name } = req.body;

  if (role !== 'candidate') {
    return res.status(400).json({ error: 'Only candidates can register' });
  }

  try {
    const existing = await pool.query('SELECT * FROM users WHERE email = $1', [email.trim()]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'User already exists' });
    }

    await pool.query(
      'INSERT INTO users (email, password, role, name) VALUES ($1, $2, $3, $4)',
      [email.trim(), password.trim(), role.trim(), name?.trim() || null]
    );

    res.json({ message: 'Candidate registered successfully' });
  } catch (err) {
    console.error('[REGISTER ERROR]:', err);
    res.status(500).json({ error: 'Server error while registering user' });
  }
});

// ------------------
// Login (All Roles)
// ------------------
router.post('/login', async (req, res) => {
 
  const { email, password, role } = req.body;
     console.log( email, password, role )
  try {
    // Recruiter login (hardcoded)
    if (role === 'recruiter') {
      if (email.trim() === RECRUITER_EMAIL && password.trim() === RECRUITER_PASSWORD) {
        const token = jwt.sign({ email, role: 'recruiter' }, JWT_SECRET, { expiresIn: '7d' });
        return res.json({ message: 'Recruiter logged in successfully', token });
      } else {
        return res.status(401).json({ error: 'Invalid recruiter credentials' });
      }
    }

    // Candidate login (from DB)
    const userResult = await pool.query(
      'SELECT * FROM users WHERE email = $1 AND role = $2',
      [email.trim(), role.trim()]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'Candidate not found' });
    }

    const user = userResult.rows[0];

    if (user.password.trim() !== password.trim()) {
      return res.status(401).json({ error: 'Incorrect password' });
    }

    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

  
    res.json({ message: 'Candidate logged in successfully', token, id: user.id });

  } catch (err) {
    console.error('[LOGIN ERROR]:', err);
    res.status(500).json({ error: 'Server error during login' });
  }
});

// ------------------
// Update Profile API
// ------------------
router.put('/profile', authenticateToken, upload.single('profile_image'), async (req, res) => {
  try {
    const { first_name, last_name, phone, company } = req.body;
    const profile_image = req.file ? `/uploads/profiles/${req.file.filename}` : null;

    let updateQuery = `
      UPDATE users 
      SET first_name = $1, last_name = $2, phone = $3, company = $4, updated_at = CURRENT_TIMESTAMP
    `;
    let queryParams = [first_name, last_name, phone, company];

    if (profile_image) {
      updateQuery += `, profile_image = $5 WHERE id = $6`;
      queryParams.push(profile_image, req.user.id);
    } else {
      updateQuery += ` WHERE id = $5`;
      queryParams.push(req.user.id);
    }

    updateQuery += ` RETURNING id, email, first_name, last_name, role, phone, company, profile_image`;

    const result = await pool.query(updateQuery, queryParams);

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile'
    });
  }
});

export default router;
