import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../config/database.js';        // ✅

import { authenticateToken, requireRole } from '../middleware/auth.js';
import upload from '../middleware/upload.js';

const router = express.Router();

// Update candidate profile
router.put('/profile', authenticateToken, requireRole(['candidate']), upload.single('resume'), [
  body('skills').optional().isArray(),
  body('experience_years').optional().isInt({ min: 0 }),
  body('expected_salary').optional().isInt({ min: 0 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const {
      skills, experience_years, current_position, current_company,
      education, certifications, portfolio_url, linkedin_url, github_url,
      summary, preferred_location, expected_salary, availability_date
    } = req.body;

    const resume_url = req.file ? `/uploads/resumes/${req.file.filename}` : null;

    let updateQuery = `
      UPDATE candidate_profiles SET 
        skills = $1, experience_years = $2, current_position = $3, current_company = $4,
        education = $5, certifications = $6, portfolio_url = $7, linkedin_url = $8,
        github_url = $9, summary = $10, preferred_location = $11, expected_salary = $12,
        availability_date = $13, updated_at = CURRENT_TIMESTAMP
    `;

    let queryParams = [
      skills || [], experience_years, current_position, current_company,
      education, certifications, portfolio_url, linkedin_url,
      github_url, summary, preferred_location, expected_salary,
      availability_date
    ];

    if (resume_url) {
      updateQuery += `, resume_url = $14 WHERE user_id = $15`;
      queryParams.push(resume_url, req.user.id);
    } else {
      updateQuery += ` WHERE user_id = $14`;
      queryParams.push(req.user.id);
    }

    updateQuery += ` RETURNING *`;

    const result = await pool.query(updateQuery, queryParams);

    if (result.rows.length === 0) {
      // Create profile if it doesn't exist
      const createResult = await pool.query(
        `INSERT INTO candidate_profiles (
          user_id, skills, experience_years, current_position, current_company,
          education, certifications, portfolio_url, linkedin_url, github_url,
          summary, preferred_location, expected_salary, availability_date, resume_url
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
        RETURNING *`,
        [
          req.user.id, skills || [], experience_years, current_position, current_company,
          education, certifications, portfolio_url, linkedin_url, github_url,
          summary, preferred_location, expected_salary, availability_date, resume_url
        ]
      );

      return res.json({
        success: true,
        message: 'Profile created successfully',
        data: createResult.rows[0]
      });
    }

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile'
    });
  }
});

// Get candidate profile
router.get('/profile', authenticateToken, requireRole(['candidate']), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT cp.*, u.first_name, u.last_name, u.email, u.phone
       FROM candidate_profiles cp
       JOIN users u ON cp.user_id = u.id
       WHERE cp.user_id = $1`,
      [req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Profile not found'
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch profile'
    });
  }
});

// Get all candidates (Recruiters only)
router.get('/', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      skills,
      experience_min,
      experience_max,
      location,
      search
    } = req.query;

    const offset = (page - 1) * limit;
    let whereConditions = ['u.role = \'candidate\'', 'u.is_active = true'];
    let queryParams = [];
    let paramCount = 0;

    // Build dynamic WHERE clause
    if (skills) {
      paramCount++;
      whereConditions.push(`cp.skills && $${paramCount}`);
      queryParams.push(Array.isArray(skills) ? skills : [skills]);
    }

    if (experience_min) {
      paramCount++;
      whereConditions.push(`cp.experience_years >= $${paramCount}`);
      queryParams.push(parseInt(experience_min));
    }

    if (experience_max) {
      paramCount++;
      whereConditions.push(`cp.experience_years <= $${paramCount}`);
      queryParams.push(parseInt(experience_max));
    }

    if (location) {
      paramCount++;
      whereConditions.push(`cp.preferred_location ILIKE $${paramCount}`);
      queryParams.push(`%${location}%`);
    }

    if (search) {
      paramCount++;
      whereConditions.push(`(
        u.first_name ILIKE $${paramCount} OR 
        u.last_name ILIKE $${paramCount} OR 
        cp.current_position ILIKE $${paramCount} OR 
        cp.summary ILIKE $${paramCount}
      )`);
      queryParams.push(`%${search}%`);
    }

    const whereClause = whereConditions.join(' AND ');

    const candidatesQuery = `
      SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.profile_image,
             cp.skills, cp.experience_years, cp.current_position, cp.current_company,
             cp.summary, cp.preferred_location, cp.expected_salary, cp.resume_url,
             cp.portfolio_url, cp.linkedin_url, cp.github_url
      FROM users u
      LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
      WHERE ${whereClause}
      ORDER BY u.created_at DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `;

    queryParams.push(parseInt(limit), offset);

    const result = await pool.query(candidatesQuery, queryParams);

    // Get total count
    const countQuery = `
      SELECT COUNT(*) as total
      FROM users u
      LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
      WHERE ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams.slice(0, -2));
    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        candidates: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_candidates: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Candidates fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch candidates'
    });
  }
});

// Get single candidate (Recruiters only)
router.get('/:id', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.profile_image, u.created_at,
              cp.skills, cp.experience_years, cp.current_position, cp.current_company,
              cp.education, cp.certifications, cp.summary, cp.preferred_location, 
              cp.expected_salary, cp.resume_url, cp.portfolio_url, cp.linkedin_url, cp.github_url,
              cp.availability_date
       FROM users u
       LEFT JOIN candidate_profiles cp ON u.id = cp.user_id
       WHERE u.id = $1 AND u.role = 'candidate' AND u.is_active = true`,
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }

    // Get candidate's application history
    const applicationsResult = await pool.query(
      `SELECT a.id, a.status, a.applied_at, a.ai_match_score,
              j.title as job_title, j.company
       FROM applications a
       JOIN jobs j ON a.job_id = j.id
       WHERE a.candidate_id = $1
       ORDER BY a.applied_at DESC`,
      [req.params.id]
    );

    const candidate = result.rows[0];
    candidate.applications = applicationsResult.rows;

    res.json({
      success: true,
      data: candidate
    });

  } catch (error) {
    console.error('Candidate fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch candidate'
    });
  }
});

export default router;