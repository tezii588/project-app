import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../config/database.js';        // ✅

import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Schedule interview (Recruiters only)
router.post('/', authenticateToken, requireRole(['recruiter']), [
  body('application_id').isUUID(),
  body('interview_type').isIn(['video', 'in-person', 'phone']),
  body('scheduled_date').isISO8601(),
  body('duration_minutes').optional().isInt({ min: 15, max: 480 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const {
      application_id, interview_type, scheduled_date,
      duration_minutes = 60, meeting_link, location
    } = req.body;

    // Verify application belongs to recruiter's job
    const applicationResult = await pool.query(
      `SELECT a.id, a.candidate_id, a.job_id, j.recruiter_id
       FROM applications a
       JOIN jobs j ON a.job_id = j.id
       WHERE a.id = $1 AND j.recruiter_id = $2`,
      [application_id, req.user.id]
    );

    if (applicationResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Application not found or unauthorized'
      });
    }

    const application = applicationResult.rows[0];

    // Check if interview already exists for this application
    const existingInterview = await pool.query(
      'SELECT id FROM interviews WHERE application_id = $1 AND status != \'cancelled\'',
      [application_id]
    );

    if (existingInterview.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Interview already scheduled for this application'
      });
    }

    // Create interview
    const result = await pool.query(
      `INSERT INTO interviews (
        application_id, recruiter_id, candidate_id, job_id,
        interview_type, scheduled_date, duration_minutes, meeting_link, location
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`,
      [
        application_id, req.user.id, application.candidate_id, application.job_id,
        interview_type, scheduled_date, duration_minutes, meeting_link, location
      ]
    );

    // Update application status
    await pool.query(
      'UPDATE applications SET status = \'interview_scheduled\', updated_at = CURRENT_TIMESTAMP WHERE id = $1',
      [application_id]
    );

    res.status(201).json({
      success: true,
      message: 'Interview scheduled successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Interview scheduling error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to schedule interview'
    });
  }
});

// Get interviews (role-based)
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, status, date_from, date_to } = req.query;
    const offset = (page - 1) * limit;

    let whereConditions = [];
    let queryParams = [];
    let paramCount = 0;

    // Role-based filtering
    if (req.user.role === 'recruiter') {
      paramCount++;
      whereConditions.push(`i.recruiter_id = $${paramCount}`);
      queryParams.push(req.user.id);
    } else {
      paramCount++;
      whereConditions.push(`i.candidate_id = $${paramCount}`);
      queryParams.push(req.user.id);
    }

    // Status filter
    if (status) {
      paramCount++;
      whereConditions.push(`i.status = $${paramCount}`);
      queryParams.push(status);
    }

    // Date range filter
    if (date_from) {
      paramCount++;
      whereConditions.push(`i.scheduled_date >= $${paramCount}`);
      queryParams.push(date_from);
    }

    if (date_to) {
      paramCount++;
      whereConditions.push(`i.scheduled_date <= $${paramCount}`);
      queryParams.push(date_to);
    }

    const whereClause = whereConditions.join(' AND ');

    const interviewsQuery = `
      SELECT i.*,
             j.title as job_title,
             c.first_name as candidate_first_name, c.last_name as candidate_last_name,
             c.email as candidate_email, c.phone as candidate_phone,
             r.first_name as recruiter_first_name, r.last_name as recruiter_last_name,
             r.company as recruiter_company
      FROM interviews i
      JOIN jobs j ON i.job_id = j.id
      JOIN users c ON i.candidate_id = c.id
      JOIN users r ON i.recruiter_id = r.id
      WHERE ${whereClause}
      ORDER BY i.scheduled_date ASC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `;

    queryParams.push(parseInt(limit), offset);

    const result = await pool.query(interviewsQuery, queryParams);

    // Get total count
    const countQuery = `
      SELECT COUNT(*) as total
      FROM interviews i
      WHERE ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams.slice(0, -2));
    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        interviews: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_interviews: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Interviews fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch interviews'
    });
  }
});

// Get single interview
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    let whereClause = 'i.id = $1';
    let queryParams = [req.params.id];

    // Role-based access control
    if (req.user.role === 'recruiter') {
      whereClause += ' AND i.recruiter_id = $2';
      queryParams.push(req.user.id);
    } else {
      whereClause += ' AND i.candidate_id = $2';
      queryParams.push(req.user.id);
    }

    const result = await pool.query(
      `SELECT i.*,
              j.title as job_title, j.description as job_description,
              c.first_name as candidate_first_name, c.last_name as candidate_last_name,
              c.email as candidate_email, c.phone as candidate_phone,
              r.first_name as recruiter_first_name, r.last_name as recruiter_last_name,
              r.company as recruiter_company, r.email as recruiter_email,
              cp.resume_url, cp.skills as candidate_skills, cp.experience_years
       FROM interviews i
       JOIN jobs j ON i.job_id = j.id
       JOIN users c ON i.candidate_id = c.id
       JOIN users r ON i.recruiter_id = r.id
       LEFT JOIN candidate_profiles cp ON c.id = cp.user_id
       WHERE ${whereClause}`,
      queryParams
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found or unauthorized'
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Interview fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch interview'
    });
  }
});

// Update interview
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const {
      interview_type, scheduled_date, duration_minutes,
      meeting_link, location, status, interviewer_notes,
      candidate_feedback, rating
    } = req.body;

    let whereClause = 'id = $1';
    let queryParams = [req.params.id];

    // Role-based access control
    if (req.user.role === 'recruiter') {
      whereClause += ' AND recruiter_id = $2';
      queryParams.push(req.user.id);
    } else {
      whereClause += ' AND candidate_id = $2';
      queryParams.push(req.user.id);
    }

    // Build update query based on user role
    let updateFields = [];
    let updateParams = [];
    let paramCount = queryParams.length;

    if (req.user.role === 'recruiter') {
      if (interview_type) {
        paramCount++;
        updateFields.push(`interview_type = $${paramCount}`);
        updateParams.push(interview_type);
      }
      if (scheduled_date) {
        paramCount++;
        updateFields.push(`scheduled_date = $${paramCount}`);
        updateParams.push(scheduled_date);
      }
      if (duration_minutes) {
        paramCount++;
        updateFields.push(`duration_minutes = $${paramCount}`);
        updateParams.push(duration_minutes);
      }
      if (meeting_link !== undefined) {
        paramCount++;
        updateFields.push(`meeting_link = $${paramCount}`);
        updateParams.push(meeting_link);
      }
      if (location !== undefined) {
        paramCount++;
        updateFields.push(`location = $${paramCount}`);
        updateParams.push(location);
      }
      if (status) {
        paramCount++;
        updateFields.push(`status = $${paramCount}`);
        updateParams.push(status);
      }
      if (interviewer_notes !== undefined) {
        paramCount++;
        updateFields.push(`interviewer_notes = $${paramCount}`);
        updateParams.push(interviewer_notes);
      }
      if (rating) {
        paramCount++;
        updateFields.push(`rating = $${paramCount}`);
        updateParams.push(rating);
      }
    } else {
      // Candidates can only update feedback
      if (candidate_feedback !== undefined) {
        paramCount++;
        updateFields.push(`candidate_feedback = $${paramCount}`);
        updateParams.push(candidate_feedback);
      }
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);

    const updateQuery = `
      UPDATE interviews 
      SET ${updateFields.join(', ')}
      WHERE ${whereClause}
      RETURNING *
    `;

    const result = await pool.query(updateQuery, [...queryParams, ...updateParams]);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found or unauthorized'
      });
    }

    res.json({
      success: true,
      message: 'Interview updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Interview update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update interview'
    });
  }
});

// Cancel interview
router.delete('/:id', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const result = await pool.query(
      `UPDATE interviews 
       SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
       WHERE id = $1 AND recruiter_id = $2
       RETURNING id`,
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Interview not found or unauthorized'
      });
    }

    res.json({
      success: true,
      message: 'Interview cancelled successfully'
    });

  } catch (error) {
    console.error('Interview cancellation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to cancel interview'
    });
  }
});

export default router;