import express from 'express';
import {
//   createJob,
  getAllJobs,
  postJob,
  updateJob,
  deleteJob,
  getUserApplications,
  applyForJob,
  getJobById, getAllJobsForRecommendations,
  updateUser, getUser
} from '../controllers/jobController.js'; // ✅ All ES imports

const router = express.Router();
// router.post('/', createJob);  



// Route handlers
router.get('/jobs/all', getAllJobs);      // GET → /api/jobs/all
router.post('/jobs/add', postJob);        // POST → /api/jobs/add
       // POST → /api/jobs
router.put('/jobs/:id', updateJob);
router.delete('/jobs/:id', deleteJob); 

router.get('/jobs/:id', getUserApplications);
router.post('/jobs/applications', applyForJob);
router.get('/jobs/details/:id', getJobById); 
router.get('/jobs/cand-recommendations', getAllJobsForRecommendations); 
router.get('/users/:id', getUser); 
router.put('/users/:id', updateUser); 


export default router;



