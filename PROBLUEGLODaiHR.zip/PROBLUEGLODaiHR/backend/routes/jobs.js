// import express from 'express';
// import { body, validationResult } from 'express-validator';
// import pool from '../config/database.js';
// import { authenticateToken, requireRole } from '../middleware/auth.js';


// const router = express.Router();

// // Create job (Recruiters only)
// router.post('/', authenticateRecruiter, async (req, res) => {
//   const { title, description, skills, experience, location } = req.body;
//   const job = await pool.query(`
//     INSERT INTO jobs (title, description, skills, experience, location, recruiter_id)
//     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
//     [title, description, skills, experience, location, req.user.id]);
//   res.status(201).json(job.rows[0]);
// });

//     }

//     const {
//       title, description, requirements, skills, experience_level,
//       job_type, location, salary_min, salary_max, currency,
//       department, application_deadline
//     } = req.body;

//     const result = await pool.query(
//       `INSERT INTO jobs (
//         recruiter_id, title, description, requirements, skills, experience_level,
//         job_type, location, salary_min, salary_max, currency, department, application_deadline
//       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
//       RETURNING *`,
//       [
//         req.user.id, title, description, requirements, skills, experience_level,
//         job_type, location, salary_min, salary_max, currency, department, application_deadline
//       ]
//     );

//     res.status(201).json({
//       success: true,
//       message: 'Job created successfully',
//       data: result.rows[0]
//     });

//   } catch (error) {
//     console.error('Job creation error:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Failed to create job'
//     });
//   }
// });

import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../config/database.js';
import { authenticateToken , requireRole} from '../middleware/auth.js';

const router = express.Router();

// Middleware to allow only recruiters
const authenticateRecruiter = (req, res, next) => {
  authenticateToken(req, res, () => {
    if (req.user.role !== 'recruiter') {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }
    next();
  });
};

// POST /jobs - Create a job (Recruiters only)
router.post(
  '/',
  authenticateRecruiter,
  [
    body('title').notEmpty().withMessage('Title is required'),
    body('description').notEmpty().withMessage('Description is required'),
    body('skills').notEmpty().withMessage('Skills are required'),
    body('experience_level').notEmpty().withMessage('Experience level is required'),
    body('job_type').notEmpty().withMessage('Job type is required'),
    body('location').notEmpty().withMessage('Location is required'),
    body('salary_min').isNumeric().withMessage('Minimum salary must be a number'),
    body('salary_max').isNumeric().withMessage('Maximum salary must be a number'),
    body('currency').notEmpty().withMessage('Currency is required'),
    body('application_deadline').notEmpty().withMessage('Application deadline is required'),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    try {
      const {
        title,
        description,
        requirements,
        skills,
        experience_level,
        job_type,
        location,
        salary_min,
        salary_max,
        currency,
        department,
        application_deadline,
      } = req.body;

      const result = await pool.query(
        `INSERT INTO jobs (
          recruiter_id, title, description, requirements, skills, experience_level,
          job_type, location, salary_min, salary_max, currency, department, application_deadline
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING *`,
        [
          req.user.id,
          title,
          description,
          requirements,
          skills,
          experience_level,
          job_type,
          location,
          salary_min,
          salary_max,
          currency,
          department,
          application_deadline,
        ]
      );

      res.status(201).json({
        success: true,
        message: 'Job created successfully',
        data: result.rows[0],
      });
    } catch (error) {
      console.error('Job creation error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to create job',
      });
    }
  }
);



// // Get all jobs (with filters)
// router.get('/', async (req, res) => {
//   try {
//     const {
//       page = 1,
//       limit = 10,
//       job_type,
//       location,
//       experience_level,
//       skills,
//       salary_min,
//       salary_max,
//       search
//     } = req.query;

//     const offset = (page - 1) * limit;
//     let whereConditions = ['j.is_active = true'];
//     let queryParams = [];
//     let paramCount = 0;

//     // Build dynamic WHERE clause
//     if (job_type) {
//       paramCount++;
//       whereConditions.push(`j.job_type = $${paramCount}`);
//       queryParams.push(job_type);
//     }

//     if (location) {
//       paramCount++;
//       whereConditions.push(`j.location ILIKE $${paramCount}`);
//       queryParams.push(`%${location}%`);
//     }

//     if (experience_level) {
//       paramCount++;
//       whereConditions.push(`j.experience_level = $${paramCount}`);
//       queryParams.push(experience_level);
//     }

//     if (skills) {
//       paramCount++;
//       whereConditions.push(`j.skills && $${paramCount}`);
//       queryParams.push(Array.isArray(skills) ? skills : [skills]);
//     }

//     if (salary_min) {
//       paramCount++;
//       whereConditions.push(`j.salary_max >= $${paramCount}`);
//       queryParams.push(parseInt(salary_min));
//     }

//     if (salary_max) {
//       paramCount++;
//       whereConditions.push(`j.salary_min <= $${paramCount}`);
//       queryParams.push(parseInt(salary_max));
//     }

//     if (search) {
//       paramCount++;
//       whereConditions.push(`(j.title ILIKE $${paramCount} OR j.description ILIKE $${paramCount})`);
//       queryParams.push(`%${search}%`);
//     }

//     const whereClause = whereConditions.join(' AND ');

//     // Get jobs with recruiter info
//     const jobsQuery = `
//       SELECT j.*, 
//              u.first_name as recruiter_first_name, 
//              u.last_name as recruiter_last_name,
//              u.company as recruiter_company,
//              (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) as application_count
//       FROM jobs j
//       JOIN users u ON j.recruiter_id = u.id
//       WHERE ${whereClause}
//       ORDER BY j.created_at DESC
//       LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
//     `;

//     queryParams.push(parseInt(limit), offset);

//     const result = await pool.query(jobsQuery, queryParams);

//     // Get total count
//     const countQuery = `
//       SELECT COUNT(*) as total
//       FROM jobs j
//       WHERE ${whereClause}
//     `;

//     const countResult = await pool.query(countQuery, queryParams.slice(0, -2));
//     const total = parseInt(countResult.rows[0].total);

//     res.json({
//       success: true,
//       data: {
//         jobs: result.rows,
//         pagination: {
//           current_page: parseInt(page),
//           total_pages: Math.ceil(total / limit),
//           total_jobs: total,
//           per_page: parseInt(limit)
//         }
//       }
//     });

//   } catch (error) {
//     console.error('Jobs fetch error:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Failed to fetch jobs'
//     });
//   }
// });

// // Get single job
// router.get('/:id', async (req, res) => {
//   try {
//     const result = await pool.query(
//       `SELECT j.*, 
//               u.first_name as recruiter_first_name, 
//               u.last_name as recruiter_last_name,
//               u.company as recruiter_company,
//               u.email as recruiter_email,
//               (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) as application_count
//        FROM jobs j
//        JOIN users u ON j.recruiter_id = u.id
//        WHERE j.id = $1 AND j.is_active = true`,
//       [req.params.id]
//     );

//     if (result.rows.length === 0) {
//       return res.status(404).json({
//         success: false,
//         message: 'Job not found'
//       });
//     }

//     res.json({
//       success: true,
//       data: result.rows[0]
//     });

//   } catch (error) {
//     console.error('Job fetch error:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Failed to fetch job'
//     });
//   }
// });

// Update job (Recruiter only - own jobs)
router.put('/:id', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const {
      title, description, requirements, skills, experience_level,
      job_type, location, salary_min, salary_max, currency,
      department, application_deadline, is_active
    } = req.body;

    const result = await pool.query(
      `UPDATE jobs SET 
        title = $1, description = $2, requirements = $3, skills = $4,
        experience_level = $5, job_type = $6, location = $7, salary_min = $8,
        salary_max = $9, currency = $10, department = $11, application_deadline = $12,
        is_active = $13, updated_at = CURRENT_TIMESTAMP
       WHERE id = $14 AND recruiter_id = $15
       RETURNING *`,
      [
        title, description, requirements, skills, experience_level,
        job_type, location, salary_min, salary_max, currency,
        department, application_deadline, is_active,
        req.params.id, req.user.id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Job not found or unauthorized'
      });
    }

    res.json({
      success: true,
      message: 'Job updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Job update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update job'
    });
  }
});

// Delete job (Recruiter only - own jobs)
router.delete('/:id', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM jobs WHERE id = $1 AND recruiter_id = $2 RETURNING id',
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Job not found or unauthorized'
      });
    }

    res.json({
      success: true,
      message: 'Job deleted successfully'
    });

  } catch (error) {
    console.error('Job deletion error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete job'
    });
  }
});

// Get recruiter's jobs
router.get('/recruiter/my-jobs', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    const { page = 1, limit = 10, status = 'all' } = req.query;
    const offset = (page - 1) * limit;

    let whereClause = 'recruiter_id = $1';
    let queryParams = [req.user.id];

    if (status !== 'all') {
      whereClause += ' AND is_active = $2';
      queryParams.push(status === 'active');
    }

    const result = await pool.query(
      `SELECT j.*,
              (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) as application_count,
              (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id AND a.status = 'shortlisted') as shortlisted_count
       FROM jobs j
       WHERE ${whereClause}
       ORDER BY j.created_at DESC
       LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}`,
      [...queryParams, parseInt(limit), offset]
    );

    // Get total count
    const countResult = await pool.query(
      `SELECT COUNT(*) as total FROM jobs WHERE ${whereClause}`,
      queryParams
    );

    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        jobs: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_jobs: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Recruiter jobs fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch jobs'
    });
  }
});

export default router;