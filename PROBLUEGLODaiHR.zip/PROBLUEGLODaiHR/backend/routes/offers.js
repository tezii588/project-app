import express from 'express';
import { body, validationResult } from 'express-validator';
import pool from '../config/database.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import upload from '../middleware/upload.js';
import nodemailer from 'nodemailer';

const router = express.Router();

// Configure email transporter
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Create offer letter (Recruiters only)
router.post('/', authenticateToken, requireRole(['recruiter']), upload.single('offer_letter'), [
  body('application_id').isUUID(),
  body('offer_amount').isInt({ min: 1 }),
  body('start_date').isISO8601(),
  body('response_deadline').optional().isISO8601()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const {
      application_id, offer_amount, currency = 'USD', start_date,
      benefits, terms_conditions, response_deadline
    } = req.body;

    const offer_letter_url = req.file ? `/uploads/offers/${req.file.filename}` : null;

    // Verify application belongs to recruiter's job
    const applicationResult = await pool.query(
      `SELECT a.id, a.candidate_id, a.job_id, j.recruiter_id, j.title as job_title
       FROM applications a
       JOIN jobs j ON a.job_id = j.id
       WHERE a.id = $1 AND j.recruiter_id = $2`,
      [application_id, req.user.id]
    );

    if (applicationResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Application not found or unauthorized'
      });
    }

    const application = applicationResult.rows[0];

    // Check if offer already exists for this application
    const existingOffer = await pool.query(
      'SELECT id FROM offer_letters WHERE application_id = $1',
      [application_id]
    );

    if (existingOffer.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Offer letter already exists for this application'
      });
    }

    // Create offer letter
    const result = await pool.query(
      `INSERT INTO offer_letters (
        application_id, recruiter_id, candidate_id, job_id,
        offer_amount, currency, start_date, benefits, terms_conditions,
        offer_letter_url, response_deadline
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *`,
      [
        application_id, req.user.id, application.candidate_id, application.job_id,
        offer_amount, currency, start_date, benefits, terms_conditions,
        offer_letter_url, response_deadline
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Offer letter created successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Offer creation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create offer letter'
    });
  }
});

// Send offer letter (Recruiters only)
router.post('/:id/send', authenticateToken, requireRole(['recruiter']), async (req, res) => {
  try {
    // Get offer details
    const offerResult = await pool.query(
      `SELECT ol.*, j.title as job_title,
              c.first_name, c.last_name, c.email as candidate_email,
              r.first_name as recruiter_first_name, r.last_name as recruiter_last_name,
              r.company as recruiter_company
       FROM offer_letters ol
       JOIN jobs j ON ol.job_id = j.id
       JOIN users c ON ol.candidate_id = c.id
       JOIN users r ON ol.recruiter_id = r.id
       WHERE ol.id = $1 AND ol.recruiter_id = $2`,
      [req.params.id, req.user.id]
    );

    if (offerResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Offer letter not found or unauthorized'
      });
    }

    const offer = offerResult.rows[0];

    // Update offer status to sent
    await pool.query(
      'UPDATE offer_letters SET status = \'sent\', sent_at = CURRENT_TIMESTAMP WHERE id = $1',
      [req.params.id]
    );

    // Send email (if email configuration is available)
    if (process.env.EMAIL_USER && process.env.EMAIL_PASS) {
      try {
        const mailOptions = {
          from: process.env.EMAIL_USER,
          to: offer.candidate_email,
          subject: `Job Offer - ${offer.job_title} at ${offer.recruiter_company}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #2c3e50;">Congratulations! Job Offer</h2>
              
              <p>Dear ${offer.first_name} ${offer.last_name},</p>
              
              <p>We are pleased to offer you the position of <strong>${offer.job_title}</strong> at ${offer.recruiter_company}.</p>
              
              <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
                <h3 style="margin-top: 0;">Offer Details:</h3>
                <ul style="list-style: none; padding: 0;">
                  <li><strong>Position:</strong> ${offer.job_title}</li>
                  <li><strong>Salary:</strong> ${offer.currency} ${offer.offer_amount.toLocaleString()}</li>
                  <li><strong>Start Date:</strong> ${new Date(offer.start_date).toLocaleDateString()}</li>
                  ${offer.benefits ? `<li><strong>Benefits:</strong> ${offer.benefits}</li>` : ''}
                </ul>
              </div>
              
              ${offer.terms_conditions ? `
                <div style="margin: 20px 0;">
                  <h3>Terms & Conditions:</h3>
                  <p>${offer.terms_conditions}</p>
                </div>
              ` : ''}
              
              <p>Please review the offer and let us know your decision by ${offer.response_deadline ? new Date(offer.response_deadline).toLocaleDateString() : 'your earliest convenience'}.</p>
              
              <p>We look forward to having you join our team!</p>
              
              <p>Best regards,<br>
              ${offer.recruiter_first_name} ${offer.recruiter_last_name}<br>
              ${offer.recruiter_company}</p>
            </div>
          `
        };

        await transporter.sendMail(mailOptions);
      } catch (emailError) {
        console.error('Email sending error:', emailError);
        // Don't fail the request if email fails
      }
    }

    res.json({
      success: true,
      message: 'Offer letter sent successfully'
    });

  } catch (error) {
    console.error('Offer sending error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to send offer letter'
    });
  }
});

// Get offers (role-based)
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const offset = (page - 1) * limit;

    let whereConditions = [];
    let queryParams = [];
    let paramCount = 0;

    // Role-based filtering
    if (req.user.role === 'recruiter') {
      paramCount++;
      whereConditions.push(`ol.recruiter_id = $${paramCount}`);
      queryParams.push(req.user.id);
    } else {
      paramCount++;
      whereConditions.push(`ol.candidate_id = $${paramCount}`);
      queryParams.push(req.user.id);
    }

    // Status filter
    if (status) {
      paramCount++;
      whereConditions.push(`ol.status = $${paramCount}`);
      queryParams.push(status);
    }

    const whereClause = whereConditions.join(' AND ');

    const offersQuery = `
      SELECT ol.*,
             j.title as job_title,
             c.first_name as candidate_first_name, c.last_name as candidate_last_name,
             c.email as candidate_email,
             r.first_name as recruiter_first_name, r.last_name as recruiter_last_name,
             r.company as recruiter_company
      FROM offer_letters ol
      JOIN jobs j ON ol.job_id = j.id
      JOIN users c ON ol.candidate_id = c.id
      JOIN users r ON ol.recruiter_id = r.id
      WHERE ${whereClause}
      ORDER BY ol.created_at DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `;

    queryParams.push(parseInt(limit), offset);

    const result = await pool.query(offersQuery, queryParams);

    // Get total count
    const countQuery = `
      SELECT COUNT(*) as total
      FROM offer_letters ol
      WHERE ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams.slice(0, -2));
    const total = parseInt(countResult.rows[0].total);

    res.json({
      success: true,
      data: {
        offers: result.rows,
        pagination: {
          current_page: parseInt(page),
          total_pages: Math.ceil(total / limit),
          total_offers: total,
          per_page: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Offers fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch offers'
    });
  }
});

// Get single offer
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    let whereClause = 'ol.id = $1';
    let queryParams = [req.params.id];

    // Role-based access control
    if (req.user.role === 'recruiter') {
      whereClause += ' AND ol.recruiter_id = $2';
      queryParams.push(req.user.id);
    } else {
      whereClause += ' AND ol.candidate_id = $2';
      queryParams.push(req.user.id);
    }

    const result = await pool.query(
      `SELECT ol.*,
              j.title as job_title, j.description as job_description,
              c.first_name as candidate_first_name, c.last_name as candidate_last_name,
              c.email as candidate_email, c.phone as candidate_phone,
              r.first_name as recruiter_first_name, r.last_name as recruiter_last_name,
              r.company as recruiter_company, r.email as recruiter_email
       FROM offer_letters ol
       JOIN jobs j ON ol.job_id = j.id
       JOIN users c ON ol.candidate_id = c.id
       JOIN users r ON ol.recruiter_id = r.id
       WHERE ${whereClause}`,
      queryParams
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Offer letter not found or unauthorized'
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Offer fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch offer'
    });
  }
});

// Respond to offer (Candidates only)
router.put('/:id/respond', authenticateToken, requireRole(['candidate']), [
  body('status').isIn(['accepted', 'rejected']),
  body('candidate_response').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { status, candidate_response } = req.body;

    const result = await pool.query(
      `UPDATE offer_letters 
       SET status = $1, candidate_response = $2, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3 AND candidate_id = $4 AND status = 'sent'
       RETURNING *`,
      [status, candidate_response, req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Offer not found, unauthorized, or already responded'
      });
    }

    // If accepted, update application status to hired
    if (status === 'accepted') {
      await pool.query(
        `UPDATE applications 
         SET status = 'hired', updated_at = CURRENT_TIMESTAMP
         WHERE id = (SELECT application_id FROM offer_letters WHERE id = $1)`,
        [req.params.id]
      );
    }

    res.json({
      success: true,
      message: `Offer ${status} successfully`,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Offer response error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to respond to offer'
    });
  }
});

// Update offer (Recruiters only)
router.put('/:id', authenticateToken, requireRole(['recruiter']), upload.single('offer_letter'), async (req, res) => {
  try {
    const {
      offer_amount, currency, start_date, benefits,
      terms_conditions, response_deadline
    } = req.body;

    const offer_letter_url = req.file ? `/uploads/offers/${req.file.filename}` : null;

    let updateFields = [];
    let updateParams = [];
    let paramCount = 0;

    if (offer_amount) {
      paramCount++;
      updateFields.push(`offer_amount = $${paramCount}`);
      updateParams.push(offer_amount);
    }

    if (currency) {
      paramCount++;
      updateFields.push(`currency = $${paramCount}`);
      updateParams.push(currency);
    }

    if (start_date) {
      paramCount++;
      updateFields.push(`start_date = $${paramCount}`);
      updateParams.push(start_date);
    }

    if (benefits !== undefined) {
      paramCount++;
      updateFields.push(`benefits = $${paramCount}`);
      updateParams.push(benefits);
    }

    if (terms_conditions !== undefined) {
      paramCount++;
      updateFields.push(`terms_conditions = $${paramCount}`);
      updateParams.push(terms_conditions);
    }

    if (response_deadline !== undefined) {
      paramCount++;
      updateFields.push(`response_deadline = $${paramCount}`);
      updateParams.push(response_deadline);
    }

    if (offer_letter_url) {
      paramCount++;
      updateFields.push(`offer_letter_url = $${paramCount}`);
      updateParams.push(offer_letter_url);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);

    const updateQuery = `
      UPDATE offer_letters 
      SET ${updateFields.join(', ')}
      WHERE id = $${paramCount + 1} AND recruiter_id = $${paramCount + 2} AND status IN ('draft', 'sent')
      RETURNING *
    `;

    const result = await pool.query(updateQuery, [...updateParams, req.params.id, req.user.id]);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Offer not found, unauthorized, or cannot be updated'
      });
    }

    res.json({
      success: true,
      message: 'Offer updated successfully',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('Offer update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update offer'
    });
  }
});

export default router;