import pool, { testConnection } from '../config/database.js';

const createTables = async () => {
  // First test the connection
  console.log('🔍 Testing database connection...');
  const isConnected = await testConnection();
  
  if (!isConnected) {
    console.error('❌ Cannot connect to database. Please check your connection settings in .env file:');
    console.error('- DB_HOST: Make sure the database server is running and accessible');
    console.error('- DB_PORT: Verify the correct port (usually 5432 for PostgreSQL)');
    console.error('- DB_USER, DB_PASSWORD: Check credentials are correct');
    console.error('- DB_NAME: Ensure the database exists');
    throw new Error('Database connection failed');
  }

  const client = await pool.connect();
  
  try {
    console.log('🔧 Setting up AI4Hr database tables...');

    // Users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL CHECK (role IN ('recruiter', 'candidate')),
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        phone VARCHAR(20),
        company VARCHAR(255),
        profile_image VARCHAR(500),
        is_active BOOLEAN DEFAULT true,
        email_verified BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Jobs table
    await client.query(`
      CREATE TABLE IF NOT EXISTS jobs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        recruiter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        requirements TEXT,
        skills TEXT[] NOT NULL,
        experience_level VARCHAR(50) NOT NULL,
        job_type VARCHAR(50) NOT NULL CHECK (job_type IN ('full-time', 'part-time', 'contract', 'internship')),
        location VARCHAR(255) NOT NULL,
        salary_min INTEGER,
        salary_max INTEGER,
        currency VARCHAR(10) DEFAULT 'USD',
        department VARCHAR(100),
        is_active BOOLEAN DEFAULT true,
        application_deadline DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Candidate profiles table
    await client.query(`
      CREATE TABLE IF NOT EXISTS candidate_profiles (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        resume_url VARCHAR(500),
        skills TEXT[] NOT NULL DEFAULT '{}',
        experience_years INTEGER DEFAULT 0,
        current_position VARCHAR(255),
        current_company VARCHAR(255),
        education TEXT,
        certifications TEXT,
        portfolio_url VARCHAR(500),
        linkedin_url VARCHAR(500),
        github_url VARCHAR(500),
        summary TEXT,
        preferred_location VARCHAR(255),
        expected_salary INTEGER,
        availability_date DATE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Applications table
    await client.query(`
      CREATE TABLE IF NOT EXISTS applications (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        candidate_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        status VARCHAR(50) NOT NULL DEFAULT 'applied' 
          CHECK (status IN ('applied', 'under_review', 'shortlisted', 'interview_scheduled', 'hired', 'rejected')),
        cover_letter TEXT,
        resume_url VARCHAR(500),
        ai_match_score DECIMAL(5,2),
        ai_analysis TEXT,
        recruiter_notes TEXT,
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(job_id, candidate_id)
      )
    `);

    // Interviews table
    await client.query(`
      CREATE TABLE IF NOT EXISTS interviews (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        application_id UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
        recruiter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        candidate_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        interview_type VARCHAR(20) NOT NULL CHECK (interview_type IN ('video', 'in-person', 'phone')),
        scheduled_date TIMESTAMP NOT NULL,
        duration_minutes INTEGER DEFAULT 60,
        meeting_link VARCHAR(500),
        location VARCHAR(500),
        status VARCHAR(20) NOT NULL DEFAULT 'scheduled' 
          CHECK (status IN ('scheduled', 'completed', 'cancelled', 'rescheduled')),
        interviewer_notes TEXT,
        candidate_feedback TEXT,
        rating INTEGER CHECK (rating >= 1 AND rating <= 5),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Offer letters table
    await client.query(`
      CREATE TABLE IF NOT EXISTS offer_letters (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        application_id UUID NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
        recruiter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        candidate_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        offer_amount INTEGER NOT NULL,
        currency VARCHAR(10) DEFAULT 'USD',
        start_date DATE NOT NULL,
        benefits TEXT,
        terms_conditions TEXT,
        offer_letter_url VARCHAR(500),
        status VARCHAR(20) NOT NULL DEFAULT 'draft' 
          CHECK (status IN ('draft', 'sent', 'accepted', 'rejected', 'expired')),
        sent_at TIMESTAMP,
        response_deadline DATE,
        candidate_response TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // AI recommendations table
    await client.query(`
      CREATE TABLE IF NOT EXISTS ai_recommendations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        candidate_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        match_score DECIMAL(5,2) NOT NULL,
        reasoning TEXT NOT NULL,
        skills_match TEXT[],
        experience_match TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create indexes for better performance
    await client.query('CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_jobs_recruiter ON jobs(recruiter_id)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_jobs_active ON jobs(is_active)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_applications_job ON applications(job_id)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_applications_candidate ON applications(candidate_id)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_interviews_date ON interviews(scheduled_date)');
    await client.query('CREATE INDEX IF NOT EXISTS idx_offers_status ON offer_letters(status)');

    console.log('✅ Database tables created successfully!');
    
  } catch (error) {
    console.error('❌ Error creating tables:', error);
    throw error;
  } finally {
    client.release();
  }
};

// Run the setup
createTables()
  .then(() => {
    console.log('🎉 Database setup completed!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Database setup failed:', error.message);
    process.exit(1);
  });