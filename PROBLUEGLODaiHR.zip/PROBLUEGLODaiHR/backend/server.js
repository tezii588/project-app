import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import jobRoutes from './routes/jobRoutes.js';
import applyRoutes from './routes/apply.js';
import RecruiterRoutes from './routes/RecruiterRoutes.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use('/api', jobRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/apply', applyRoutes);
app.use('/api', RecruiterRoutes);
// app.use(jobRoutes); // 🔥 register the job routes

app.listen(process.env.PORT, () => {
  console.log(`✅ Server running on port ${process.env.PORT}`);
});
