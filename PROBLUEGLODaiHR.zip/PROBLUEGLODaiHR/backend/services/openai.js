const OPENAI_API_KEY = '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';

export const generateJobDescription = async (jobData) => {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an expert HR professional and technical recruiter. Generate professional, comprehensive job descriptions that are engaging and attract top talent.'
          },
          {
            role: 'user',
            content: `Generate a professional job description for the following position:

Title: ${jobData.title}
Department: ${jobData.department || 'Not specified'}
Requirements: ${jobData.requirements}
Responsibilities: ${jobData.responsibilities || 'Not specified'}

Please create a comprehensive job description that includes:
- A compelling overview of the role
- Key responsibilities (expand on what was provided)
- Required qualifications and skills
- Preferred qualifications
- What we offer section
- Company culture highlights

Make it professional, engaging, and optimized for attracting quality candidates.`
          }
        ],
        max_tokens: 1000,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Error generating job description:', error);
    
    // Fallback job description template
    return `
# ${jobData.title}

## About This Role
We are seeking a talented ${jobData.title} to join our ${jobData.department || 'dynamic'} team. This is an exciting opportunity to work with cutting-edge technologies and make a significant impact on our products and services.

## Key Responsibilities
${jobData.responsibilities || `
• Lead development of high-quality software solutions
• Collaborate with cross-functional teams to deliver exceptional products
• Mentor junior team members and contribute to technical decisions
• Participate in code reviews and maintain high coding standards
`}

## Required Qualifications
${jobData.requirements || `
• Bachelor's degree in Computer Science or related field
• 3+ years of relevant experience
• Strong problem-solving and communication skills
• Experience with modern development practices
`}

## What We Offer
• Competitive salary and benefits package
• Flexible work arrangements
• Professional development opportunities
• Collaborative and innovative work environment
• Opportunity to work on challenging and meaningful projects

Join our team and help shape the future of technology!
    `.trim();
  }
};

export const analyzeResume = async (resumeText, jobDescription) => {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an expert ATS system and recruitment specialist. Analyze resumes against job descriptions and provide detailed scoring and recommendations.'
          },
          {
            role: 'user',
            content: `Analyze this resume against the job description and provide a detailed assessment:

RESUME:
${resumeText}

JOB DESCRIPTION:
${jobDescription}

Please provide:
1. Overall match score (0-100)
2. Skills alignment score
3. Experience relevance score
4. Education fit score
5. Key strengths
6. Areas for improvement
7. Missing skills/qualifications
8. Recommendations for the candidate

Format as JSON.`
          }
        ],
        max_tokens: 1500,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return JSON.parse(data.choices[0].message.content);
  } catch (error) {
    console.error('Error analyzing resume:', error);
    throw error;
  }
};

export const generateCoverLetter = async (candidateProfile, jobDescription) => {
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are an expert career counselor and professional writer. Generate compelling, personalized cover letters that highlight relevant experience and skills.'
          },
          {
            role: 'user',
            content: `Generate a professional cover letter based on:

CANDIDATE PROFILE:
${JSON.stringify(candidateProfile)}

JOB DESCRIPTION:
${jobDescription}

Create a compelling cover letter that:
- Addresses the specific role and company
- Highlights relevant experience and achievements
- Shows enthusiasm for the position
- Demonstrates knowledge of the company/industry
- Includes a strong opening and closing
- Is professional yet personable
- Is approximately 3-4 paragraphs long`
          }
        ],
        max_tokens: 800,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('Error generating cover letter:', error);
    throw error;
  }
};