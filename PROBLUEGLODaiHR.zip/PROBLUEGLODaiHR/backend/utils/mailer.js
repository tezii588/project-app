import nodemailer from 'nodemailer';
import pool from '../config/database.js'; // PostgreSQL config

export const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Helper to fetch recruiter email by jobId
export const getRecruiterByJobId = async (jobId) => {
  const result = await pool.query(`
    SELECT u.email FROM jobs j
    JOIN users u ON j.recruiter_id = u.id
    WHERE j.id = $1`, [jobId]);
  return result.rows[0];
};

// Main function
export const sendEmailToRecruiter = async (jobId, candidateId) => {
  const recruiter = await getRecruiterByJobId(jobId);
  if (!recruiter || !recruiter.email) return;

  await transporter.sendMail({
    from: '"AI4Hr" <no-reply@ai4hr.com>',
    to: recruiter.email,
    subject: '📩 New Job Application Received',
    text: `A new candidate has applied to your job post on AI4Hr!`
  });
};
