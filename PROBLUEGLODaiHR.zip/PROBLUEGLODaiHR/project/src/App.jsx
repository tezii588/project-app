// // import React, { useState } from 'react';
// // import Layout from './components/Layout';
// // import Login from './components/Login';
// // import Dashboard from './components/Dashboard'; 
// // import PostJob from './components/PostJob';
// // import Recommendations from './components/Recommendations';
// // import Shortlist from './components/Shortlist';
// // import Interviews from './components/Interviews';
// // import Offers from './components/Offers';
// // import { NavigationPages } from './types';

// // function App() {
// //   const [currentPage, setCurrentPage] = useState(NavigationPages.LOGIN);

// //   const handleNavigate = (page) => {
// //     setCurrentPage(page);
// //   };

// //   const renderCurrentPage = () => {
// //     switch (currentPage) {
// //       case NavigationPages.LOGIN:
// //         return <Login onNavigate={handleNavigate} />;
// //       case NavigationPages.DASHBOARD:
// //         return <Dashboard onNavigate={handleNavigate} />;
// //       case NavigationPages.POST_JOB:
// //         return <PostJob />;
// //       case NavigationPages.RECOMMENDATIONS:
// //         return <Recommendations onNavigate={handleNavigate} />;
// //       case NavigationPages.SHORTLIST:
// //         return <Shortlist onNavigate={handleNavigate} />;
// //       case NavigationPages.INTERVIEWS:
// //         return <Interviews />;
// //       case NavigationPages.OFFERS:
// //         return <Offers />;
// //       default:
// //         return <Dashboard onNavigate={handleNavigate} />;
// //     }
// //   };

// //   if (currentPage === NavigationPages.LOGIN) {
// //     return renderCurrentPage();
// //   }

// //   return (
// //     <Layout currentPage={currentPage} onNavigate={handleNavigate}>
// //       {renderCurrentPage()}
// //     </Layout>
// //   );
// // }

// // export default App;

// import React, { useState } from 'react';
// import { Routes, Route, BrowserRouter, Navigate } from 'react-router-dom';

// // Public Web UI
// import Navbar from './website/webcomponents/Navbar.jsx';
// import Hero from './website/webcomponents/Hero.jsx';
// import AIFeatures from './website/webcomponents/AIFeatures.jsx';
// import JobPortal from './website/webcomponents/JobPortal.jsx';
// import Testimonials from './website/webcomponents/Testimonials.jsx';
// import Blog from './website/webcomponents/Blog.jsx';
// import Newsletter from './website/webcomponents/Newsletter.jsx';
// import Footer from './website/webcomponents/Footer.jsx';
// import ResumeBuilder from './website/webcomponents/ResumeBuilder.jsx';
// import CandidateDashboard from './website/webcomponents/CandidateDashboard.jsx';
// import RecruiterDashboard from './website/webcomponents/RecruiterDashboard.jsx';


// // Dashboard App
// import Layout from './components/Layout.jsx';
// import Login from './components/Login.jsx';
// import Dashboard from './components/Dashboard.jsx';
// import PostJob from './components/PostJob.jsx';
// import Recommendations from './components/Recommendations.jsx';
// import Shortlist from './components/Shortlist.jsx';
// import Interviews from './components/Interviews.jsx';
// import Offers from './components/Offers.jsx';

// // Types (assumes NavigationPages is an enum or object)
// import { NavigationPages } from './types/index.js';

// function App() {
//   const [currentPage, setCurrentPage] = useState(NavigationPages.LOGIN);
//   const [isAuthenticated, setIsAuthenticated] = useState(false);

//   const handleNavigate = (page) => {
//     setCurrentPage(page);
//   };

//   const handleLoginSuccess = () => {
//     setIsAuthenticated(true);
//     setCurrentPage(NavigationPages.DASHBOARD);
//   };

//   const renderCurrentDashboardPage = () => {
//     switch (currentPage) {
//       case NavigationPages.LOGIN:
//         return <Login onLoginSuccess={handleLoginSuccess} onNavigate={handleNavigate} />;
//       case NavigationPages.DASHBOARD:
//         return <Dashboard onNavigate={handleNavigate} />;
//       case NavigationPages.POST_JOB:
//         return <PostJob />;
//       case NavigationPages.RECOMMENDATIONS:
//         return <Recommendations onNavigate={handleNavigate} />;
//       case NavigationPages.SHORTLIST:
//         return <Shortlist onNavigate={handleNavigate} />;
//       case NavigationPages.INTERVIEWS:
//         return <Interviews />;
//       case NavigationPages.OFFERS:
//         return <Offers />;
//       default:
//         return <Dashboard onNavigate={handleNavigate} />;
//     }
//   };

//   return (
//     <BrowserRouter>
//       {!isAuthenticated ? (
//         // 🌐 Public Website View
//         <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
//           <Navbar />
//           <Routes>
//             <Route
//               path="/"
//               element={
//                 <main>
//                   <Hero />
//                   <AIFeatures />
//                   <JobPortal />
//                   <Testimonials />
//                   <Blog />
//                   <Newsletter />
//                 </main>
//               }
//             />
//             <Route path="/candidate-dashboard" element={<CandidateDashboard />} />
// <Route path="/recruiter-dashboard" element={<RecruiterDashboard />} />

//             <Route path="/resume-builder" element={<ResumeBuilder />} />
//             <Route path="/login" element={<Login onLoginSuccess={handleLoginSuccess} />} />
//             <Route path="*" element={<Navigate to="/" />} />
//           </Routes>
//           <Footer />
//         </div>
//       ) : (
//         // 🔐 Dashboard View After Login
//         <>
//           {currentPage === NavigationPages.LOGIN ? (
//             renderCurrentDashboardPage()
//           ) : (
//             <Layout currentPage={currentPage} onNavigate={handleNavigate}>
//               {renderCurrentDashboardPage()}
//             </Layout>
//           )}
//         </>
//       )}
//     </BrowserRouter>
//   );
// }

// export default App;


// import React, { useState } from 'react';
// import { Routes, Route, BrowserRouter, Navigate } from 'react-router-dom';

// // Website Components
// import Navbar from './website/webcomponents/Navbar.jsx';
// import Hero from './website/webcomponents/Hero.jsx';
// import AIFeatures from './website/webcomponents/AIFeatures.jsx';
// import JobPortal from './website/webcomponents/JobPortal.jsx';
// import Testimonials from './website/webcomponents/Testimonials.jsx';
// import Blog from './website/webcomponents/Blog.jsx';
// import Newsletter from './website/webcomponents/Newsletter.jsx';
// import Footer from './website/webcomponents/Footer.jsx';
// import ResumeBuilder from './website/webcomponents/ResumeBuilder.jsx';
// // import CandidateDashboard from './website/webcomponents/CandidateDashboard.jsx';
// // import RecruiterDashboard from './website/webcomponents/RecruiterDashboard.jsx';

// // Dashboard App Components
// import Layout from './components/Layout.jsx';
// import AuthPage from "./components/AuthPage"; 
// import Login from './components/copy.jsx';
// import Dashboard from './components/Dashboard.jsx';
// import PostJob from './components/PostJob.jsx';
// import Recommendations from './components/Recommendations.jsx';
// import Shortlist from './components/Shortlist.jsx';
// import Interviews from './components/Interviews.jsx';
// import Offers from './components/Offers.jsx';
// import CandidateDashboard from './candidate/candidate-dashboard';
// // Enums
// import { NavigationPages } from './types/index.js';

// function App() {
//   const [isAuthenticated, setIsAuthenticated] = useState(false);
//   const [currentPage, setCurrentPage] = useState(NavigationPages.LOGIN);

//   const handleLoginSuccess = () => {
//     setIsAuthenticated(true);
//     setCurrentPage(NavigationPages.DASHBOARD);
//   };

//   const handleNavigate = (page) => {
//     setCurrentPage(page);
//   };

//   const renderCurrentDashboardPage = () => {
//     switch (currentPage) {
//       case NavigationPages.LOGIN:
//         return <Login onLoginSuccess={handleLoginSuccess} onNavigate={handleNavigate} />;
//       case NavigationPages.DASHBOARD:
//         return <Dashboard onNavigate={handleNavigate} />;
//       case NavigationPages.POST_JOB:
//         return <PostJob />;
//       case NavigationPages.RECOMMENDATIONS:
//         return <Recommendations onNavigate={handleNavigate} />;
//       case NavigationPages.SHORTLIST:
//         return <Shortlist onNavigate={handleNavigate} />;
//       case NavigationPages.INTERVIEWS:
//         return <Interviews onNavigate={handleNavigate} />;
//       case NavigationPages.OFFERS:
//         return <Offers />;
//       default:
//         return <Dashboard onNavigate={handleNavigate} />;
//     }
//   };

//   return (
//     <BrowserRouter>
//       <Routes>

//         {/* 🌐 Public Website */}
//         <Route
//           path="/"
//           element={
//             <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
//               <Navbar />
//               <main>
//                 <Hero />
//                 <AIFeatures />
//                 <JobPortal />
//                 <Testimonials />
//                 <Blog />
//                 <Newsletter />
//               </main>
//               <Footer />
//             </div>
//           }
//         />
// <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
// <Route path="/login" element={<AuthPage />} />
//         {/* 🎯 Standalone Pages */}
//         <Route path="/resume-builder" element={<ResumeBuilder />} />
//         {/* <Route path="/candidate-dashboard" element={<CandidateDashboard />} />
//         <Route path="/recruiter-dashboard" element={<RecruiterDashboard />} /> */}

//         {/* 🔐 Admin Dashboard Pages */}
//         <Route path="/login" element={<Login onLoginSuccess={handleLoginSuccess} />} />

//         {isAuthenticated ? (
//           <>
//             <Route path="/dashboard" element={<Layout currentPage={currentPage} onNavigate={handleNavigate}>{renderCurrentDashboardPage()}</Layout>} />
//             <Route path="/post-job" element={<Layout><PostJob /></Layout>} />
//             <Route path="/recommendations" element={<Layout><Recommendations /></Layout>} />
//             <Route path="/shortlist" element={<Layout><Shortlist /></Layout>} />
//             <Route path="/interviews" element={<Layout><Interviews /></Layout>} />
//             <Route path="/offers" element={<Layout><Offers /></Layout>} />
//           </>
//         ) : (
//           <>
//             <Route path="/dashboard" element={<Navigate to="/login" />} />
//             <Route path="/post-job" element={<Navigate to="/login" />} />
//             <Route path="/recommendations" element={<Navigate to="/login" />} />
//             <Route path="/shortlist" element={<Navigate to="/login" />} />
//             <Route path="/interviews" element={<Navigate to="/login" />} />
//             <Route path="/offers" element={<Navigate to="/login" />} />
//           </>
//         )}

//         {/* 🔁 Catch-all */}
//         <Route path="*" element={<Navigate to="/" />} />

//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;





// import React, { useState } from 'react';
// import { Routes, Route, BrowserRouter, Navigate } from 'react-router-dom';

// // Website Components
// import Navbar from './website/webcomponents/Navbar.jsx';
// import Hero from './website/webcomponents/Hero.jsx';
// import AIFeatures from './website/webcomponents/AIFeatures.jsx';
// import JobPortal from './website/webcomponents/JobPortal.jsx';
// import Testimonials from './website/webcomponents/Testimonials.jsx';
// import Blog from './website/webcomponents/Blog.jsx';
// import Newsletter from './website/webcomponents/Newsletter.jsx';
// import Footer from './website/webcomponents/Footer.jsx';
// import ResumeBuilder from './website/webcomponents/ResumeBuilder.jsx';

// // Dashboard App Components
// import Layout from './components/Layout.jsx';
// import AuthPage from "./components/AuthPage"; 
// import Login from './components/copy.jsx';
// import RecruiterDashboard from './recruiter/RecruiterDashboard.jsx';
// import PostJob from './components/PostJob.jsx';
// import Recommendations from './components/Recommendations.jsx';
// import Shortlist from './components/Shortlist.jsx';
// import Interviews from './components/Interviews.jsx';
// import Offers from './components/Offers.jsx';
// import CandidateDashboard from './candidate/CandidateDashboard.jsx';

// // Enums
// import { NavigationPages } from './types/index.js';

// function App() {
//   const [isAuthenticated, setIsAuthenticated] = useState(false);
//   const [currentPage, setCurrentPage] = useState(NavigationPages.LOGIN);

//   const handleLoginSuccess = () => {
//     setIsAuthenticated(true);
//     setCurrentPage(NavigationPages.DASHBOARD);
//   };

//   const handleNavigate = (page) => {
//     setCurrentPage(page);
//   };

//   const renderCurrentDashboardPage = () => {
//     switch (currentPage) {
//       case NavigationPages.LOGIN:
//         return <Login onLoginSuccess={handleLoginSuccess} onNavigate={handleNavigate} />;
//       case NavigationPages.DASHBOARD:
//         return <Dashboard onNavigate={handleNavigate} />;
//       case NavigationPages.POST_JOB:
//         return <PostJob />;
//       case NavigationPages.RECOMMENDATIONS:
//         return <Recommendations onNavigate={handleNavigate} />;
//       case NavigationPages.SHORTLIST:
//         return <Shortlist onNavigate={handleNavigate} />;
//       case NavigationPages.INTERVIEWS:
//         return <Interviews onNavigate={handleNavigate} />;
//       case NavigationPages.OFFERS:
//         return <Offers />;
//       default:
//         return <Dashboard onNavigate={handleNavigate} />;
//     }
//   };

//   return (
//     <BrowserRouter>
//       <Routes>

//         {/* 🌐 Public Website */}
//         <Route
//           path="/"
//           element={
//             <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
//               <Navbar />
//               <main>
//                 <Hero />
//                 <AIFeatures />
//                 <JobPortal />
//                 <Testimonials />
//                 <Blog />
//                 <Newsletter />
//               </main>
//               <Footer />
//             </div>
//           }
//         />
//         <Route path="/recruiter/dashboard" element={<RecruiterDashboard />} />


//         {/* 🎯 Standalone Pages */}
//         <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
//         <Route path="/resume-builder" element={<ResumeBuilder />} />
//         <Route path="/login" element={<AuthPage />} />

//         {/* 🔐 Admin Dashboard Pages */}
//         {isAuthenticated ? (
//           <>
//             <Route path="/dashboard" element={<Layout currentPage={currentPage} onNavigate={handleNavigate}>{renderCurrentDashboardPage()}</Layout>} />
//             <Route path="/post-job" element={<Layout><PostJob /></Layout>} />
//             <Route path="/recommendations" element={<Layout><Recommendations /></Layout>} />
//             <Route path="/shortlist" element={<Layout><Shortlist /></Layout>} />
//             <Route path="/interviews" element={<Layout><Interviews /></Layout>} />
//             <Route path="/offers" element={<Layout><Offers /></Layout>} />
//           </>
//         ) : (
//           <>
//             <Route path="/dashboard" element={<Navigate to="/login" />} />
//             <Route path="/post-job" element={<Navigate to="/login" />} />
//             <Route path="/recommendations" element={<Navigate to="/login" />} />
//             <Route path="/shortlist" element={<Navigate to="/login" />} />
//             <Route path="/interviews" element={<Navigate to="/login" />} />
//             <Route path="/offers" element={<Navigate to="/login" />} />
//           </>
//         )}

//         {/* 🔁 Catch-all */}
//         <Route path="*" element={<Navigate to="/" />} />

//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;

import React, { useState } from 'react';
import { Routes, Route, BrowserRouter, Navigate } from 'react-router-dom';

// Website Components
import Navbar from './website/webcomponents/Navbar.jsx';
import Hero from './website/webcomponents/Hero.jsx';
import AIFeatures from './website/webcomponents/AIFeatures.jsx';
import JobPortal from './website/webcomponents/JobPortal.jsx';
import Testimonials from './website/webcomponents/Testimonials.jsx';
import Blog from './website/webcomponents/Blog.jsx';
import Newsletter from './website/webcomponents/Newsletter.jsx';
import Footer from './website/webcomponents/Footer.jsx';
import ResumeBuilder from './website/webcomponents/ResumeBuilder.jsx';

// Dashboard App Components
import Layout from './components/Layout.jsx';
import AuthPage from './components/AuthPage.jsx';
import RecruiterDashboard from './recruiter/RecruiterDashboard.jsx';
import PostJob from './components/PostJob.jsx';
import Recommendations from './components/Recommendations.jsx';
import Shortlist from './components/Shortlist.jsx';
import Interviews from './components/Interviews.jsx';
import Offers from './components/Offers.jsx';
import CandidateDashboard from './candidate/CandidateDashboard.jsx';
import CandidateRecommendations  from "./candidate/CandidateRecommendations.jsx";
import JobBoard from "./candidate/JobBoard.jsx";
import SettingPage from "./candidate/SettingPage.jsx";
import CandidateProfile from "./candidate/CandidateProfile.jsx";

import RecruiterApplications from  "./recruiter/RecruiterApplications";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <BrowserRouter>
      <Routes>
        {/* 🌐 Public Website */}
        <Route
          path="/"
          element={
            <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
              <Navbar />
              <main>
                <Hero />
                <AIFeatures />
                <JobPortal />
                <Testimonials />
                <Blog />
                <Newsletter />
              </main>
              <Footer />
            </div>
          }
        />

        {/* 🎯 Standalone Pages */}
        <Route path="/resume-builder" element={<ResumeBuilder />} />
        <Route path="/applications" element={<JobBoard  />} />
        <Route path="/candidate-recommendations" element={<CandidateRecommendations  />} />
        <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
              <Route path="/settings" element={<SettingPage />} />
              <Route path="/profile" element={<CandidateProfile/>} />

        <Route path="/login" element={<AuthPage setIsAuthenticated={setIsAuthenticated} />} />

        {/* 🔐 Protected Recruiter Pages */}
        {/* {isAuthenticated ? ( */}
         {true ? (
          <>
            <Route path="/recruiter/dashboard" element={<Layout><RecruiterDashboard /></Layout>} />
            <Route path="/post-job" element={<Layout><PostJob /></Layout>} />
            <Route path="/recommendations" element={<Layout><Recommendations /></Layout>} />
            <Route path="/shortlist" element={<Layout><Shortlist /></Layout>} />
            <Route path="/interviews" element={<Layout><Interviews /></Layout>} />
            <Route path="/offers" element={<Layout><Offers /></Layout>} />
            <Route path="/recruiter-applications" element={<Layout><RecruiterApplications /></Layout>} />
          </>
        ) : (
          <>
            <Route path="/recruiter/dashboard" element={<Navigate to="/login" />} />
            <Route path="/post-job" element={<Navigate to="/login" />} />
            <Route path="/recommendations" element={<Navigate to="/login" />} />
            <Route path="/shortlist" element={<Navigate to="/login" />} />
            <Route path="/interviews" element={<Navigate to="/login" />} />
            <Route path="/offers" element={<Navigate to="/login" />} />
          </>
        )}

        {/* 🔁 Catch-all */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;


// import React, { useState } from 'react';
// import { Routes, Route, BrowserRouter, Navigate } from 'react-router-dom';

// // Website Components
// import Navbar from './website/webcomponents/Navbar.jsx';
// import Hero from './website/webcomponents/Hero.jsx';
// import AIFeatures from './website/webcomponents/AIFeatures.jsx';
// import JobPortal from './website/webcomponents/JobPortal.jsx';
// import Testimonials from './website/webcomponents/Testimonials.jsx';
// import Blog from './website/webcomponents/Blog.jsx';
// import Newsletter from './website/webcomponents/Newsletter.jsx';
// import Footer from './website/webcomponents/Footer.jsx';
// import ResumeBuilder from './website/webcomponents/ResumeBuilder.jsx';

// // Dashboard App Components
// import Layout from './components/Layout.jsx';
// import AuthPage from "./components/AuthPage"; 
// import Login from './components/copy.jsx';
// import RecruiterDashboard from './recruiter/RecruiterDashboard.jsx';
// import PostJob from './components/PostJob.jsx';
// import Recommendations from './components/Recommendations.jsx';
// import Shortlist from './components/Shortlist.jsx';
// import Interviews from './components/Interviews.jsx';
// import Offers from './components/Offers.jsx';
// import CandidateDashboard from './candidate/CandidateDashboard.jsx';

// // Enums
// import { NavigationPages } from './types/index.js';

// function App() {
//   const [isAuthenticated, setIsAuthenticated] = useState(false);
//   const [currentPage, setCurrentPage] = useState(NavigationPages.LOGIN);

//   const handleLoginSuccess = () => {
//     setIsAuthenticated(true);
//     setCurrentPage(NavigationPages.DASHBOARD);
//   };

//   const handleNavigate = (page) => {
//     setCurrentPage(page);
//   };

//   const renderCurrentDashboardPage = () => {
//     switch (currentPage) {
//       case NavigationPages.LOGIN:
//         return <Login onLoginSuccess={handleLoginSuccess} onNavigate={handleNavigate} />;
//       case NavigationPages.DASHBOARD:
//         return <RecruiterDashboard onNavigate={handleNavigate} />;
//       case NavigationPages.POST_JOB:
//         return <PostJob />;
//       case NavigationPages.RECOMMENDATIONS:
//         return <Recommendations onNavigate={handleNavigate} />;
//       case NavigationPages.SHORTLIST:
//         return <Shortlist onNavigate={handleNavigate} />;
//       case NavigationPages.INTERVIEWS:
//         return <Interviews onNavigate={handleNavigate} />;
//       case NavigationPages.OFFERS:
//         return <Offers />;
//       default:
//         return <RecruiterDashboard onNavigate={handleNavigate} />;
//     }
//   };

//   return (
//     <BrowserRouter>
//       <Routes>

//         {/* 🌐 Public Website */}
//         <Route
//           path="/"
//           element={
//             <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
//               <Navbar />
//               <main>
//                 <Hero />
//                 <AIFeatures />
//                 <JobPortal />
//                 <Testimonials />
//                 <Blog />
//                 <Newsletter />
//               </main>
//               <Footer />
//             </div>
//           }
//         />

//         {/* 🎯 Standalone Pages */}
//         <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
//         <Route path="/recruiter/dashboard" element={<RecruiterDashboard />} />
//         <Route path="/resume-builder" element={<ResumeBuilder />} />
//         <Route path="/login" element={<AuthPage />} />

//         {/* 🔐 Recruiter Dashboard Pages */}
//         {isAuthenticated ? (
//           <>
//             <Route
//               path="/dashboard"
//               element={
//                 <Layout currentPage={currentPage} onNavigate={handleNavigate}>
//                   {renderCurrentDashboardPage()}
//                 </Layout>
//               }
//             />
//             <Route path="/post-job" element={<Layout><PostJob /></Layout>} />
//             <Route path="/recommendations" element={<Layout><Recommendations /></Layout>} />
//             <Route path="/shortlist" element={<Layout><Shortlist /></Layout>} />
//             <Route path="/interviews" element={<Layout><Interviews /></Layout>} />
//             <Route path="/offers" element={<Layout><Offers /></Layout>} />
//           </>
//         ) : (
//           <>
//             <Route path="/dashboard" element={<Navigate to="/login" />} />
//             <Route path="/post-job" element={<Navigate to="/login" />} />
//             <Route path="/recommendations" element={<Navigate to="/login" />} />
//             <Route path="/shortlist" element={<Navigate to="/login" />} />
//             <Route path="/interviews" element={<Navigate to="/login" />} />
//             <Route path="/offers" element={<Navigate to="/login" />} />
//           </>
//         )}

//         {/* 🔁 Catch-all */}
//         <Route path="*" element={<Navigate to="/" />} />
//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;
