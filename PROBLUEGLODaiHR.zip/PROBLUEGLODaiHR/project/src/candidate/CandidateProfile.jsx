import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import CandidateSidebar from './CandidateSidebar';

const CandidateProfile = () => {
  const [user, setUser] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    bio: '',
    avatar: '',
    skills: [],
    experience: [],
    education: []
  });
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [avatarPreview, setAvatarPreview] = useState('');

  // Get current user ID from local storage or context
  const userId = localStorage.getItem('userId') || 'current-user-id';

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      setIsLoading(true);
      const response = await fetch(`http://localhost:5000/api/users/${userId}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }
      
      const data = await response.json();
      setUser(data);
      setAvatarPreview(data.avatar || '');
    } catch (error) {
      toast.error(error.message || 'Failed to fetch user data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleArrayChange = (field, index, e) => {
    const newArray = [...user[field]];
    newArray[index] = e.target.value;
    setUser({ ...user, [field]: newArray });
  };

  const addArrayItem = (field) => {
    setUser({ ...user, [field]: [...user[field], ''] });
  };

  const removeArrayItem = (field, index) => {
    const newArray = user[field].filter((_, i) => i !== index);
    setUser({ ...user, [field]: newArray });
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result);
        setUser({ ...user, avatar: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      const response = await fetch(`http://localhost:5000/api/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(user)
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      toast.success('Profile updated successfully');
      setIsEditing(false);
      fetchUserData(); // Refresh data
    } catch (error) {
      toast.error(error.message || 'Failed to update profile');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gradient-to-tr from-blue-900 via-black to-yellow-900">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-tr from-blue-900 via-black to-yellow-900 flex flex-col md:flex-row">
      <CandidateSidebar />
      
      <div className="flex-1 p-4">
        <div className="bg-blue-80 shadow-xl rounded-lg overflow-hidden max-w-4xl mx-auto">
          {/* Header */}
          <div className="px-4 py-5 sm:px-6 bg-gray-50">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Profile</h2>
          
          </div>

          {/* Content */}
          <div className="p-4 sm:p-6">
            <form onSubmit={handleSubmit}>
              {/* Avatar Section */}
              <div className="flex flex-col sm:flex-row items-center mb-6 gap-4">
                <div className="relative">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden bg-gray-200 border-2 border-white shadow-md">
                    {avatarPreview ? (
                      <img 
                        src={avatarPreview} 
                        alt="Avatar" 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-200 text-gray-400">
                        <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                      </div>
                    )}
                  </div>
                  
                  {isEditing && (
                    <label className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarChange}
                        className="hidden"
                      />
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </label>
                  )}
                </div>
                
                <div className="text-center sm:text-left mt-2 sm:mt-0">
                  {isEditing ? (
                    <div className="space-y-2">
                      <input
                        type="text"
                        name="name"
                        value={user.name}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md text-center sm:text-left"
                        placeholder="Full Name"
                        required
                      />
                      <div className="text-white">{user.email}</div>
                    </div>
                  ) : (
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">{user.name}</h3>
                      <p className="text-white">{user.email}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Basic Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Phone</label>
                  {isEditing ? (
                    <input
                      type="tel"
                      name="phone"
                      value={user.phone}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="Phone number"
                    />
                  ) : (
                    <p className="text-white py-1">{user.phone || 'Not provided'}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white mb-1">Location</label>
                  {isEditing ? (
                    <input
                      type="text"
                      name="location"
                      value={user.location}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="Your location"
                    />
                  ) : (
                    <p className="text-white py-1">{user.location || 'Not provided'}</p>
                  )}
                </div>
              </div>

              {/* Bio Section */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-white mb-1">About Me</label>
                {isEditing ? (
                  <textarea
                    name="bio"
                    value={user.bio}
                    onChange={handleInputChange}
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    placeholder="Tell about yourself..."
                  />
                ) : (
                  <p className="text-white py-1">
                    {user.bio || 'No bio provided'}
                  </p>
                )}
              </div>

              {/* Skills Section */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-white">Skills</label>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={() => addArrayItem('skills')}
                      className="text-blue-600 text-sm"
                    >
                      + Add Skill
                    </button>
                  )}
                </div>
                
                {user.skills.length === 0 && !isEditing ? (
                  <p className="text-white py-1">No skills added</p>
                ) : isEditing ? (
                  <div className="space-y-2">
                    {user.skills.map((skill, index) => (
                      <div key={index} className="flex items-center">
                        <input
                          type="text"
                          value={skill}
                          onChange={(e) => handleArrayChange('skills', index, e)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Skill"
                        />
                        <button
                          type="button"
                          onClick={() => removeArrayItem('skills', index)}
                          className="ml-2 text-red-500"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2 py-1">
                    {user.skills.map((skill, index) => (
                      <span 
                        key={index} 
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Experience Section */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-white">Experience</label>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={() => addArrayItem('experience')}
                      className="text-blue-600 text-sm"
                    >
                      + Add Experience
                    </button>
                  )}
                </div>
                
                {user.experience.length === 0 && !isEditing ? (
                  <p className="text-white py-1">No experience added</p>
                ) : isEditing ? (
                  <div className="space-y-2">
                    {user.experience.map((exp, index) => (
                      <div key={index} className="flex items-center">
                        <input
                          type="text"
                          value={exp}
                          onChange={(e) => handleArrayChange('experience', index, e)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Position at Company"
                        />
                        <button
                          type="button"
                          onClick={() => removeArrayItem('experience', index)}
                          className="ml-2 text-red-500"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 py-1">
                    {user.experience.map((exp, index) => (
                      <div key={index} className="border-l-2 border-blue-500 pl-3 py-1">
                        <p className="text-gray-800">{exp}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Education Section */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-white">Education</label>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={() => addArrayItem('education')}
                      className="text-blue-600 text-sm"
                    >
                      + Add Education
                    </button>
                  )}
                </div>
                
                {user.education.length === 0 && !isEditing ? (
                  <p className="text-white py-1">No education added</p>
                ) : isEditing ? (
                  <div className="space-y-2">
                    {user.education.map((edu, index) => (
                      <div key={index} className="flex items-center">
                        <input
                          type="text"
                          value={edu}
                          onChange={(e) => handleArrayChange('education', index, e)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                          placeholder="Degree at University"
                        />
                        <button
                          type="button"
                          onClick={() => removeArrayItem('education', index)}
                          className="ml-2 text-red-500"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2 py-1">
                    {user.education.map((edu, index) => (
                      <div key={index} className="border-l-2 border-blue-500 pl-3 py-1">
                        <p className="text-gray-800">{edu}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              {/* <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                {isEditing ? (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditing(false);
                        fetchUserData();
                      }}
                      className="px-4 py-2 border border-gray-300 rounded-md text-white bg-white hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      Save Changes
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsEditing(true)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Edit Profile
                  </button>
                )}
              </div> */}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateProfile;