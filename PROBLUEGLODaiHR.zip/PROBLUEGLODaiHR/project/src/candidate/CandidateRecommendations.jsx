import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FiSearch, FiBriefcase, FiMapPin, FiDollarSign, FiClock } from 'react-icons/fi';
import CandidateSidebar from './CandidateSidebar';
import { debounce } from 'lodash';

const CandidateRecommendations = () => {
  const [allJobs, setAllJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [filters, setFilters] = useState({
    search: '',
    location: '',
    type: 'all',
    minSalary: '',
    sort: 'newest'
  });

  // Fetch all jobs on component mount
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);

        const response = await axios.get('http://localhost:5000/api/jobs/cand-recommendations');
        setAllJobs(response.data);
        setFilteredJobs(response.data);
         console.log(response);
        setError(null);
      } catch (err) {
        console.error('Error fetching jobs:', err);
        setError('Failed to load job recommendations');
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  // Apply filters whenever filters state changes
  useEffect(() => {
    const applyFilters = () => {
      let results = [...allJobs];

      // Apply search filter
      if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        results = results.filter(job => 
          job.title.toLowerCase().includes(searchTerm) || 
          job.company.toLowerCase().includes(searchTerm) ||
          job.description.toLowerCase().includes(searchTerm)
        );
      }

      // Apply location filter
      if (filters.location) {
        const locationTerm = filters.location.toLowerCase();
        results = results.filter(job => 
          job.location.toLowerCase().includes(locationTerm)
        );
      }

      // Apply job type filter
      if (filters.type !== 'all') {
        results = results.filter(job => job.type === filters.type);
      }

      // Apply minimum salary filter
      if (filters.minSalary) {
        const minSalary = Number(filters.minSalary);
        results = results.filter(job => job.salary_max >= minSalary);
      }

      // Apply sorting
      switch(filters.sort) {
        case 'newest':
          results.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
          break;
        case 'salary_high':
          results.sort((a, b) => b.salary_max - a.salary_max);
          break;
        case 'salary_low':
          results.sort((a, b) => a.salary_max - b.salary_max);
          break;
        default:
          results.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      }

      setFilteredJobs(results);
    };

    applyFilters();
  }, [allJobs, filters]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  // Debounced search handler
  const handleSearchChange = debounce((value) => {
    setFilters(prev => ({ ...prev, search: value }));
  }, 300);

  const formatSalary = (min, max) => {
    if (min === max) return `$${min.toLocaleString()}`;
    return `$${min.toLocaleString()} - $${max.toLocaleString()}`;
  };

  const formatJobType = (type) => {
    return type.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-tr from-blue-900 via-black to-yellow-900 flex">
      <CandidateSidebar />
      
      <div className="flex-1 p-6 md:p-8 lg:p-10">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Job Recommendations</h1>
            <p className="text-gray-600">Find your next career opportunity</p>
          </div>
          
          {/* Search and Filters */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Search */}
              <div className="md:col-span-4">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <FiSearch className="mr-2" /> Search
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Job title, company, keywords"
                    onChange={(e) => handleSearchChange(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <FiSearch className="absolute left-3 top-3 text-gray-400" />
                </div>
              </div>
              
              {/* Location */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <FiMapPin className="mr-2" /> Location
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="location"
                    value={filters.location}
                    onChange={handleFilterChange}
                    placeholder="Any location"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <FiMapPin className="absolute left-3 top-3 text-gray-400" />
                </div>
              </div>
              
              {/* Job Type */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <FiBriefcase className="mr-2" /> Job Type
                </label>
                <select
                  name="type"
                  value={filters.type}
                  onChange={handleFilterChange}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white"
                >
                  <option value="all">All Types</option>
                  <option value="full-time">Full-time</option>
                  <option value="part-time">Part-time</option>
                  <option value="contract">Contract</option>
                  <option value="internship">Internship</option>
                  <option value="remote">Remote</option>
                </select>
                <FiBriefcase className="absolute left-3 top-3 text-gray-400 pointer-events-none" />
              </div>
              
              {/* Min Salary */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <FiDollarSign className="mr-2" /> Min Salary
                </label>
                <div className="relative">
                  <input
                    type="number"
                    name="minSalary"
                    value={filters.minSalary}
                    onChange={handleFilterChange}
                    placeholder="Any amount"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <FiDollarSign className="absolute left-3 top-3 text-gray-400" />
                </div>
              </div>
              
              {/* Sort */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center">
                  <FiClock className="mr-2" /> Sort By
                </label>
                <select
                  name="sort"
                  value={filters.sort}
                  onChange={handleFilterChange}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 appearance-none bg-white"
                >
                  <option value="newest">Newest</option>
                  <option value="salary_high">Salary High</option>
                  <option value="salary_low">Salary Low</option>
                </select>
                <FiClock className="absolute left-3 top-3 text-gray-400 pointer-events-none" />
              </div>
            </div>
            
            {/* Active filters */}
            {(filters.search || filters.location || filters.type !== 'all' || filters.minSalary) && (
              <div className="mt-4 flex flex-wrap gap-2">
                {filters.search && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    Search: {filters.search}
                    <button 
                      onClick={() => setFilters(prev => ({ ...prev, search: '' }))}
                      className="ml-1.5 inline-flex items-center justify-center w-4 h-4 rounded-full text-blue-800 hover:bg-blue-200"
                    >
                      ×
                    </button>
                  </span>
                )}
                {filters.location && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Location: {filters.location}
                    <button 
                      onClick={() => setFilters(prev => ({ ...prev, location: '' }))}
                      className="ml-1.5 inline-flex items-center justify-center w-4 h-4 rounded-full text-green-800 hover:bg-green-200"
                    >
                      ×
                    </button>
                  </span>
                )}
                {filters.type !== 'all' && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                    Type: {formatJobType(filters.type)}
                    <button 
                      onClick={() => setFilters(prev => ({ ...prev, type: 'all' }))}
                      className="ml-1.5 inline-flex items-center justify-center w-4 h-4 rounded-full text-purple-800 hover:bg-purple-200"
                    >
                      ×
                    </button>
                  </span>
                )}
                {filters.minSalary && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Min Salary: ${filters.minSalary}
                    <button 
                      onClick={() => setFilters(prev => ({ ...prev, minSalary: '' }))}
                      className="ml-1.5 inline-flex items-center justify-center w-4 h-4 rounded-full text-yellow-800 hover:bg-yellow-200"
                    >
                      ×
                    </button>
                  </span>
                )}
              </div>
            )}
          </div>
          
          {/* Results count */}
          <div className="mb-4 flex justify-between items-center">
            <p className="text-gray-600">
              {filteredJobs.length} {filteredJobs.length === 1 ? 'job' : 'jobs'} found
            </p>
            <div className="text-sm text-gray-500">
              Sorted by: {filters.sort === 'newest' ? 'Newest' : 
                          filters.sort === 'salary_high' ? 'Salary (High to Low)' : 
                          'Salary (Low to High)'}
            </div>
          </div>
          
          {/* Job Listings */}
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : error ? (
            <div className="bg-white rounded-xl shadow-sm p-8 text-center border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-2">Error loading jobs</h3>
              <p className="text-gray-500">{error}</p>
              <button 
                onClick={() => window.location.reload()}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Try Again
              </button>
            </div>
          ) : filteredJobs.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm p-8 text-center border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs match your criteria</h3>
              <p className="text-gray-500">Try adjusting your search filters</p>
              <button 
                onClick={() => setFilters({
                  search: '',
                  location: '',
                  type: 'all',
                  minSalary: '',
                  sort: 'newest'
                })}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredJobs.map((job) => (
                <div key={job.id} className="bg-white rounded-xl shadow-sm border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all duration-200">
                  <div className="p-6">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 flex-shrink-0 bg-gray-100 rounded-lg flex items-center justify-center">
                            {job.company_logo ? (
                              <img src={job.company_logo} alt={job.company} className="w-full h-full object-contain" />
                            ) : (
                              <span className="text-xl font-bold text-gray-400">
                                {job.company.charAt(0).toUpperCase()}
                              </span>
                            )}
                          </div>
                          <div>
                            <h2 className="text-xl font-bold text-gray-900 hover:text-blue-600 transition-colors">
                              {job.title}
                            </h2>
                            <p className="text-gray-600">
                              {job.company} • {job.location}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-4 flex flex-wrap gap-2">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                            job.type === 'remote' ? 'bg-green-100 text-green-800' :
                            job.type === 'full-time' ? 'bg-blue-100 text-blue-800' :
                            job.type === 'part-time' ? 'bg-purple-100 text-purple-800' :
                            job.type === 'contract' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {formatJobType(job.type)}
                          </span>
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                            {formatSalary(job.salary_min, job.salary_max)}
                          </span>
                        </div>
                        
                        <p className="mt-3 text-gray-700 line-clamp-2">
                          {job.description}
                        </p>
                      </div>
                      
                      <div className="flex flex-col items-end gap-3">
                        <span className="text-sm text-gray-500 flex items-center">
                          <FiClock className="mr-1" />
                          {new Date(job.created_at).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric'
                          })}
                        </span>
                        <div className="flex gap-2">
                          <button className="text-blue-600 font-medium hover:text-blue-800 px-3 py-1.5 rounded-lg hover:bg-blue-50 transition-colors">
                            Save
                          </button>
                          <button className="bg-blue-600 text-white px-4 py-1.5 rounded-lg hover:bg-blue-700 transition-colors">
                            Apply Now
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CandidateRecommendations;