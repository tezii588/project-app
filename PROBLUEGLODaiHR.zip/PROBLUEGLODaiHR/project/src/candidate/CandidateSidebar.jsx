// src/components/SidebarTabs.jsx
import React from 'react';
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import {
  TrendingUp,
  FileText,
  Target,
  User,
  Settings,LogOut
} from 'lucide-react';

const tabs = [
  { id: 'overview', label: 'Overview', icon: TrendingUp, href: "/candidate/dashboard" },
  { id: 'applications', label: 'Applications', icon: FileText, href: "/applications" },
  { id: 'recommendations', label: 'Recommendations', icon: Target, href: "/candidate-recommendations" },
  { id: 'profile', label: 'Profile', icon: User, href: "/profile" },
  { id: 'settings', label: 'Settings', icon: Settings, href: "/settings" }
  
];

const CandidateSidebar = () => {
  const location = useLocation();


  const navigate= useNavigate();
   const handleLogout = () => {
    navigate('/login');
  };

  return (
    <div className="lg:col-span-1">
      <div className="bg-white/5 backdrop-blur-lg p-6 rounded-2xl border border-white/10 space-y-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = location.pathname === tab.href;
          
          return (
            <NavLink
              to={tab.href}
              key={tab.id}
              className={`flex items-center w-full space-x-3 px-4 py-3 rounded-xl transition-colors duration-200 ${
                isActive
                  ? 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/30'
                  : 'text-white hover:text-yellow-200 hover:bg-white/10'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="truncate">{tab.label}</span>
            </NavLink>
          );
        })}

            <button
             
              className="flex items-center w-full space-x-3 px-4 py-3 rounded-xl transition-colors duration-200 text-white hover:text-yellow-200 hover:bg-white/10'
              "
            >
              <LogOut className="w-5 h-5 text-red-500" />
              <span className="truncate" onClick={handleLogout}>
                
                Logout</span>
      
            </button>
          
      </div>

    </div>
  );
};

export default CandidateSidebar;