import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  Chip,
  Box,
  Paper,
  CircularProgress,
  useMediaQuery,
  useTheme
} from '@mui/material';
import { 
  FilterList, 
  Search, 
  Work, 
  Business, 
  LocationOn, 
  Schedule, 
  AttachMoney,
  Description
} from '@mui/icons-material';

import CandidateSidebar from "./CandidateSidebar";

const JobBoard = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.down('md'));
  
  // State initialization
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);
  const [applyOpen, setApplyOpen] = useState(false);
  const [application, setApplication] = useState({
    cover_letter: '',
    resume_url: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  const [filters, setFilters] = useState({
    search: '',
    location: '',
    type: '',
    salary_min: ''
  });
  const [applications, setApplications] = useState([]);
  const [expandedJobId, setExpandedJobId] = useState(null);

  const userId = '5';

  // Fetch jobs and applications
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch jobs
        const jobsResponse = await axios.get('http://localhost:5000/api/jobs/all');
        const jobsData = Array.isArray(jobsResponse?.data) ? jobsResponse.data : [];
        setJobs(jobsData);
        setFilteredJobs(jobsData);
        
        // Fetch applications if userId exists
        if (userId) {
          const appsResponse = await axios.get(`http://localhost:5000/api/jobs/details/${userId}`);
          const appsData = Array.isArray(appsResponse?.data) ? appsResponse.data : [];
          setApplications(appsData);
        }
        
        setError(null);
      } catch (err) {
        setError(err.message || 'Failed to load data');
        setJobs([]);
        setFilteredJobs([]);
        setApplications([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [userId]);

  // Apply filters whenever filters or jobs change
  useEffect(() => {
    if (!Array.isArray(jobs)) {
      setFilteredJobs([]);
      return;
    }

    let result = [...jobs];
    
    // Apply search filter
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      result = result.filter(job => 
        (job.title?.toLowerCase().includes(searchTerm)) || 
        (job.company?.toLowerCase().includes(searchTerm)) ||
        (job.description?.toLowerCase().includes(searchTerm))
      );
    }
    
    // Apply location filter
    if (filters.location) {
      result = result.filter(job => 
        job.location?.toLowerCase().includes(filters.location.toLowerCase())
      );
    }
    
    // Apply job type filter
    if (filters.type) {
      result = result.filter(job => job.type === filters.type);
    }
    
    // Apply salary filter
    if (filters.salary_min) {
      const minSalary = parseInt(filters.salary_min);
      result = result.filter(job => 
        job.salary_min && job.salary_min >= minSalary
      );
    }
    
    setFilteredJobs(result);
  }, [filters, jobs]);

  // Handle apply button click
  const handleApplyClick = (job) => {
    setSelectedJob(job);
    setApplyOpen(true);
  };

  // Close application dialog
  const handleApplyClose = () => {
    setApplyOpen(false);
    setSelectedJob(null);
    setApplication({
      cover_letter: '',
      resume_url: ''
    });
  };

  // Submit application
  const handleApplicationSubmit = async () => {
    try {
      if (!application.cover_letter || !application.resume_url) {
        throw new Error('Cover letter and resume are required');
      }
      
      if (!selectedJob?.id || !userId) {
        throw new Error('Invalid job or user information');
      }
      
      const response = await axios.post('http://localhost:5000/api/jobs/applications', {
        job_id: selectedJob.id,
        user_id: '5',
        cover_letter: application.cover_letter,
        resume_url: application.resume_url
      });
      
      setApplications(prev => [...prev, response.data]);
      setSnackbar({
        open: true,
        message: 'Application submitted successfully!',
        severity: 'success'
      });
      handleApplyClose();
    } catch (err) {
      setSnackbar({
        open: true,
        message: err.response?.data?.error || err.message || 'Failed to submit application',
        severity: 'error'
      });
    }
  };

  // Handle file upload
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
      // In a real app, you would upload to a storage service here
      // This is a mock implementation
      const mockUrl = `https://example.com/resumes/${file.name}`;
      setApplication({
        ...application,
        resume_url: mockUrl
      });
    } catch (err) {
      setSnackbar({
        open: true,
        message: 'Failed to upload resume',
        severity: 'error'
      });
    }
  };

  // Handle filter changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value
    });
  };

  // Check if user has already applied to a job
  const hasApplied = (jobId) => {
    return applications.some(app => app.job_id === jobId);
  };

  // Toggle job description expansion
  const toggleDescription = (jobId) => {
    setExpandedJobId(expandedJobId === jobId ? null : jobId);
  };

  // Loading state
  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} />
      </Container>
    );
  }

  // Error state
  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
        <Button 
          variant="contained" 
          onClick={() => window.location.reload()}
        >
          Retry
        </Button>
      </Container>
    );
  }

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-tr from-blue-900 via-black to-yellow-900 flex">
      <CandidateSidebar/>
    
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {/* Filters Section */}
        <Paper elevation={3} sx={{ p: 3, mb: 3, borderRadius: 4, background: 'rgba(255, 255, 255, 0.05)' }}>
          <Typography variant="h4" gutterBottom sx={{ color: 'white', fontWeight: 700 }}>
            Job Board
          </Typography>
          
          <Grid container spacing={2} alignItems="center">
  {/* Search Field */}
  <Grid item xs={12} md={isMobile ? 12 : 3}>
    <TextField
      fullWidth
      label="Search"
      name="search"
      value={filters.search}
      onChange={handleFilterChange}
      InputLabelProps={{
        sx: {
          color: 'white',
          '&.Mui-focused': { color: 'white' },
        }
      }}
      InputProps={{
        startAdornment: <Search sx={{ color: 'white' }} />,
        sx: {
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderRadius: 2,
          color: 'white',
          '& .MuiInputBase-input': { color: 'white' },
          '& fieldset': {
            borderColor: 'white',
          },
          '&:hover fieldset': {
            borderColor: 'white',
          },
          '&.Mui-focused fieldset': {
            borderColor: 'white',
          },
        }
      }}
    />
  </Grid>

  {/* Location Field */}
  <Grid item xs={12} md={isMobile ? 12 : 3}>
    <TextField
      fullWidth
      label="Location"
      name="location"
      value={filters.location}
      onChange={handleFilterChange}
      InputLabelProps={{
        sx: {
          color: 'white',
          '&.Mui-focused': { color: 'white' },
        }
      }}
      InputProps={{
        startAdornment: <LocationOn sx={{ color: 'white' }} />,
        sx: {
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderRadius: 2,
          color: 'white',
          '& .MuiInputBase-input': { color: 'white' },
          '& fieldset': {
            borderColor: 'white',
          },
          '&:hover fieldset': {
            borderColor: 'white',
          },
          '&.Mui-focused fieldset': {
            borderColor: 'white',
          },
        }
      }}
    />
  </Grid>

  {/* Job Type Dropdown */}
  <Grid item xs={12} md={isMobile ? 12 : 2}>
    <FormControl fullWidth sx={{
      '& .MuiInputLabel-root': {
        color: 'white',
        '&.Mui-focused': { color: 'white' },
      },
      '& .MuiOutlinedInput-root': {
        color: 'white',
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        borderRadius: 2,
        '& fieldset': { borderColor: 'white' },
        '&:hover fieldset': { borderColor: 'white' },
        '&.Mui-focused fieldset': { borderColor: 'white' },
      },
    }}>
      <InputLabel>Job Type</InputLabel>
      <Select
        name="type"
        value={filters.type}
        onChange={handleFilterChange}
        label="Job Type"
        IconComponent={() => <span style={{ color: 'white' }}>▼</span>}
      >
        <MenuItem value="">All Types</MenuItem>
        <MenuItem value="full-time">Full-time</MenuItem>
        <MenuItem value="part-time">Part-time</MenuItem>
        <MenuItem value="contract">Contract</MenuItem>
        <MenuItem value="internship">Internship</MenuItem>
        <MenuItem value="remote">Remote</MenuItem>
      </Select>
    </FormControl>
  </Grid>

  {/* Min Salary Field */}
  <Grid item xs={12} md={isMobile ? 12 : 2}>
    <TextField
      fullWidth
      label="Min Salary"
      name="salary_min"
      type="number"
      value={filters.salary_min}
      onChange={handleFilterChange}
      InputLabelProps={{
        sx: {
          color: 'white',
          '&.Mui-focused': { color: 'white' },
        }
      }}
      InputProps={{
        startAdornment: <AttachMoney sx={{ color: 'white' }} />,
        sx: {
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderRadius: 2,
          '& .MuiInputBase-input': { color: 'white' },
          '& fieldset': {
            borderColor: 'white',
          },
          '&:hover fieldset': {
            borderColor: 'white',
          },
          '&.Mui-focused fieldset': {
            borderColor: 'white',
          },
        }
      }}
    />
  </Grid>

  {/* Clear Filters Button */}
  <Grid item xs={12} md={isMobile ? 12 : 3} sx={{ 
    display: 'flex', 
    justifyContent: isMobile ? 'center' : 'flex-end',
    mt: isMobile ? 2 : 0
  }}>
    <Button
      variant="outlined"
      startIcon={<FilterList />}
      onClick={() => setFilters({
        search: '',
        location: '',
        type: '',
        salary_min: ''
      })}
      sx={{ 
        color: 'white', 
        borderColor: 'white',
        '&:hover': {
          backgroundColor: 'rgba(255, 255, 255, 0.1)',
          borderColor: 'white'
        }
      }}
    >
      Clear Filters
    </Button>
  </Grid>
</Grid>

        </Paper>

        {/* Job Count */}
        <Typography variant="h6" gutterBottom sx={{ color: 'white', mb: 3 }}>
          <span style={{ fontWeight: 700 }}>
            {filteredJobs.filter(job => !hasApplied(job.id)).length}
          </span> Jobs Available
        </Typography>

        {/* Jobs List */}
        <Grid container spacing={3}>
          {filteredJobs.length === 0 ? (
            <Grid item xs={12}>
              <Paper elevation={3} sx={{ p: 3, textAlign: 'center', background: 'rgba(255, 255, 255, 0.05)' }}>
                <Typography variant="body1" sx={{ color: 'white' }}>
                  No jobs match your filters. Try adjusting your search criteria.
                </Typography>
              </Paper>
            </Grid>
          ) : (
            filteredJobs.map((job) => (
              <Grid item xs={12} key={job.id}>
                <Card elevation={3} sx={{ 
                  borderRadius: 4,
                  background: 'linear-gradient(145deg, rgba(30, 30, 40, 0.8), rgba(20, 20, 30, 0.9))',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: '0 10px 20px rgba(0, 0, 0, 0.3)'
                  }
                }}>
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={12} md={8}>
                        <Typography variant="h5" component="div" sx={{ color: 'white', fontWeight: 700 }}>
                          {job.title}
                        </Typography>
                        <Typography variant="subtitle1" sx={{ 
                          color: 'rgba(255, 255, 255, 0.7)', 
                          display: 'flex', 
                          alignItems: 'center', 
                          gap: 1,
                          mt: 1,
                          flexWrap: 'wrap'
                        }}>
                          <Business fontSize="small" />
                          {job.company}
                          <LocationOn fontSize="small" />
                          {job.location || 'Location not specified'}
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 1, mb: 1, flexWrap: 'wrap', mt: 2 }}>
                          <Chip 
                            icon={<Schedule />} 
                            label={job.type || 'Not specified'} 
                            size="small" 
                            sx={{ 
                              backgroundColor: 'rgba(33, 150, 243, 0.2)', 
                              color: 'white'
                            }} 
                          />
                          {job.salary_min && job.salary_max && (
                            <Chip 
                              icon={<AttachMoney />} 
                              label={`${job.salary_min} - ${job.salary_max}`} 
                              size="small" 
                              sx={{ 
                                backgroundColor: 'rgba(76, 175, 80, 0.2)', 
                                color: 'white'
                              }} 
                            />
                          )}
                        </Box>
                        <Typography variant="body2" sx={{ 
                          color: 'rgba(255, 255, 255, 0.8)',
                          mt: 2,
                          mb: 1
                        }}>
                          {expandedJobId === job.id 
                            ? job.description 
                            : job.description?.substring(0, 150) + (job.description?.length > 150 ? '...' : '')
                          }
                        </Typography>
                        {job.description?.length > 150 && (
                          <Button 
                            size="small" 
                            onClick={() => toggleDescription(job.id)}
                            sx={{ 
                              color: '#42a5f5',
                              textTransform: 'none',
                              fontWeight: 500
                            }}
                          >
                            {expandedJobId === job.id ? 'Show Less' : 'Read More'}
                          </Button>
                        )}
                      </Grid>
                      <Grid item xs={12} md={4} sx={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: { xs: 'flex-start', md: 'flex-end' } 
                      }}>
                        {hasApplied(job.id) ? (
                          <Chip 
                            label="Applied" 
                            color="success" 
                            sx={{ 
                              fontSize: '0.875rem', 
                              padding: '8px 16px',
                              backgroundColor: 'rgba(46, 125, 50, 0.2)',
                              color: '#66bb6a'
                            }}
                          />
                        ) : (
                          <Button
                            variant="contained"
                            startIcon={<Work />}
                            onClick={() => handleApplyClick(job)}
                            sx={{ 
                              whiteSpace: 'nowrap',
                              backgroundColor: '#1e88e5',
                              '&:hover': {
                                backgroundColor: '#1565c0'
                              },
                              fontWeight: 600,
                              px: 3,
                              py: 1
                            }}
                          >
                            Apply Now
                          </Button>
                        )}
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
            ))
          )}
        </Grid>

        {/* Application Dialog */}
        <Dialog 
          open={applyOpen} 
          onClose={handleApplyClose} 
          maxWidth="md" 
          fullWidth
          fullScreen={isMobile}
          PaperProps={{
            sx: { 
              borderRadius: isMobile ? 0 : 4,
              background: 'linear-gradient(to bottom right, #0f172a, #1e293b)',
              color: 'white'
            }
          }}
        >
          <DialogTitle sx={{ 
            backgroundColor: 'rgba(21, 101, 192, 0.2)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
          }}>
            Apply for {selectedJob?.title} at {selectedJob?.company}
          </DialogTitle>
          <DialogContent dividers sx={{ py: 3 }}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <Typography variant="h6" gutterBottom sx={{ color: 'white' }}>
                  Job Details
                </Typography>
                <Typography variant="body1" paragraph sx={{ color: 'rgba(255, 255, 255, 0.8)' }}>
                  {selectedJob?.description || 'No description provided'}
                </Typography>
                
                {selectedJob?.requirements?.length > 0 && (
                  <>
                    <Typography variant="subtitle1" gutterBottom sx={{ color: 'white', mt: 2 }}>
                      Requirements:
                    </Typography>
                    <ul style={{ color: 'rgba(255, 255, 255, 0.8)', paddingLeft: 20 }}>
                      {selectedJob.requirements.map((req, index) => (
                        <li key={index}>{req}</li>
                      ))}
                    </ul>
                  </>
                )}
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Cover Letter *"
                  name="cover_letter"
                  multiline
                  rows={isMobile ? 4 : 6}
                  required
                  value={application.cover_letter}
                  onChange={(e) => setApplication({...application, cover_letter: e.target.value})}
                  helperText="Explain why you're a good fit for this position"
                  InputProps={{
                    sx: { 
                      color: 'white',
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      borderRadius: 2
                    }
                  }}
                  InputLabelProps={{
                    sx: { color: 'rgba(255, 255, 255, 0.7)' }
                  }}
                  FormHelperTextProps={{
                    sx: { color: 'rgba(255, 255, 255, 0.6)' }
                  }}
                />
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="subtitle1" gutterBottom sx={{ color: 'white' }}>
                  Upload Resume *
                </Typography>
                <Button
                  variant="outlined"
                  component="label"
                  startIcon={<Description />}
                  sx={{ 
                    mb: 1,
                    color: 'white',
                    borderColor: 'rgba(255, 255, 255, 0.3)',
                    '&:hover': {
                      borderColor: 'white'
                    }
                  }}
                >
                  Upload Resume
                  <input
                    type="file"
                    hidden
                    accept=".pdf,.doc,.docx"
                    onChange={handleFileUpload}
                  />
                </Button>
                {application.resume_url ? (
                  <Typography variant="body2" sx={{ mt: 1, color: '#66bb6a' }}>
                    Resume uploaded: {application.resume_url.split('/').pop()}
                  </Typography>
                ) : (
                  <Typography variant="body2" sx={{ mt: 1, color: 'rgba(255, 255, 255, 0.6)' }}>
                    Please upload your resume (PDF or Word document)
                  </Typography>
                )}
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ 
            backgroundColor: 'rgba(30, 30, 40, 0.5)',
            borderTop: '1px solid rgba(255, 255, 255, 0.1)',
            px: 3,
            py: 2
          }}>
            <Button 
              onClick={handleApplyClose} 
              sx={{ 
                color: 'rgba(255, 255, 255, 0.7)',
                '&:hover': {
                  color: 'white'
                }
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleApplicationSubmit} 
              variant="contained"
              disabled={!application.cover_letter || !application.resume_url}
              sx={{
                backgroundColor: '#1e88e5',
                '&:hover': {
                  backgroundColor: '#1565c0'
                },
                '&:disabled': {
                  backgroundColor: 'rgba(30, 136, 229, 0.5)'
                }
              }}
            >
              Submit Application
            </Button>
          </DialogActions>
        </Dialog>

        {/* Snackbar for notifications */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={() => setSnackbar({...snackbar, open: false})}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setSnackbar({...snackbar, open: false})} 
            severity={snackbar.severity}
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Container>
    </div>
  );
};

export default JobBoard;