// // // // // // // // // import React, { useState } from 'react';
// // // // // // // // // import { useNavigate } from 'react-router-dom';

// // // // // // // // // const AuthPage = () => {
// // // // // // // // //   const [isLogin, setIsLogin] = useState(true);
// // // // // // // // //   const [email, setEmail] = useState('');
// // // // // // // // //   const [password, setPassword] = useState('');
// // // // // // // // //   const navigate = useNavigate();

// // // // // // // // //   const handleSubmit = () => {
// // // // // // // // //   if (email === 'sandeep@gmail.com' && password === '0404') {
// // // // // // // // //     // Recruiter Login
// // // // // // // // //     localStorage.setItem('userRole', 'recruiter');
// // // // // // // // //     navigate('/recruiter-dashboard');
// // // // // // // // //   } else {
// // // // // // // // //     // Candidate logic
// // // // // // // // //     let users = JSON.parse(localStorage.getItem('candidates')) || [];

// // // // // // // // //     if (!isLogin) {
// // // // // // // // //       // Sign Up logic
// // // // // // // // //       users.push({ email, password });
// // // // // // // // //       localStorage.setItem('candidates', JSON.stringify(users));
// // // // // // // // //       alert('Candidate registered! Please sign in.');
// // // // // // // // //       setIsLogin(true);
// // // // // // // // //     } else {
// // // // // // // // //       // Candidate Login logic
// // // // // // // // //       const user = users.find((u) => u.email === email && u.password === password);
// // // // // // // // //       if (user) {
// // // // // // // // //         localStorage.setItem('userRole', 'candidate');
// // // // // // // // //         navigate('/candidate-dashboard');
// // // // // // // // //       } else {
// // // // // // // // //         alert('Invalid candidate credentials');
// // // // // // // // //       }
// // // // // // // // //     }
// // // // // // // // //   }
// // // // // // // // // };


// // // // // // // // //   return (
// // // // // // // // //     <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white px-4">
// // // // // // // // //       <div className="max-w-md w-full bg-white/5 p-8 rounded-xl border border-white/10 backdrop-blur-md">
// // // // // // // // //         <h2 className="text-2xl font-bold text-center mb-6">
// // // // // // // // //           {isLogin ? 'Sign In to Visys' : 'Sign Up for Visys'}
// // // // // // // // //         </h2>

// // // // // // // // //         <input
// // // // // // // // //           type="email"
// // // // // // // // //           placeholder="Email"
// // // // // // // // //           value={email}
// // // // // // // // //           onChange={(e) => setEmail(e.target.value)}
// // // // // // // // //           className="w-full mb-4 px-4 py-2 bg-white/10 rounded text-white"
// // // // // // // // //         />

// // // // // // // // //         <input
// // // // // // // // //           type="password"
// // // // // // // // //           placeholder="Password"
// // // // // // // // //           value={password}
// // // // // // // // //           onChange={(e) => setPassword(e.target.value)}
// // // // // // // // //           className="w-full mb-4 px-4 py-2 bg-white/10 rounded text-white"
// // // // // // // // //         />

// // // // // // // // //         <button
// // // // // // // // //           onClick={handleSubmit}
// // // // // // // // //           className="w-full py-2 bg-yellow-400 text-slate-900 font-semibold rounded hover:scale-105 transition"
// // // // // // // // //         >
// // // // // // // // //           {isLogin ? 'Sign In' : 'Sign Up'}
// // // // // // // // //         </button>

// // // // // // // // //         <p className="mt-4 text-center text-sm text-gray-300">
// // // // // // // // //           {isLogin ? 'New user?' : 'Already have an account?'}{' '}
// // // // // // // // //           <button
// // // // // // // // //             onClick={() => setIsLogin(!isLogin)}
// // // // // // // // //             className="text-yellow-400 hover:underline"
// // // // // // // // //           >
// // // // // // // // //             {isLogin ? 'Sign Up' : 'Sign In'}
// // // // // // // // //           </button>
// // // // // // // // //         </p>
// // // // // // // // //       </div>
// // // // // // // // //     </div>
// // // // // // // // //   );
// // // // // // // // // };

// // // // // // // // // export default AuthPage;


// // // // // // // // import React, { useState } from 'react';
// // // // // // // // import { Mail, Lock, Crown, Eye, EyeOff } from 'lucide-react';
// // // // // // // // import { NavigationPages } from '../types';

// // // // // // // // export default function AuthPage({ onNavigate }) {
// // // // // // // //   const [isSignUp, setIsSignUp] = useState(false);
// // // // // // // //   const [email, setEmail] = useState('');
// // // // // // // //   const [password, setPassword] = useState('');
// // // // // // // //   const [confirmPassword, setConfirmPassword] = useState('');
// // // // // // // //   const [showPassword, setShowPassword] = useState(false);
// // // // // // // //   const [isLoading, setIsLoading] = useState(false);

// // // // // // // // const handleSubmit = async (e) => {
// // // // // // // //   e.preventDefault();
// // // // // // // //   setIsLoading(true);

// // // // // // // //   const url = isSignUp ? 'http://localhost:5000/api/auth/register' : 'http://localhost:5000/api/auth/login';
// // // // // // // //   const payload = { email, password };

// // // // // // // //   try {
// // // // // // // //     const res = await fetch(url, {
// // // // // // // //       method: 'POST',
// // // // // // // //       headers: { 'Content-Type': 'application/json' },
// // // // // // // //       body: JSON.stringify(payload),
// // // // // // // //     });

// // // // // // // //     const data = await res.json();

// // // // // // // //     if (!res.ok) {
// // // // // // // //       alert(data.message || 'Error');
// // // // // // // //     } else {
// // // // // // // //       localStorage.setItem('token', data.token);
// // // // // // // //       onNavigate(NavigationPages.DASHBOARD);
// // // // // // // //     }
// // // // // // // //   } catch (error) {
// // // // // // // //     console.error(error);
// // // // // // // //     alert('Something went wrong!');
// // // // // // // //   }

// // // // // // // //   setIsLoading(false);
// // // // // // // // };

// // // // // // // //   return (
// // // // // // // //     <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
// // // // // // // //       {/* Background Pattern */}
// // // // // // // //       <div className="fixed inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(212,175,55,0.15),transparent_50%)] pointer-events-none"></div>
// // // // // // // //       <div className="fixed inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(59,130,246,0.15),transparent_50%)] pointer-events-none"></div>

// // // // // // // //       <div className="w-full max-w-md">
// // // // // // // //         <div className="backdrop-blur-2xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl shadow-black/20 p-8">
// // // // // // // //           {/* Header */}
// // // // // // // //           <div className="text-center mb-8">
// // // // // // // //             <div className="flex justify-center mb-4">
// // // // // // // //               <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 via-gold-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-gold-500/25">
// // // // // // // //                 <Crown className="text-white w-8 h-8" />
// // // // // // // //               </div>
// // // // // // // //             </div>
// // // // // // // //             <h1 className="text-3xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent mb-2">
// // // // // // // //               AI4Hr
// // // // // // // //             </h1>
// // // // // // // //             <p className="text-gold-300/80 text-sm">
// // // // // // // //               {isSignUp ? 'Create a New Account' : 'Premium Recruiting Platform'}
// // // // // // // //             </p>
// // // // // // // //           </div>

// // // // // // // //           {/* Auth Form */}
// // // // // // // //           <form onSubmit={handleSubmit} className="space-y-6">
// // // // // // // //             {/* Email */}
// // // // // // // //             <div className="space-y-2">
// // // // // // // //               <label className="block text-sm font-medium text-gold-200">Email Address</label>
// // // // // // // //               <div className="relative">
// // // // // // // //                 <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold-400 w-5 h-5" />
// // // // // // // //                 <input
// // // // // // // //                   type="email"
// // // // // // // //                   value={email}
// // // // // // // //                   onChange={(e) => setEmail(e.target.value)}
// // // // // // // //                   className="w-full pl-10 pr-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
// // // // // // // //                   placeholder="Enter your email"
// // // // // // // //                   required
// // // // // // // //                 />
// // // // // // // //               </div>
// // // // // // // //             </div>

// // // // // // // //             {/* Password */}
// // // // // // // //             <div className="space-y-2">
// // // // // // // //               <label className="block text-sm font-medium text-gold-200">Password</label>
// // // // // // // //               <div className="relative">
// // // // // // // //                 <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold-400 w-5 h-5" />
// // // // // // // //                 <input
// // // // // // // //                   type={showPassword ? 'text' : 'password'}
// // // // // // // //                   value={password}
// // // // // // // //                   onChange={(e) => setPassword(e.target.value)}
// // // // // // // //                   className="w-full pl-10 pr-12 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
// // // // // // // //                   placeholder="Enter your password"
// // // // // // // //                   required
// // // // // // // //                 />
// // // // // // // //                 <button
// // // // // // // //                   type="button"
// // // // // // // //                   onClick={() => setShowPassword(!showPassword)}
// // // // // // // //                   className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gold-400 hover:text-gold-300 transition-colors"
// // // // // // // //                 >
// // // // // // // //                   {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
// // // // // // // //                 </button>
// // // // // // // //               </div>
// // // // // // // //             </div>

// // // // // // // //             {/* Confirm Password (Sign Up Only) */}
// // // // // // // //             {isSignUp && (
// // // // // // // //               <div className="space-y-2">
// // // // // // // //                 <label className="block text-sm font-medium text-gold-200">Confirm Password</label>
// // // // // // // //                 <div className="relative">
// // // // // // // //                   <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold-400 w-5 h-5" />
// // // // // // // //                   <input
// // // // // // // //                     type={showPassword ? 'text' : 'password'}
// // // // // // // //                     value={confirmPassword}
// // // // // // // //                     onChange={(e) => setConfirmPassword(e.target.value)}
// // // // // // // //                     className="w-full pl-10 pr-12 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
// // // // // // // //                     placeholder="Confirm your password"
// // // // // // // //                     required
// // // // // // // //                   />
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             )}

// // // // // // // //             {/* Button */}
// // // // // // // //             <button
// // // // // // // //               type="submit"
// // // // // // // //               disabled={isLoading}
// // // // // // // //               className="w-full bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
// // // // // // // //             >
// // // // // // // //               {isLoading ? (
// // // // // // // //                 <>
// // // // // // // //                   <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
// // // // // // // //                   {isSignUp ? 'Creating Account...' : 'Signing In...'}
// // // // // // // //                 </>
// // // // // // // //               ) : isSignUp ? (
// // // // // // // //                 'Sign Up'
// // // // // // // //               ) : (
// // // // // // // //                 'Sign In'
// // // // // // // //               )}
// // // // // // // //             </button>
// // // // // // // //           </form>

// // // // // // // //           {/* Divider */}
// // // // // // // //           <div className="my-6 flex items-center">
// // // // // // // //             <div className="flex-1 border-t border-white/10"></div>
// // // // // // // //             <span className="px-4 text-gold-300/60 text-sm">or</span>
// // // // // // // //             <div className="flex-1 border-t border-white/10"></div>
// // // // // // // //           </div>

// // // // // // // //           {/* Toggle Auth */}
// // // // // // // //           <button
// // // // // // // //             onClick={() => setIsSignUp(!isSignUp)}
// // // // // // // //             className="w-full text-gold-300 hover:text-gold-200 text-sm"
// // // // // // // //           >
// // // // // // // //             {isSignUp
// // // // // // // //               ? 'Already have an account? Sign In'
// // // // // // // //               : "Don't have an account? Sign Up"}
// // // // // // // //           </button>

// // // // // // // //           {/* Footer */}
// // // // // // // //           <div className="mt-6 text-center text-xs text-gold-300/60">
// // // // // // // //             <p>By signing {isSignUp ? 'up' : 'in'}, you agree to our Terms of Service and Privacy Policy</p>
// // // // // // // //           </div>
// // // // // // // //         </div>
// // // // // // // //       </div>
// // // // // // // //     </div>
// // // // // // // //   );
// // // // // // // // }
// // // // // // // import React, { useState } from 'react';
// // // // // // // import { Mail, Lock, Crown, Eye, EyeOff } from 'lucide-react';
// // // // // // // import { NavigationPages } from '../types'; // Make sure this has both CANDIDATE_DASHBOARD & RECRUITER_DASHBOARD

// // // // // // // export default function AuthPage({ onNavigate }) {
// // // // // // //   const [isSignUp, setIsSignUp] = useState(false);
// // // // // // //   const [email, setEmail] = useState('');
// // // // // // //   const [password, setPassword] = useState('');
// // // // // // //   const [confirmPassword, setConfirmPassword] = useState('');
// // // // // // //   const [showPassword, setShowPassword] = useState(false);
// // // // // // //   const [isLoading, setIsLoading] = useState(false);

// // // // // // //   const handleSubmit = async (e) => {
// // // // // // //     e.preventDefault();
// // // // // // //     setIsLoading(true);

// // // // // // //     const isRecruiter = email === 'recruiter@visys.com';

// // // // // // //     if (isRecruiter && isSignUp) {
// // // // // // //       alert('Recruiter cannot sign up. Please log in.');
// // // // // // //       setIsLoading(false);
// // // // // // //       return;
// // // // // // //     }

// // // // // // //     if (isSignUp && password !== confirmPassword) {
// // // // // // //       alert('Passwords do not match!');
// // // // // // //       setIsLoading(false);
// // // // // // //       return;
// // // // // // //     }

// // // // // // //     const url = isSignUp
// // // // // // //       ? 'http://localhost:5000/api/auth/register'
// // // // // // //       : 'http://localhost:5000/api/auth/login';

// // // // // // //     const payload = { email, password };

// // // // // // //     try {
// // // // // // //       const res = await fetch(url, {
// // // // // // //         method: 'POST',
// // // // // // //         headers: { 'Content-Type': 'application/json' },
// // // // // // //         body: JSON.stringify(payload),
// // // // // // //       });

// // // // // // //       const data = await res.json();

// // // // // // //       if (!res.ok) {
// // // // // // //         alert(data.message || 'Error');
// // // // // // //       } else {
// // // // // // //         localStorage.setItem('token', data.token);

// // // // // // //         if (isRecruiter) {
// // // // // // //           onNavigate(NavigationPages.RECRUITER_DASHBOARD);
// // // // // // //         } else {
// // // // // // //           onNavigate(NavigationPages.CANDIDATE_DASHBOARD);
// // // // // // //         }
// // // // // // //       }
// // // // // // //     } catch (err) {
// // // // // // //       console.error(err);
// // // // // // //       alert('Something went wrong!');
// // // // // // //     }

// // // // // // //     setIsLoading(false);
// // // // // // //   };

// // // // // // //   return (
// // // // // // //     <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
// // // // // // //       <div className="fixed inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(212,175,55,0.15),transparent_50%)] pointer-events-none"></div>
// // // // // // //       <div className="fixed inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(59,130,246,0.15),transparent_50%)] pointer-events-none"></div>

// // // // // // //       <div className="w-full max-w-md">
// // // // // // //         <div className="backdrop-blur-2xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl shadow-black/20 p-8">
// // // // // // //           {/* Header */}
// // // // // // //           <div className="text-center mb-8">
// // // // // // //             <div className="flex justify-center mb-4">
// // // // // // //               <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-yellow-500/25">
// // // // // // //                 <Crown className="text-white w-8 h-8" />
// // // // // // //               </div>
// // // // // // //             </div>
// // // // // // //             <h1 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-200 bg-clip-text text-transparent mb-2">
// // // // // // //               AI4Hr
// // // // // // //             </h1>
// // // // // // //             <p className="text-yellow-300/80 text-sm">
// // // // // // //               {isSignUp ? 'Candidate Registration' : 'Sign In to your Account'}
// // // // // // //             </p>
// // // // // // //           </div>

// // // // // // //           {/* Form */}
// // // // // // //           <form onSubmit={handleSubmit} className="space-y-6">
// // // // // // //             <div className="space-y-2">
// // // // // // //               <label className="text-sm font-medium text-yellow-200">Email</label>
// // // // // // //               <div className="relative">
// // // // // // //                 <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-400" />
// // // // // // //                 <input
// // // // // // //                   type="email"
// // // // // // //                   required
// // // // // // //                   value={email}
// // // // // // //                   onChange={(e) => setEmail(e.target.value)}
// // // // // // //                   placeholder="Enter email"
// // // // // // //                   className="w-full pl-10 pr-4 py-3 bg-white/5 text-white rounded-xl"
// // // // // // //                 />
// // // // // // //               </div>
// // // // // // //             </div>

// // // // // // //             <div className="space-y-2">
// // // // // // //               <label className="text-sm font-medium text-yellow-200">Password</label>
// // // // // // //               <div className="relative">
// // // // // // //                 <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-400" />
// // // // // // //                 <input
// // // // // // //                   type={showPassword ? 'text' : 'password'}
// // // // // // //                   required
// // // // // // //                   value={password}
// // // // // // //                   onChange={(e) => setPassword(e.target.value)}
// // // // // // //                   placeholder="Enter password"
// // // // // // //                   className="w-full pl-10 pr-12 py-3 bg-white/5 text-white rounded-xl"
// // // // // // //                 />
// // // // // // //                 <button
// // // // // // //                   type="button"
// // // // // // //                   onClick={() => setShowPassword(!showPassword)}
// // // // // // //                   className="absolute right-3 top-1/2 -translate-y-1/2 text-yellow-400"
// // // // // // //                 >
// // // // // // //                   {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
// // // // // // //                 </button>
// // // // // // //               </div>
// // // // // // //             </div>

// // // // // // //             {/* Confirm Password */}
// // // // // // //             {isSignUp && email !== 'recruiter@visys.com' && (
// // // // // // //               <div className="space-y-2">
// // // // // // //                 <label className="text-sm font-medium text-yellow-200">Confirm Password</label>
// // // // // // //                 <div className="relative">
// // // // // // //                   <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-400" />
// // // // // // //                   <input
// // // // // // //                     type={showPassword ? 'text' : 'password'}
// // // // // // //                     required
// // // // // // //                     value={confirmPassword}
// // // // // // //                     onChange={(e) => setConfirmPassword(e.target.value)}
// // // // // // //                     placeholder="Confirm password"
// // // // // // //                     className="w-full pl-10 pr-12 py-3 bg-white/5 text-white rounded-xl"
// // // // // // //                   />
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             )}

// // // // // // //             {/* Button */}
// // // // // // //             <button
// // // // // // //               type="submit"
// // // // // // //               disabled={isLoading}
// // // // // // //               className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-3 rounded-xl transition"
// // // // // // //             >
// // // // // // //               {isLoading ? (isSignUp ? 'Registering...' : 'Signing In...') : isSignUp ? 'Sign Up' : 'Sign In'}
// // // // // // //             </button>
// // // // // // //           </form>

// // // // // // //           <div className="my-6 text-center text-yellow-300/80 text-sm">
// // // // // // //             {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
// // // // // // //             <button onClick={() => setIsSignUp(!isSignUp)} className="underline hover:text-yellow-200">
// // // // // // //               {isSignUp ? 'Sign In' : 'Sign Up'}
// // // // // // //             </button>
// // // // // // //           </div>
// // // // // // //         </div>
// // // // // // //       </div>
// // // // // // //     </div>
// // // // // // //   );
// // // // // // // }
// // // // // // import React, { useState } from 'react';
// // // // // // import { Mail, Lock, Crown, Eye, EyeOff } from 'lucide-react';
// // // // // // import { NavigationPages } from '../types'; // Make sure this file has your route constants

// // // // // // export default function AuthPage({ onNavigate }) {
// // // // // //   const [isSignUp, setIsSignUp] = useState(false);
// // // // // //   const [email, setEmail] = useState('');
// // // // // //   const [password, setPassword] = useState('');
// // // // // //   const [confirmPassword, setConfirmPassword] = useState('');
// // // // // //   const [showPassword, setShowPassword] = useState(false);
// // // // // //   const [isLoading, setIsLoading] = useState(false);

// // // // // //   const handleSubmit = async (e) => {
// // // // // //     e.preventDefault();
// // // // // //     setIsLoading(true);

// // // // // //     const isRecruiter = email === 'recruiter@visys.com';

// // // // // //     // Prevent recruiter from signing up
// // // // // //     if (isRecruiter && isSignUp) {
// // // // // //       alert('Recruiter cannot sign up. Please use your credentials to sign in.');
// // // // // //       setIsLoading(false);
// // // // // //       return;
// // // // // //     }

// // // // // //     // Password check for candidate
// // // // // //     if (isSignUp && password !== confirmPassword) {
// // // // // //       alert('Passwords do not match!');
// // // // // //       setIsLoading(false);
// // // // // //       return;
// // // // // //     }

// // // // // //     const url = isSignUp
// // // // // //       ? 'http://localhost:5000/api/auth/register'
// // // // // //       : 'http://localhost:5000/api/auth/login';

// // // // // //     const payload = { email, password };

// // // // // //     try {
// // // // // //       const res = await fetch(url, {
// // // // // //         method: 'POST',
// // // // // //         headers: { 'Content-Type': 'application/json' },
// // // // // //         body: JSON.stringify(payload),
// // // // // //       });

// // // // // //       const data = await res.json();

// // // // // //       if (!res.ok) {
// // // // // //         alert(data.message || 'Authentication failed.');
// // // // // //       } else {
// // // // // //         localStorage.setItem('token', data.token);
// // // // // //         if (isRecruiter) {
// // // // // //           onNavigate(NavigationPages.RECRUITER_DASHBOARD);
// // // // // //         } else {
// // // // // //           onNavigate(NavigationPages.CANDIDATE_DASHBOARD);
// // // // // //         }
// // // // // //       }
// // // // // //     } catch (err) {
// // // // // //       console.error(err);
// // // // // //       alert('Something went wrong!');
// // // // // //     }

// // // // // //     setIsLoading(false);
// // // // // //   };

// // // // // //   return (
// // // // // //     <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
// // // // // //       <div className="fixed inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(212,175,55,0.15),transparent_50%)] pointer-events-none"></div>
// // // // // //       <div className="fixed inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(59,130,246,0.15),transparent_50%)] pointer-events-none"></div>

// // // // // //       <div className="w-full max-w-md">
// // // // // //         <div className="backdrop-blur-2xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-8">
// // // // // //           <div className="text-center mb-8">
// // // // // //             <div className="flex justify-center mb-4">
// // // // // //               <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-amber-600 rounded-2xl flex items-center justify-center">
// // // // // //                 <Crown className="text-white w-8 h-8" />
// // // // // //               </div>
// // // // // //             </div>
// // // // // //             <h1 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-200 bg-clip-text text-transparent mb-2">
// // // // // //               AI4Hr
// // // // // //             </h1>
// // // // // //             <p className="text-yellow-300/80 text-sm">
// // // // // //               {isSignUp ? 'Candidate Registration' : 'Sign In to your Account'}
// // // // // //             </p>
// // // // // //           </div>

// // // // // //           <form onSubmit={handleSubmit} className="space-y-6">
// // // // // //             {/* Email */}
// // // // // //             <div className="space-y-2">
// // // // // //               <label className="text-sm font-medium text-yellow-200">Email</label>
// // // // // //               <div className="relative">
// // // // // //                 <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-400" />
// // // // // //                 <input
// // // // // //                   type="email"
// // // // // //                   required
// // // // // //                   value={email}
// // // // // //                   onChange={(e) => setEmail(e.target.value)}
// // // // // //                   placeholder="Enter email"
// // // // // //                   className="w-full pl-10 pr-4 py-3 bg-white/5 text-white rounded-xl"
// // // // // //                 />
// // // // // //               </div>
// // // // // //             </div>

// // // // // //             {/* Password */}
// // // // // //             <div className="space-y-2">
// // // // // //               <label className="text-sm font-medium text-yellow-200">Password</label>
// // // // // //               <div className="relative">
// // // // // //                 <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-400" />
// // // // // //                 <input
// // // // // //                   type={showPassword ? 'text' : 'password'}
// // // // // //                   required
// // // // // //                   value={password}
// // // // // //                   onChange={(e) => setPassword(e.target.value)}
// // // // // //                   placeholder="Enter password"
// // // // // //                   className="w-full pl-10 pr-12 py-3 bg-white/5 text-white rounded-xl"
// // // // // //                 />
// // // // // //                 <button
// // // // // //                   type="button"
// // // // // //                   onClick={() => setShowPassword(!showPassword)}
// // // // // //                   className="absolute right-3 top-1/2 -translate-y-1/2 text-yellow-400"
// // // // // //                 >
// // // // // //                   {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
// // // // // //                 </button>
// // // // // //               </div>
// // // // // //             </div>

// // // // // //             {/* Confirm Password */}
// // // // // //             {isSignUp && email !== 'recruiter@visys.com' && (
// // // // // //               <div className="space-y-2">
// // // // // //                 <label className="text-sm font-medium text-yellow-200">Confirm Password</label>
// // // // // //                 <div className="relative">
// // // // // //                   <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-400" />
// // // // // //                   <input
// // // // // //                     type={showPassword ? 'text' : 'password'}
// // // // // //                     required
// // // // // //                     value={confirmPassword}
// // // // // //                     onChange={(e) => setConfirmPassword(e.target.value)}
// // // // // //                     placeholder="Confirm password"
// // // // // //                     className="w-full pl-10 pr-12 py-3 bg-white/5 text-white rounded-xl"
// // // // // //                   />
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             )}

// // // // // //             {/* Submit Button */}
// // // // // //             <button
// // // // // //               type="submit"
// // // // // //               disabled={isLoading}
// // // // // //               className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-3 rounded-xl transition"
// // // // // //             >
// // // // // //               {isLoading ? (isSignUp ? 'Registering...' : 'Signing In...') : isSignUp ? 'Sign Up' : 'Sign In'}
// // // // // //             </button>
// // // // // //           </form>

// // // // // //           {/* Toggle Link */}
// // // // // //           <div className="my-6 text-center text-yellow-300/80 text-sm">
// // // // // //             {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
// // // // // //             <button onClick={() => setIsSignUp(!isSignUp)} className="underline hover:text-yellow-200">
// // // // // //               {isSignUp ? 'Sign In' : 'Sign Up'}
// // // // // //             </button>
// // // // // //           </div>
// // // // // //         </div>
// // // // // //       </div>
// // // // // //     </div>
// // // // // //   );
// // // // // // }
// // // // // // import { useState } from "react";

// // // // // // export default function AuthPage() {
// // // // // //   const [isSignUp, setIsSignUp] = useState(false);
// // // // // //   const [formData, setFormData] = useState({
// // // // // //     email: "",
// // // // // //     password: "",
// // // // // //     role: "candidate", // candidate or recruiter
// // // // // //   });

// // // // // //   const toggleMode = () => setIsSignUp(!isSignUp);

// // // // // //   const handleChange = (e) => {
// // // // // //     setFormData({ ...formData, [e.target.name]: e.target.value });
// // // // // //   };

// // // // // //   const handleSubmit = async (e) => {
// // // // // //     e.preventDefault();

// // // // // //     const endpoint = isSignUp ? "/api/signup" : "/api/login";
// // // // // //     const res = await fetch(endpoint, {
// // // // // //       method: "POST",
// // // // // //       headers: { "Content-Type": "application/json" },
// // // // // //       body: JSON.stringify(formData),
// // // // // //     });

// // // // // //     const data = await res.json();
// // // // // //     alert(data.message); // for now
// // // // // //   };

// // // // // //   return (
// // // // // //     <div className="flex items-center justify-center h-screen bg-gray-100">
// // // // // //       <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
// // // // // //         <h2 className="text-2xl font-bold mb-6 text-center">
// // // // // //           {isSignUp ? "Candidate Sign Up" : "Login"}
// // // // // //         </h2>

// // // // // //         <form onSubmit={handleSubmit} className="space-y-4">
// // // // // //           <select
// // // // // //             name="role"
// // // // // //             onChange={handleChange}
// // // // // //             value={formData.role}
// // // // // //             className="w-full p-2 border rounded"
// // // // // //           >
// // // // // //             <option value="candidate">Candidate</option>
// // // // // //             <option value="recruiter">Recruiter</option>
// // // // // //           </select>

// // // // // //           <input
// // // // // //             type="email"
// // // // // //             name="email"
// // // // // //             required
// // // // // //             placeholder="Email"
// // // // // //             onChange={handleChange}
// // // // // //             className="w-full p-2 border rounded"
// // // // // //           />

// // // // // //           <input
// // // // // //             type="password"
// // // // // //             name="password"
// // // // // //             required
// // // // // //             placeholder="Password"
// // // // // //             onChange={handleChange}
// // // // // //             className="w-full p-2 border rounded"
// // // // // //           />

// // // // // //           <button
// // // // // //             type="submit"
// // // // // //             className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
// // // // // //           >
// // // // // //             {isSignUp ? "Sign Up" : "Login"}
// // // // // //           </button>
// // // // // //         </form>

// // // // // //         {formData.role === "candidate" && (
// // // // // //           <p className="mt-4 text-center text-sm">
// // // // // //             {isSignUp ? "Already have an account?" : "New here?"}
// // // // // //             <button onClick={toggleMode} className="text-green-600 ml-1 underline">
// // // // // //               {isSignUp ? "Login" : "Sign Up"}
// // // // // //             </button>
// // // // // //           </p>
// // // // // //         )}
// // // // // //       </div>
// // // // // //     </div>
// // // // // //   );
// // // // // // }


// // // // // import { useState } from "react";

// // // // // export default function AuthPage() {
// // // // //   const [isSignUp, setIsSignUp] = useState(false);
// // // // //   const [formData, setFormData] = useState({
// // // // //     email: "",
// // // // //     password: "",
// // // // //     role: "candidate", // candidate or recruiter
// // // // //   });
// // // // //   const [error, setError] = useState(null);
// // // // //   const [success, setSuccess] = useState(null);

// // // // //   const toggleMode = () => {
// // // // //     setError(null);
// // // // //     setSuccess(null);
// // // // //     setIsSignUp(!isSignUp);
// // // // //   };

// // // // //   const handleChange = (e) => {
// // // // //     setFormData({ ...formData, [e.target.name]: e.target.value });
// // // // //   };

// // // // //   const handleSubmit = async (e) => {
// // // // //     e.preventDefault();
// // // // //     setError(null);
// // // // //     setSuccess(null);

// // // // //     // Set backend URL explicitly
// // // // //     const backendURL = "http://localhost:5000";
// // // // //     const endpoint = isSignUp ? "/api/signup" : "/api/login";

// // // // //     try {
// // // // //       const res = await fetch(backendURL + endpoint, {
// // // // //         method: "POST",
// // // // //         headers: { "Content-Type": "application/json" },
// // // // //         body: JSON.stringify(formData),
// // // // //       });

// // // // //       // Check for non-OK responses
// // // // //       if (!res.ok) {
// // // // //         const errorText = await res.text();
// // // // //         throw new Error(errorText || "Request failed");
// // // // //       }

// // // // //       const data = await res.json();
// // // // //       setSuccess(data.message || "Success!");
// // // // //       alert(data.message || "Success!");
// // // // //     } catch (err) {
// // // // //       setError(err.message || "Something went wrong");
// // // // //       alert(err.message || "Something went wrong");
// // // // //       console.error("Error:", err);
// // // // //     }
// // // // //   };

// // // // //   return (
// // // // //     <div className="flex items-center justify-center h-screen bg-gray-100">
// // // // //       <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
// // // // //         <h2 className="text-2xl font-bold mb-6 text-center">
// // // // //           {isSignUp ? "Candidate Sign Up" : "Login"}
// // // // //         </h2>

// // // // //         <form onSubmit={handleSubmit} className="space-y-4">
// // // // //           <select
// // // // //             name="role"
// // // // //             onChange={handleChange}
// // // // //             value={formData.role}
// // // // //             className="w-full p-2 border rounded"
// // // // //           >
// // // // //             <option value="candidate">Candidate</option>
// // // // //             <option value="recruiter">Recruiter</option>
// // // // //           </select>

// // // // //           <input
// // // // //             type="email"
// // // // //             name="email"
// // // // //             required
// // // // //             placeholder="Email"
// // // // //             onChange={handleChange}
// // // // //             value={formData.email}
// // // // //             className="w-full p-2 border rounded"
// // // // //           />

// // // // //           <input
// // // // //             type="password"
// // // // //             name="password"
// // // // //             required
// // // // //             placeholder="Password"
// // // // //             onChange={handleChange}
// // // // //             value={formData.password}
// // // // //             className="w-full p-2 border rounded"
// // // // //           />

// // // // //           <button
// // // // //             type="submit"
// // // // //             className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
// // // // //           >
// // // // //             {isSignUp ? "Sign Up" : "Login"}
// // // // //           </button>
// // // // //         </form>

// // // // //         {error && <p className="mt-4 text-center text-red-600">{error}</p>}
// // // // //         {success && <p className="mt-4 text-center text-green-600">{success}</p>}

// // // // //         <p className="mt-4 text-center text-sm">
// // // // //           {isSignUp ? "Already have an account?" : "New here?"}
// // // // //           <button onClick={toggleMode} className="text-green-600 ml-1 underline">
// // // // //             {isSignUp ? "Login" : "Sign Up"}
// // // // //           </button>
// // // // //         </p>
// // // // //       </div>
// // // // //     </div>
// // // // //   );
// // // // // }
// // // // import { useState } from 'react';
// // // // import axios from 'axios';

// // // // export default function AuthPage() {
// // // //   const [isSignup, setIsSignup] = useState(false);
// // // //   const [role, setRole] = useState('candidate');
// // // //   const [email, setEmail] = useState('');
// // // //   const [password, setPassword] = useState('');
  
// // // //   const toggleMode = () => setIsSignup(prev => !prev);

// // // //   const handleSubmit = async (e) => {
// // // //     e.preventDefault();
    
// // // //     try {
// // // //       let response;

// // // //       if (role === 'recruiter') {
// // // //         // Recruiter can only log in
// // // //         response = await axios.post('http://localhost:5000/api/auth/login', {
// // // //           email, password, role
// // // //         });
// // // //       } else {
// // // //         if (isSignup) {
// // // //           response = await axios.post('http://localhost:5000/api/auth/register', {
// // // //             email, password, role
// // // //           });
// // // //         } else {
// // // //           response = await axios.post('http://localhost:5000/api/auth/login', {
// // // //             email, password, role
// // // //           });
// // // //         }
// // // //       }

// // // //       alert('✅ Success: ' + response.data.message);
// // // //     } catch (err) {
// // // //       alert('❌ Error: ' + err.response?.data?.error || 'Server error');
// // // //     }
// // // //   };

// // // //   return (
// // // //     <div style={{ padding: 20 }}>
// // // //       <h2>{isSignup ? 'Sign Up' : 'Login'} as {role}</h2>
// // // //       <form onSubmit={handleSubmit}>
// // // //         <select onChange={(e) => setRole(e.target.value)} value={role}>
// // // //           <option value="candidate">Candidate</option>
// // // //           <option value="recruiter">Recruiter</option>
// // // //         </select>
// // // //         <br /><br />
// // // //         <input type="email" placeholder="Email" required onChange={(e) => setEmail(e.target.value)} />
// // // //         <br /><br />
// // // //         <input type="password" placeholder="Password" required onChange={(e) => setPassword(e.target.value)} />
// // // //         <br /><br />
// // // //         <button type="submit">{isSignup ? 'Register' : 'Login'}</button>
// // // //       </form>
// // // //       {role === 'candidate' && (
// // // //         <p onClick={toggleMode} style={{ cursor: 'pointer', color: 'blue' }}>
// // // //           {isSignup ? 'Already have an account? Login' : 'New here? Register'}
// // // //         </p>
// // // //       )}
// // // //     </div>
// // // //   );
// // // // }
// // // import { useState } from 'react';
// // // import axios from 'axios';

// // // export default function AuthPage() {
// // //   const [isSignup, setIsSignup] = useState(false);
// // //   const [role, setRole] = useState('candidate');
// // //   const [email, setEmail] = useState('');
// // //   const [password, setPassword] = useState('');
// // //   const [name, setName] = useState('');

// // //   const toggleMode = () => setIsSignup((prev) => !prev);

// // //   const handleSubmit = async (e) => {
// // //     e.preventDefault();

// // //     try {
// // //       let response;

// // //       if (role === 'recruiter') {
// // //         // Recruiter: only login
// // //         response = await axios.post('http://localhost:5000/api/auth/login', {
// // //           email,
// // //           password,
// // //           role
// // //         });
// // //       } else {
// // //         // Candidate: register or login
// // //         if (isSignup) {
// // //           response = await axios.post('http://localhost:5000/api/auth/register', {
// // //             email,
// // //             password,
// // //             name,
// // //             role
// // //           });
// // //         } else {
// // //           await axios.post('http://localhost:5000/api/auth/login', {
// // //   email,
// // //   password,
// // //   role
// // // });
// // //         }
// // //       }

// // //       alert('✅ Success: ' + response.data.message);
// // //     } catch (err) {
// // //       console.error('Error:', err);
// // //       const errorMessage =
// // //         err.response?.data?.error || err.message || 'Something went wrong';
// // //       alert('❌ Error: ' + errorMessage);
// // //     }
// // //   };

// // //   return (
// // //     <div style={{ padding: 20, maxWidth: 400, margin: 'auto' }}>
// // //       <h2>{isSignup ? 'Sign Up' : 'Login'} as {role}</h2>

// // //       <form onSubmit={handleSubmit}>
// // //         <label>Role:</label>
// // //         <select onChange={(e) => setRole(e.target.value)} value={role}>
// // //           <option value="candidate">Candidate</option>
// // //           <option value="recruiter">Recruiter</option>
// // //         </select>

// // //         <br /><br />

// // //         <label>Email:</label>
// // //         <input
// // //   type="text"
// // //   placeholder="Your Name"
// // //   required
// // //   onChange={(e) => setName(e.target.value)}
// // // />


// // //         <br /><br />

// // //         <label>Password:</label>
// // //         <input
// // //   type="text"
// // //   placeholder="Your Name"
// // //   required
// // //   onChange={(e) => setName(e.target.value)}
// // // />


// // //         {role === 'candidate' && isSignup && (
// // //           <>
// // //             <br /><br />
// // //             <label>Name:</label>
// // //             <input
// // //   type="text"
// // //   placeholder="Your Name"
// // //   required
// // //   onChange={(e) => setName(e.target.value)}
// // // />

// // //           </>
// // //         )}

// // //         <br /><br />
// // //         <button type="submit">{isSignup && role === 'candidate' ? 'Register' : 'Login'}</button>
// // //       </form>

// // //       {role === 'candidate' && (
// // //         <p onClick={toggleMode} style={{ cursor: 'pointer', color: 'blue', marginTop: '10px' }}>
// // //           {isSignup ? 'Already have an account? Login' : 'New user? Register'}
// // //         </p>
// // //       )}
// // //     </div>
// // //   );
// // // }
// // // ✅ AuthPage.jsx - Full Glassmorphism UI with Blue-Gold Theme
// // // Supports: Candidate (Signup + Login), Recruiter (Login only)
// // // ############################################################################################################
// // // import { useState } from 'react';
// // // import axios from 'axios';

// // // export default function AuthPage() {
// // //   const [isSignup, setIsSignup] = useState(false);
// // //   const [role, setRole] = useState('candidate');
// // //   const [email, setEmail] = useState('');
// // //   const [password, setPassword] = useState('');
// // //   const [name, setName] = useState('');

// // //   const toggleMode = () => setIsSignup(prev => !prev);

// // //   const handleSubmit = async (e) => {
// // //     e.preventDefault();

// // //     if (!email || !password || (isSignup && role === 'candidate' && !name)) {
// // //       alert('Please fill all required fields');
// // //       return;
// // //     }

// // //     try {
// // //       let response;

// // //       if (role === 'recruiter') {
// // //         response = await axios.post('http://localhost:5000/api/auth/login', {
// // //           email, password, role
// // //         });
// // //       } else {
// // //         if (isSignup) {
// // //           response = await axios.post('http://localhost:5000/api/auth/register', {
// // //             email, password, role, name
// // //           });
// // //         } else {
// // //           response = await axios.post('http://localhost:5000/api/auth/login', {
// // //             email, password, role
// // //           });
// // //         }
// // //       }

// // //       alert('✅ ' + response.data.message);
// // //     } catch (err) {
// // //       const msg = err.response?.data?.error || 'Something went wrong';
// // //       alert('❌ ' + msg);
// // //     }
// // //   };

// // //   return (
// // //     <div className="min-h-screen bg-gradient-to-br from-blue-900 to-yellow-600 flex items-center justify-center">
// // //       <div className="backdrop-blur-xl bg-white/10 border border-white/30 rounded-3xl p-8 shadow-xl w-full max-w-md">
// // //         <h2 className="text-2xl font-bold text-center text-white mb-6">
// // //           {isSignup ? 'Candidate Sign Up' : `${role === 'recruiter' ? 'Recruiter' : 'Candidate'} Login`}
// // //         </h2>

// // //         <form onSubmit={handleSubmit} className="space-y-4">
// // //           <div>
// // //             <label className="text-white">Role</label>
// // //             <select
// // //               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white backdrop-blur border border-white/30"
// // //               value={role}
// // //               onChange={(e) => {
// // //                 setRole(e.target.value);
// // //                 if (e.target.value === 'recruiter') setIsSignup(false);
// // //               }}>
// // //               <option value="candidate">Candidate</option>
// // //               <option value="recruiter">Recruiter</option>
// // //             </select>
// // //           </div>

// // //           <div>
// // //             <label className="text-white">Email</label>
// // //             <input
// // //               type="email"
// // //               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
// // //               value={email}
// // //               required
// // //               onChange={(e) => setEmail(e.target.value)}
// // //               placeholder="Email"
// // //             />
// // //           </div>

// // //           <div>
// // //             <label className="text-white">Password</label>
// // //             <input
// // //               type="password"
// // //               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
// // //               value={password}
// // //               required
// // //               onChange={(e) => setPassword(e.target.value)}
// // //               placeholder="Password"
// // //             />
// // //           </div>

// // //           {role === 'candidate' && isSignup && (
// // //             <div>
// // //               <label className="text-white">Full Name</label>
// // //               <input
// // //                 type="text"
// // //                 className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
// // //                 value={name}
// // //                 required
// // //                 onChange={(e) => setName(e.target.value)}
// // //                 placeholder="Your Name"
// // //               />
// // //             </div>
// // //           )}

// // //           <button
// // //             type="submit"
// // //             className="w-full bg-gradient-to-r from-blue-700 to-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:scale-105 transition">
// // //             {isSignup && role === 'candidate' ? 'Register' : 'Login'}
// // //           </button>
// // //         </form>

// // //         {role === 'candidate' && (
// // //           <p
// // //             className="mt-4 text-center text-white underline cursor-pointer"
// // //             onClick={toggleMode}
// // //           >
// // //             {isSignup ? 'Already registered? Login' : 'New user? Register'}
// // //           </p>
// // //         )}
// // //       </div>
// // //     </div>
// // //   );
// // // }
// // // ********************************************************************************************
// // import { useState } from 'react';
// // import axios from 'axios';
// // import { useNavigate } from 'react-router-dom';

// // export default function AuthPage() {
// //   const navigate = useNavigate();

// //   const [isSignup, setIsSignup] = useState(false);
// //   const [role, setRole] = useState('candidate');
// //   const [email, setEmail] = useState('');
// //   const [password, setPassword] = useState('');
// //   const [name, setName] = useState('');

// //   const toggleMode = () => setIsSignup(prev => !prev);

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();

// //     if (!email || !password || (isSignup && role === 'candidate' && !name)) {
// //       alert('Please fill all required fields');
// //       return;
// //     }

// //     try {
// //       let response;

// //       if (role === 'recruiter') {
// //         // Recruiter can only login
// //         response = await axios.post('http://localhost:5000/api/auth/login', {
// //           email,
// //           password,
// //           role,
// //         });
// //         alert('✅ ' + response.data.message);
// //         navigate('/components/dashboard'); // 🎯 Recruiter redirect
// //       } else {
// //         if (isSignup) {
// //           // Candidate Registration
// //           response = await axios.post('http://localhost:5000/api/auth/register', {
// //             email,
// //             password,
// //             role,
// //             name,
// //           });
// //           alert('✅ ' + response.data.message);
// //           setIsSignup(false); // 🎯 Redirect to login page (stay here but switch mode)
// //         } else {
// //           // Candidate Login
// //           response = await axios.post('http://localhost:5000/api/auth/login', {
// //             email,
// //             password,
// //             role,
// //           });
// //           alert('✅ ' + response.data.message);
// //           navigate('/candidate/candidate-dashboard'); // 🎯 Candidate redirect
// //         }
// //       }
// //     } catch (err) {
// //       const msg = err.response?.data?.error || 'Something went wrong';
// //       alert('❌ ' + msg);
// //     }
// //   };

// //   return (
// //     <div className="min-h-screen bg-gradient-to-br from-blue-900 to-yellow-600 flex items-center justify-center">
// //       <div className="backdrop-blur-xl bg-white/10 border border-white/30 rounded-3xl p-8 shadow-xl w-full max-w-md">
// //         <h2 className="text-2xl font-bold text-center text-white mb-6">
// //           {isSignup ? 'Candidate Sign Up' : `${role === 'recruiter' ? 'Recruiter' : 'Candidate'} Login`}
// //         </h2>

// //         <form onSubmit={handleSubmit} className="space-y-4">
// //           <div>
// //             <label className="text-white">Role</label>
// //             <select
// //               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white backdrop-blur border border-white/30"
// //               value={role}
// //               onChange={(e) => {
// //                 setRole(e.target.value);
// //                 if (e.target.value === 'recruiter') setIsSignup(false);
// //               }}
// //             >
// //               <option value="candidate">Candidate</option>
// //               <option value="recruiter">Recruiter</option>
// //             </select>
// //           </div>

// //           <div>
// //             <label className="text-white">Email</label>
// //             <input
// //               type="email"
// //               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
// //               value={email}
// //               required
// //               onChange={(e) => setEmail(e.target.value)}
// //               placeholder="Email"
// //             />
// //           </div>

// //           <div>
// //             <label className="text-white">Password</label>
// //             <input
// //               type="password"
// //               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
// //               value={password}
// //               required
// //               onChange={(e) => setPassword(e.target.value)}
// //               placeholder="Password"
// //             />
// //           </div>

// //           {role === 'candidate' && isSignup && (
// //             <div>
// //               <label className="text-white">Full Name</label>
// //               <input
// //                 type="text"
// //                 className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
// //                 value={name}
// //                 required
// //                 onChange={(e) => setName(e.target.value)}
// //                 placeholder="Your Name"
// //               />
// //             </div>
// //           )}

// //           <button
// //             type="submit"
// //             className="w-full bg-gradient-to-r from-blue-700 to-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:scale-105 transition"
// //           >
// //             {isSignup && role === 'candidate' ? 'Register' : 'Login'}
// //           </button>
// //         </form>

// //         {role === 'candidate' && (
// //           <p
// //             className="mt-4 text-center text-white underline cursor-pointer"
// //             onClick={toggleMode}
// //           >
// //             {isSignup ? 'Already registered? Login' : 'New user? Register'}
// //           </p>
// //         )}
// //       </div>
// //     </div>
// //   );
// // }


// import { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// export default function AuthPage() {
//   const [isSignup, setIsSignup] = useState(false);
//   const [role, setRole] = useState('candidate');
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [name, setName] = useState('');
//   const navigate = useNavigate();

//   const toggleMode = () => setIsSignup(prev => !prev);

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!email || !password || (isSignup && role === 'candidate' && !name)) {
//       alert('Please fill all required fields');
//       return;
//     }

//     try {
//       let response;

//       if (role === 'recruiter') {
//         response = await axios.post('http://localhost:5000/api/auth/login', {
//           email,
//           password,
//           role
//         });
//       } else {
//         if (isSignup) {
//           response = await axios.post('http://localhost:5000/api/auth/register', {
//             email,
//             password,
//             role,
//             name
//           });
//         } else {
//           response = await axios.post('http://localhost:5000/api/auth/login', {
//             email,
//             password,
//             role
//           });
//         }
//       }

//       alert('✅ ' + response.data.message);

//       // ✅ Redirect based on role
//       if (response.data.message.toLowerCase().includes('success')) {
//         if (role === 'recruiter') {
//            navigate('/recruiter/dashboard'); // recruiter
//         } else {
//           navigate('/candidate/dashboard'); // candidate
//         }
//       }

//     } catch (err) {
//       const msg = err.response?.data?.error || 'Something went wrong';
//       alert('❌ ' + msg);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-blue-900 to-yellow-600 flex items-center justify-center">
//       <div className="backdrop-blur-xl bg-white/10 border border-white/30 rounded-3xl p-8 shadow-xl w-full max-w-md">
//         <h2 className="text-2xl font-bold text-center text-white mb-6">
//           {isSignup ? 'Candidate Sign Up' : `${role === 'recruiter' ? 'Recruiter' : 'Candidate'} Login`}
//         </h2>

//         <form onSubmit={handleSubmit} className="space-y-4">
//           <div>
//             <label className="text-white">Role</label>
//             <select
//               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white backdrop-blur border border-white/30"
//               value={role}
//               onChange={(e) => {
//                 setRole(e.target.value);
//                 if (e.target.value === 'recruiter') setIsSignup(false);
//               }}>
//               <option value="candidate">Candidate</option>
//               <option value="recruiter">Recruiter</option>
//             </select>
//           </div>

//           <div>
//             <label className="text-white">Email</label>
//             <input
//               type="email"
//               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
//               value={email}
//               required
//               onChange={(e) => setEmail(e.target.value)}
//               placeholder="Email"
//             />
//           </div>

//           <div>
//             <label className="text-white">Password</label>
//             <input
//               type="password"
//               className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
//               value={password}
//               required
//               onChange={(e) => setPassword(e.target.value)}
//               placeholder="Password"
//             />
//           </div>

//           {role === 'candidate' && isSignup && (
//             <div>
//               <label className="text-white">Full Name</label>
//               <input
//                 type="text"
//                 className="w-full mt-1 p-2 rounded-lg bg-white/20 text-white placeholder-white/70 backdrop-blur border border-white/30"
//                 value={name}
//                 required
//                 onChange={(e) => setName(e.target.value)}
//                 placeholder="Your Name"
//               />
//             </div>
//           )}

//           <button
//             type="submit"
//             className="w-full bg-gradient-to-r from-blue-700 to-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:scale-105 transition">
//             {isSignup && role === 'candidate' ? 'Register' : 'Login'}
//           </button>
//         </form>

//         {role === 'candidate' && (
//           <p
//             className="mt-4 text-center text-white underline cursor-pointer"
//             onClick={toggleMode}
//           >
//             {isSignup ? 'Already registered? Login' : 'New user? Register'}
//           </p>
//         )}
//       </div>
//     </div>
//   );
// }


import { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function AuthPage({ setIsAuthenticated }) {
  const [isSignup, setIsSignup] = useState(false);
  const [role, setRole] = useState('candidate');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const toggleMode = () => setIsSignup((prev) => !prev);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!email || !password || (isSignup && role === 'candidate' && !name)) {
      alert('Please fill all required fields');
      return;
    }

    try {
      let response;

      if (isSignup && role === 'candidate') {
        response = await axios.post('http://localhost:5000/api/auth/register', {
          email,
          password,
          role,
          name
        });
      } else {
        response = await axios.post('http://localhost:5000/api/auth/login', {
          email,
          password,
          role
        });
      }

      if (response.data.message.toLowerCase().includes('success')) {
        alert('✅ ' + response.data.message);
        console.log(response.data)
        localStorage.setItem("userId", response.data.id);
        setIsAuthenticated(true);
        if (role === 'recruiter') {
          navigate('/recruiter/dashboard');
        } else {
          navigate('/candidate/dashboard');
        }
      }

    } catch (err) {
      const msg = err.response?.data?.error || 'Something went wrong';
      alert('❌ ' + msg);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-yellow-600 flex items-center justify-center">
      <div className="backdrop-blur-xl bg-white/10 border border-white/30 rounded-3xl p-8 shadow-xl w-full max-w-md">
        <h2 className="text-2xl font-bold text-center text-white mb-6">
          {isSignup ? 'Candidate Sign Up' : `${role === 'recruiter' ? 'Recruiter' : 'Candidate'} Login`}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-white">Role</label>
            <select
              className="w-full mt-1 p-2 rounded-lg bg-white/20"
              value={role}
              onChange={(e) => {
                setRole(e.target.value);
                if (e.target.value === 'recruiter') setIsSignup(false);
              }}
            >
              <option value="candidate">Candidate</option>
              <option value="recruiter">Recruiter</option>
            </select>
          </div>

          <div>
            <label className="text-white">Email</label>
            <input
              type="email"
              className="w-full mt-1 p-2 rounded-lg bg-white/20"
              value={email}
              required
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
            />
          </div>

          <div>
            <label className="text-white">Password</label>
            <input
              type="password"
              className="w-full mt-1 p-2 rounded-lg bg-white/20 "
              value={password}
              required
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
            />
          </div>

          {role === 'candidate' && isSignup && (
            <div>
              <label className="text-white">Full Name</label>
              <input
                type="text"
                className="w-full mt-1 p-2 rounded-lg bg-white/20 "
                value={name}
                required
                onChange={(e) => setName(e.target.value)}
                placeholder="Your Name"
              />
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-700 to-yellow-500 text-white font-semibold py-2 px-4 rounded-lg hover:scale-105 transition"
          >
            {isSignup && role === 'candidate' ? 'Register' : 'Login'}
          </button>
        </form>

        {role === 'candidate' && (
          <p className="mt-4 text-center text-white underline cursor-pointer" onClick={toggleMode}>
            {isSignup ? 'Already registered? Login' : 'New user? Register'}
          </p>
        )}
      </div>
    </div>
  );
}
