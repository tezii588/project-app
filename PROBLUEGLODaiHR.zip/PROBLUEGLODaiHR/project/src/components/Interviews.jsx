import React, { useState } from 'react';
import { Calendar, Clock, Video, MapPin, User, Plus, Edit, Trash2, ExternalLink } from 'lucide-react';
import { mockInterviews, mockCandidates } from '../data/mockData';

export default function Interviews() {
  const [interviews, setInterviews] = useState(mockInterviews);
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [newInterview, setNewInterview] = useState({
    candidateId: '',
    candidateName: '',
    jobTitle: '',
    date: '',
    time: '',
    type: 'Video',
    meetingLink: ''
  });

  const shortlistedCandidates = mockCandidates.filter(c => c.isShortlisted);

  const handleScheduleInterview = (e) => {
    e.preventDefault();
    const selectedCandidate = shortlistedCandidates.find(c => c.id === newInterview.candidateId);
    
    const interview = {
      id: Date.now().toString(),
      ...newInterview,
      candidateName: selectedCandidate?.name || '',
      status: 'Scheduled'
    };

    setInterviews([...interviews, interview]);
    setNewInterview({
      candidateId: '',
      candidateName: '',
      jobTitle: '',
      date: '',
      time: '',
      type: 'Video',
      meetingLink: ''
    });
    setShowScheduleForm(false);
  };

  const handleDeleteInterview = (interviewId) => {
    setInterviews(interviews.filter(interview => interview.id !== interviewId));
  };

  const getInterviewTypeIcon = (type) => {
    switch (type) {
      case 'Video':
        return <Video className="w-4 h-4" />;
      case 'In-Person':
        return <MapPin className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Scheduled':
        return 'text-blue-400 bg-blue-500/20 border-blue-400/30';
      case 'Completed':
        return 'text-green-400 bg-green-500/20 border-green-400/30';
      case 'Cancelled':
        return 'text-red-400 bg-red-500/20 border-red-400/30';
      default:
        return 'text-gold-400 bg-gold-500/20 border-gold-400/30';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
              <Calendar className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
                Interview Schedule
              </h1>
              <p className="text-gold-300/80">Manage and schedule candidate interviews</p>
            </div>
          </div>
          <button
            onClick={() => setShowScheduleForm(true)}
            className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40 flex items-center gap-2"
          >
            <Plus size={18} />
            Schedule Interview
          </button>
        </div>
      </div>

      {/* Schedule Interview Form */}
      {showScheduleForm && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Schedule New Interview</h2>
          <form onSubmit={handleScheduleInterview} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Select Candidate *
                </label>
                <select
                  value={newInterview.candidateId}
                  onChange={(e) => setNewInterview({...newInterview, candidateId: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  required
                >
                  <option value="">Choose a candidate</option>
                  {shortlistedCandidates.map((candidate) => (
                    <option key={candidate.id} value={candidate.id}>
                      {candidate.name} - {candidate.matchPercentage}% match
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Job Title *
                </label>
                <input
                  type="text"
                  value={newInterview.jobTitle}
                  onChange={(e) => setNewInterview({...newInterview, jobTitle: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  placeholder="e.g., Senior React Developer"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Interview Date *
                </label>
                <input
                  type="date"
                  value={newInterview.date}
                  onChange={(e) => setNewInterview({...newInterview, date: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Interview Time *
                </label>
                <input
                  type="time"
                  value={newInterview.time}
                  onChange={(e) => setNewInterview({...newInterview, time: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Interview Type *
                </label>
                <select
                  value={newInterview.type}
                  onChange={(e) => setNewInterview({...newInterview, type: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                >
                  <option value="Video">Video Call</option>
                  <option value="In-Person">In-Person</option>
                  <option value="Phone">Phone Call</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Meeting Link (for video calls)
                </label>
                <input
                  type="url"
                  value={newInterview.meetingLink}
                  onChange={(e) => setNewInterview({...newInterview, meetingLink: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  placeholder="https://meet.google.com/..."
                />
              </div>
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40"
              >
                Schedule Interview
              </button>
              <button
                type="button"
                onClick={() => setShowScheduleForm(false)}
                className="flex-1 bg-white/5 hover:bg-white/10 text-gold-200 font-semibold py-3 px-6 rounded-xl transition-all duration-300 border border-white/20 hover:border-white/30"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Interviews List */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl">
        <div className="p-6 border-b border-white/10">
          <h2 className="text-lg font-semibold text-white">Upcoming Interviews ({interviews.filter(i => i.status === 'Scheduled').length})</h2>
        </div>

        <div className="divide-y divide-white/5">
          {interviews.map((interview) => (
            <div key={interview.id} className="p-6 hover:bg-white/5 transition-all duration-300">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                    {getInterviewTypeIcon(interview.type)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-lg">{interview.candidateName}</h3>
                    <p className="text-gold-300/70">{interview.jobTitle}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gold-300/60">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {new Date(interview.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {interview.time}
                      </div>
                      <div className="flex items-center gap-1">
                        {getInterviewTypeIcon(interview.type)}
                        {interview.type}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-lg text-sm font-medium border ${getStatusColor(interview.status)}`}>
                    {interview.status}
                  </span>
                  
                  {interview.meetingLink && (
                    <a
                      href={interview.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-green-500/20 hover:bg-green-500/30 text-green-400 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-green-400/30 hover:border-green-400/50 flex items-center gap-2"
                    >
                      <ExternalLink size={14} />
                      Join
                    </a>
                  )}
                  
                  <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-white/20 hover:border-white/30">
                    <Edit size={14} />
                  </button>
                  
                  <button
                    onClick={() => handleDeleteInterview(interview.id)}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-400 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-red-400/30 hover:border-red-400/50"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Empty State */}
      {interviews.length === 0 && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-gold-500 to-gold-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Calendar className="text-white w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No Interviews Scheduled</h3>
          <p className="text-gold-300/70 mb-6">Start scheduling interviews with your shortlisted candidates</p>
          <button
            onClick={() => setShowScheduleForm(true)}
            className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40"
          >
            Schedule Your First Interview
          </button>
        </div>
      )}
    </div>
  );
}