import React, { useState } from 'react';
import Postjob from '../components/Postjob';

export default function JobPost() {
  const [showModal, setShowModal] = useState(true); // open on page load for now

  return (
    <div className="p-6">
      <button
        onClick={() => setShowModal(true)}
        className="bg-yellow-500 text-black px-6 py-3 rounded-lg font-semibold shadow-md hover:bg-yellow-600"
      >
        + Create Job
      </button>

      <Postjob
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onJobCreated={() => {
          console.log('Job created successfully!');
        }}
      />
    </div>
  );
}
