// import React, { useState } from 'react';
// import { 
//   Briefcase, 
//   Users, 
//   Calendar, 
//   FileText, 
//   Star, 
//   Home,
//   Bell,
//   Settings,
//   LogOut,
//   Menu,
//   X,
//   Crown
// } from 'lucide-react';
// import { NavigationPages } from '../types';
// import { mockUser } from '../data/mockData';

// const navigationItems = [
//   { id: NavigationPages.DASHBOARD, label: 'Dashboard', icon: Home },
//   { id: NavigationPages.POST_JOB, label: 'Postjob', icon: Briefcase },
//   { id: NavigationPages.RECOMMENDATIONS, label: 'AI Recommendations', icon: Star },
//   { id: NavigationPages.SHORTLIST, label: 'Shortlisted', icon: Users },
//   { id: NavigationPages.INTERVIEWS, label: 'Interviews', icon: Calendar },
//   { id: NavigationPages.OFFERS, label: 'Offer Letters', icon: FileText },
// ];

// export default function Layout({ currentPage, onNavigate, children }) {
//   const [sidebarOpen, setSidebarOpen] = useState(false);

//   const handleLogout = () => {
//     onNavigate(NavigationPages.LOGIN);
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
//       {/* Background Pattern */}
//       <div className="fixed inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(212,175,55,0.1),transparent_50%)] pointer-events-none"></div>
      
//       {/* Header */}
//       <header className="relative z-20">
//         <div className="backdrop-blur-xl bg-white/10 border-b border-white/20 shadow-2xl">
//           <div className="px-4 sm:px-6 lg:px-8">
//             <div className="flex justify-between items-center h-16">
//               {/* Logo and mobile menu */}
//               <div className="flex items-center gap-4">
//                 <button
//                   onClick={() => setSidebarOpen(!sidebarOpen)}
//                   className="lg:hidden p-2 rounded-xl text-gold-300 hover:text-gold-100 hover:bg-white/10 transition-all duration-300 backdrop-blur-sm"
//                 >
//                   {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
//                 </button>
//                 <div className="flex items-center gap-3">
//                   <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 via-gold-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg shadow-gold-500/25">
//                     <Crown className="text-white w-5 h-5" />
//                   </div>
//                   <div>
//                     <h1 className="text-xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
//                       AI4Hr
//                     </h1>
//                     <p className="text-xs text-gold-300/70">Premium Edition</p>
//                   </div>
//                 </div>
//               </div>

//               {/* User profile */}
//               <div className="flex items-center gap-3">
//                 <button className="p-2.5 text-gold-300 hover:text-gold-100 hover:bg-white/10 rounded-xl transition-all duration-300 backdrop-blur-sm relative">
//                   <Bell size={18} />
//                   <span className="absolute -top-1 -right-1 w-2 h-2 bg-gold-400 rounded-full"></span>
//                 </button>
//                 <button className="p-2.5 text-gold-300 hover:text-gold-100 hover:bg-white/10 rounded-xl transition-all duration-300 backdrop-blur-sm">
//                   <Settings size={18} />
//                 </button>
//                 <div className="flex items-center gap-3 pl-4 border-l border-white/20">
//                   <img
//                     src={mockUser.avatar}
//                     alt={mockUser.name}
//                     className="w-9 h-9 rounded-xl object-cover border-2 border-gold-400/30 shadow-lg"
//                   />
//                   <div className="hidden sm:block">
//                     <p className="text-sm font-semibold text-white">{mockUser.name}</p>
//                     <p className="text-xs text-gold-300/70">{mockUser.company}</p>
//                   </div>
//                 </div>
//                 <button 
//                   onClick={handleLogout}
//                   className="p-2.5 text-gold-300 hover:text-red-400 hover:bg-white/10 rounded-xl transition-all duration-300 backdrop-blur-sm ml-2"
//                 >
//                   <LogOut size={18} />
//                 </button>
//               </div>
//             </div>
//           </div>
//         </div>
//       </header>

//       <div className="flex">
//         {/* Sidebar */}
//         <aside className={`
//           fixed inset-y-0 left-0 z-10 w-64 transform transition-all duration-500 ease-in-out lg:translate-x-0 lg:static lg:inset-0
//           ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
//         `}>
//           <div className="h-full backdrop-blur-xl bg-white/5 border-r border-white/10 shadow-2xl">
//             <div className="flex flex-col h-full pt-20 lg:pt-6">
//               <nav className="flex-1 px-4 space-y-2">
//                 {navigationItems.map((item) => {
//                   const Icon = item.icon;
//                   const isActive = currentPage === item.id;
                  
//                   return (
//                     <button
//                       key={item.id}
//                       onClick={() => {
//                         onNavigate(item.id);
//                         setSidebarOpen(false);
//                       }}
//                       className={`
//                         w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-300
//                         ${isActive 
//                           ? 'bg-gradient-to-r from-gold-500/20 to-gold-600/20 text-gold-200 shadow-lg shadow-gold-500/10 border border-gold-400/30' 
//                           : 'text-gold-300/80 hover:text-gold-200 hover:bg-white/10'
//                         }
//                         backdrop-blur-sm group
//                       `}
//                     >
//                       <Icon 
//                         size={20} 
//                         className={`transition-all duration-300 ${
//                           isActive ? 'text-gold-400' : 'group-hover:text-gold-300'
//                         }`} 
//                       />
//                       <span className="font-medium">{item.label}</span>
//                       {isActive && (
//                         <div className="ml-auto w-2 h-2 bg-gold-400 rounded-full shadow-lg shadow-gold-400/50"></div>
//                       )}
//                     </button>
//                   );
//                 })}
//               </nav>
              
//               <div className="p-4 border-t border-white/10">
//                 <div className="backdrop-blur-sm bg-gradient-to-r from-gold-500/10 to-gold-600/10 rounded-xl p-4 border border-gold-400/20">
//                   <div className="flex items-center gap-3">
//                     <div className="w-8 h-8 bg-gradient-to-r from-gold-400 to-gold-600 rounded-lg flex items-center justify-center">
//                       <Crown size={16} className="text-white" />
//                     </div>
//                     <div>
//                       <p className="text-sm font-semibold text-gold-200">Premium Plan</p>
//                       <p className="text-xs text-gold-400/70">Unlimited Access</p>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </aside>

//         {/* Main Content */}
//         <main className="flex-1 lg:ml-0">
//           <div className="p-6 lg:p-8">
//             {children}
//           </div>
//         </main>
//       </div>

//       {/* Mobile overlay */}
//       {sidebarOpen && (
//         <div
//           className="fixed inset-0 bg-black/50 backdrop-blur-sm z-0 lg:hidden"
//           onClick={() => setSidebarOpen(false)}
//         />
//       )}
//     </div>
//   );
// }

import React, { useState } from 'react';
import {
  Briefcase,
  Users,
  Calendar,
  FileText,
  Star,
  Home,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  Crown,
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { mockUser } from '../data/mockData';

const navigationItems = [
  { path: '/recruiter/dashboard', label: 'Dashboard', icon: Home },
  { path: '/post-job', label: 'Postjob', icon: Briefcase },
  { path: '/recruiter-applications', label: 'Applications', icon: FileText },
  { path: '/recommendations', label: 'AI Recommendations', icon: Star },
  { path: '/shortlist', label: 'Shortlisted', icon: Users },
  { path: '/interviews', label: 'Interviews', icon: Calendar },
  { path: '/offers', label: 'Offer Letters', icon: FileText },

];

export default function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="relative z-20">
        <div className="backdrop-blur-xl bg-white/10 border-b border-white/20 shadow-2xl">
          <div className="px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                  className="lg:hidden p-2 rounded-xl text-gold-300 hover:text-gold-100 hover:bg-white/10 transition-all duration-300 backdrop-blur-sm"
                >
                  {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
                </button>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg shadow-gold-500/25">
                    <Crown className="text-white w-5 h-5" />
                  </div>
                  <div>
                    <h1 className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-200 bg-clip-text text-transparent">
                      AI4Hr
                    </h1>
                    <p className="text-xs text-gold-300/70">Premium Edition</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button className="p-2.5 text-gold-300 hover:text-gold-100 hover:bg-white/10 rounded-xl transition-all duration-300 backdrop-blur-sm relative">
                  <Bell size={18} />
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-400 rounded-full"></span>
                </button>
                <button className="p-2.5 text-gold-300 hover:text-gold-100 hover:bg-white/10 rounded-xl transition-all duration-300 backdrop-blur-sm">
                  <Settings size={18} />
                </button>
                <div className="flex items-center gap-3 pl-4 border-l border-white/20">
                  <img
                    src={mockUser.avatar}
                    alt={mockUser.name}
                    className="w-9 h-9 rounded-xl object-cover border-2 border-yellow-400/30 shadow-lg"
                  />
                  <div className="hidden sm:block">
                    <p className="text-sm font-semibold text-white">{mockUser.name}</p>
                    <p className="text-xs text-gold-300/70">{mockUser.company}</p>
                  </div>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-2.5 text-gold-300 hover:text-red-400 hover:bg-white/10 rounded-xl transition-all duration-300 backdrop-blur-sm ml-2"
                >
                  <LogOut size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`fixed inset-y-0 left-0 z-10 w-64 transform transition-all duration-500 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="h-full backdrop-blur-xl bg-white/5 border-r border-white/10 shadow-2xl">
            <div className="flex flex-col h-full pt-20 lg:pt-6">
              <nav className="flex-1 px-4 space-y-2">
                {navigationItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  return (
                    <button
                      key={item.path}
                      onClick={() => {
                        navigate(item.path);
                        setSidebarOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-300 ${
                        isActive
                          ? 'bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 text-yellow-200 shadow-lg shadow-yellow-500/10 border border-yellow-400/30'
                          : 'text-yellow-300/80 hover:text-yellow-200 hover:bg-white/10'
                      } backdrop-blur-sm group`}
                    >
                      <Icon
                        size={20}
                        className={`transition-all duration-300 ${
                          isActive ? 'text-yellow-400' : 'group-hover:text-yellow-300'
                        }`}
                      />
                      <span className="font-medium">{item.label}</span>
                      {isActive && (
                        <div className="ml-auto w-2 h-2 bg-yellow-400 rounded-full shadow-lg shadow-yellow-400/50"></div>
                      )}
                    </button>
                  );
                })}
              </nav>

              <div className="p-4 border-t border-white/10">
                <div className="backdrop-blur-sm bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 rounded-xl p-4 border border-yellow-400/20">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-lg flex items-center justify-center">
                      <Crown size={16} className="text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-yellow-200">Premium Plan</p>
                      <p className="text-xs text-yellow-400/70">Unlimited Access</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 lg:ml-0">
          <div className="p-6 lg:p-8">{children}</div>
        </main>
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-0 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
