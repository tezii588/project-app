import React, { useState } from 'react';
import { FileText, Plus, Send, Download, Edit, Trash2, DollarSign, Calendar, User } from 'lucide-react';
import { mockOffers, mockCandidates } from '../data/mockData';

export default function Offers() {
  const [offers, setOffers] = useState(mockOffers);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newOffer, setNewOffer] = useState({
    candidateId: '',
    candidateName: '',
    jobTitle: '',
    salary: '',
    startDate: '',
    benefits: '',
    additionalTerms: ''
  });

  const shortlistedCandidates = mockCandidates.filter(c => c.isShortlisted);

  const handleCreateOffer = (e) => {
    e.preventDefault();
    const selectedCandidate = shortlistedCandidates.find(c => c.id === newOffer.candidateId);
    
    const offer = {
      id: Date.now().toString(),
      ...newOffer,
      candidateName: selectedCandidate?.name || '',
      status: 'Draft',
      createdAt: new Date()
    };

    setOffers([...offers, offer]);
    setNewOffer({
      candidateId: '',
      candidateName: '',
      jobTitle: '',
      salary: '',
      startDate: '',
      benefits: '',
      additionalTerms: ''
    });
    setShowCreateForm(false);
  };

  const handleSendOffer = (offerId) => {
    setOffers(offers.map(offer => 
      offer.id === offerId 
        ? { ...offer, status: 'Sent' }
        : offer
    ));
  };

  const handleDeleteOffer = (offerId) => {
    setOffers(offers.filter(offer => offer.id !== offerId));
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Draft':
        return 'text-gray-400 bg-gray-500/20 border-gray-400/30';
      case 'Sent':
        return 'text-blue-400 bg-blue-500/20 border-blue-400/30';
      case 'Accepted':
        return 'text-green-400 bg-green-500/20 border-green-400/30';
      case 'Rejected':
        return 'text-red-400 bg-red-500/20 border-red-400/30';
      default:
        return 'text-gold-400 bg-gold-500/20 border-gold-400/30';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
              <FileText className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
                Offer Letters
              </h1>
              <p className="text-gold-300/80">Create and manage job offers</p>
            </div>
          </div>
          <button
            onClick={() => setShowCreateForm(true)}
            className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40 flex items-center gap-2"
          >
            <Plus size={18} />
            Create Offer
          </button>
        </div>
      </div>

      {/* Create Offer Form */}
      {showCreateForm && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Create New Offer Letter</h2>
          <form onSubmit={handleCreateOffer} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Select Candidate *
                </label>
                <select
                  value={newOffer.candidateId}
                  onChange={(e) => setNewOffer({...newOffer, candidateId: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  required
                >
                  <option value="">Choose a candidate</option>
                  {shortlistedCandidates.map((candidate) => (
                    <option key={candidate.id} value={candidate.id}>
                      {candidate.name} - {candidate.matchPercentage}% match
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  Job Title *
                </label>
                <input
                  type="text"
                  value={newOffer.jobTitle}
                  onChange={(e) => setNewOffer({...newOffer, jobTitle: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  placeholder="e.g., Senior React Developer"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  <DollarSign className="inline w-4 h-4 mr-1" />
                  Annual Salary *
                </label>
                <input
                  type="text"
                  value={newOffer.salary}
                  onChange={(e) => setNewOffer({...newOffer, salary: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  placeholder="e.g., $120,000"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gold-200 mb-2">
                  <Calendar className="inline w-4 h-4 mr-1" />
                  Start Date *
                </label>
                <input
                  type="date"
                  value={newOffer.startDate}
                  onChange={(e) => setNewOffer({...newOffer, startDate: e.target.value})}
                  className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gold-200 mb-2">
                Benefits & Perks
              </label>
              <textarea
                value={newOffer.benefits}
                onChange={(e) => setNewOffer({...newOffer, benefits: e.target.value})}
                rows={3}
                className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300 resize-none"
                placeholder="Health insurance, 401k, vacation days, remote work options..."
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gold-200 mb-2">
                Additional Terms
              </label>
              <textarea
                value={newOffer.additionalTerms}
                onChange={(e) => setNewOffer({...newOffer, additionalTerms: e.target.value})}
                rows={3}
                className="w-full px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300 resize-none"
                placeholder="Any additional terms, conditions, or notes..."
              />
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40"
              >
                Create Offer Letter
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="flex-1 bg-white/5 hover:bg-white/10 text-gold-200 font-semibold py-3 px-6 rounded-xl transition-all duration-300 border border-white/20 hover:border-white/30"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Offers List */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">All Offers ({offers.length})</h2>
            <div className="flex items-center gap-2">
              <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-4 py-2 rounded-xl transition-all duration-300 border border-white/20 hover:border-white/30 flex items-center gap-2">
                <Download size={16} />
                Export
              </button>
            </div>
          </div>
        </div>

        <div className="divide-y divide-white/5">
          {offers.map((offer) => (
            <div key={offer.id} className="p-6 hover:bg-white/5 transition-all duration-300">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                    <User className="text-white w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-lg">{offer.candidateName}</h3>
                    <p className="text-gold-300/70">{offer.jobTitle}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gold-300/60">
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        {offer.salary}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Start: {new Date(offer.startDate).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <FileText className="w-4 h-4" />
                        Created: {offer.createdAt.toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-lg text-sm font-medium border ${getStatusColor(offer.status)}`}>
                    {offer.status}
                  </span>
                  
                  {offer.status === 'Draft' && (
                    <button
                      onClick={() => handleSendOffer(offer.id)}
                      className="bg-green-500/20 hover:bg-green-500/30 text-green-400 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-green-400/30 hover:border-green-400/50 flex items-center gap-2"
                    >
                      <Send size={14} />
                      Send
                    </button>
                  )}
                  
                  <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-white/20 hover:border-white/30">
                    <Download size={14} />
                  </button>
                  
                  <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-white/20 hover:border-white/30">
                    <Edit size={14} />
                  </button>
                  
                  <button
                    onClick={() => handleDeleteOffer(offer.id)}
                    className="bg-red-500/20 hover:bg-red-500/30 text-red-400 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-red-400/30 hover:border-red-400/50"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-gray-500 to-gray-600 rounded-xl flex items-center justify-center">
              <FileText className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{offers.filter(o => o.status === 'Draft').length}</p>
              <p className="text-gold-300/70 text-sm">Draft Offers</p>
            </div>
          </div>
        </div>

        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Send className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{offers.filter(o => o.status === 'Sent').length}</p>
              <p className="text-gold-300/70 text-sm">Sent Offers</p>
            </div>
          </div>
        </div>

        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center">
              <FileText className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{offers.filter(o => o.status === 'Accepted').length}</p>
              <p className="text-gold-300/70 text-sm">Accepted</p>
            </div>
          </div>
        </div>

        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center">
              <FileText className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{offers.filter(o => o.status === 'Rejected').length}</p>
              <p className="text-gold-300/70 text-sm">Rejected</p>
            </div>
          </div>
        </div>
      </div>

      {/* Empty State */}
      {offers.length === 0 && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-gold-500 to-gold-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <FileText className="text-white w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No Offers Created Yet</h3>
          <p className="text-gold-300/70 mb-6">Start creating offer letters for your top candidates</p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40"
          >
            Create Your First Offer
          </button>
        </div>
      )}
    </div>
  );
}