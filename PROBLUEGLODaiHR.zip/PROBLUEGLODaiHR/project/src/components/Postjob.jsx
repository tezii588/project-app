import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const JobModal = ({ isUpdate, jobForm, handleChange, handleSubmit, closeModals }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-4 z-50">
    <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4">
      <div className="bg-blue-600 text-white p-4 rounded-t-lg">
        <h3 className="text-xl font-semibold">
          {isUpdate ? 'Update Job' : 'Add New Job'}
        </h3>
      </div>
      
      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto">
        {Object.entries(jobForm).map(([field, value]) => {
          const isTextArea = ['description', 'requirements', 'benefits'].includes(field);
          const isFullWidth = isTextArea || field === 'type';
          
          return (
            <div 
              key={field} 
              className={isFullWidth ? 'md:col-span-2' : ''}
            >
              <label className="block text-gray-700 mb-1 capitalize">
                {field.replace(/_/g, ' ')}
              </label>
              
              {field === 'type' ? (
                <select
                  name={field}
                  value={value}
                  onChange={handleChange}
                  className="w-full border rounded p-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="full-time">Full-time</option>
                  <option value="part-time">Part-time</option>
                  <option value="contract">Contract</option>
                  <option value="internship">Internship</option>
                </select>
              ) : isTextArea ? (
                <textarea
                  name={field}
                  value={value}
                  onChange={handleChange}
                  className="w-full border rounded p-2 focus:ring-blue-500 focus:border-blue-500"
                  rows={4}
                />
              ) : (
                <input
                  type={field.includes('salary') ? 'number' : 'text'}
                  name={field}
                  value={value}
                  onChange={handleChange}
                  className="w-full border rounded p-2 focus:ring-blue-500 focus:border-blue-500"
                />
              )}
            </div>
          );
        })}
      </div>
      
      <div className="bg-gray-100 px-6 py-3 flex justify-end space-x-3 rounded-b-lg">
        <button 
          onClick={closeModals}
          className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-200"
        >
          Cancel
        </button>
        <button 
          onClick={() => handleSubmit(isUpdate)}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          {isUpdate ? 'Update' : 'Submit'}
        </button>
      </div>
    </div>
  </div>
);

const PostJob = () => {
  const [jobs, setJobs] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [currentJob, setCurrentJob] = useState(null);
  
  // Form states
  const [jobForm, setJobForm] = useState({
    title: '',
    company: '',
    location: '',
    type: 'full-time',
    salary_min: '',
    salary_max: '',
    description: '',
    requirements: '',
    benefits: '',
  });

  // Fetch jobs function
  const fetchJobs = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/jobs/all');
      setJobs(res.data);
    } catch (err) {
      console.error('Fetch error:', err);
    }
  }, []);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleChange = useCallback((e) => {
    const { name, value } = e.target;
    setJobForm(prevForm => ({
      ...prevForm,
      [name]: value
    }));
  }, []);

  // Open update modal with selected job data
  const handleEditClick = useCallback((job) => {
    setCurrentJob(job);
    setJobForm({
      title: job.title,
      company: job.company,
      location: job.location,
      type: job.type,
      salary_min: job.salary_min,
      salary_max: job.salary_max,
      description: job.description,
      requirements: job.requirements.join(', '),
      benefits: job.benefits.join(', '),
    });
    setShowUpdateModal(true);
  }, []);

  // Submit handler for both add/update
  const handleSubmit = useCallback(async (isUpdate = false) => {
    const payload = {
      ...jobForm,
      requirements: jobForm.requirements.split(',').map(item => item.trim()),
      benefits: jobForm.benefits.split(',').map(item => item.trim()),
      posted_by: 6,
      status: 'active'
    };

    try {
      if (isUpdate) {
        await axios.put(`http://localhost:5000/api/jobs/${currentJob.id}`, payload);
      } else {
        await axios.post('http://localhost:5000/api/jobs/add', payload);
      }
      
      fetchJobs();
      closeModals();
    } catch (err) {
      console.error('Submission error:', err);
    }
  }, [jobForm, currentJob, fetchJobs]);

  const handleDelete = useCallback(async (id) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      try {
        await axios.delete(`http://localhost:5000/api/jobs/${id}`);
        fetchJobs();
      } catch (err) {
        console.error('Delete error:', err);
      }
    }
  }, [fetchJobs]);

  const closeModals = useCallback(() => {
    setShowAddModal(false);
    setShowUpdateModal(false);
    setJobForm({
      title: '',
      company: '',
      location: '',
      type: 'full-time',
      salary_min: '',
      salary_max: '',
      description: '',
      requirements: '',
      benefits: '',
    });
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Job Board</h1>
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition whitespace-nowrap"
          >
            + Add Job
          </button>
        </div>

        <div className="bg-white rounded-xl shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-blue-50">
                <tr>
                  {['Title', 'Company', 'Location', 'Type', 'Salary', 'Status', 'Actions'].map(header => (
                    <th 
                      key={header}
                      className="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider"
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-gray-50">
                    <td className="px-4 py-4 text-sm text-gray-900 max-w-[150px] truncate" title={job.title}>
                      {job.title}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900 max-w-[120px] truncate" title={job.company}>
                      {job.company}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900 max-w-[120px] truncate" title={job.location}>
                      {job.location}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900 capitalize">
                      {job.type}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-900">
                      ${job.salary_min} - ${job.salary_max}
                    </td>
                    <td className="px-4 py-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        job.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {job.status}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleEditClick(job)}
                          className="text-blue-600 hover:text-blue-900 whitespace-nowrap"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDelete(job.id)}
                          className="text-red-600 hover:text-red-900 whitespace-nowrap"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showAddModal && (
        <JobModal 
          isUpdate={false} 
          jobForm={jobForm}
          handleChange={handleChange}
          handleSubmit={handleSubmit}
          closeModals={closeModals}
        />
      )}
      {showUpdateModal && (
        <JobModal 
          isUpdate={true} 
          jobForm={jobForm}
          handleChange={handleChange}
          handleSubmit={handleSubmit}
          closeModals={closeModals}
        />
      )}
    </div>
  );
};

export default PostJob;