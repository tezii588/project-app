import React, { useState } from 'react';
import { Star, Search, Download, UserPlus, MapPin, Briefcase, Award, ChevronDown } from 'lucide-react';
import { mockCandidates } from '../data/mockData';
import { NavigationPages } from '../types';

export default function Recommendations({ onNavigate }) {
  const [jobDescription, setJobDescription] = useState('');
  const [recommendations, setRecommendations] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchFilters, setSearchFilters] = useState({
    experience: 'all',
    location: 'all',
    matchThreshold: 80
  });

  const handleGetRecommendations = async () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setRecommendations(mockCandidates);
      setIsLoading(false);
    }, 2000);
  };

  const handleShortlist = (candidateId) => {
    setRecommendations(recommendations.map(candidate => 
      candidate.id === candidateId 
        ? { ...candidate, isShortlisted: true }
        : candidate
    ));
  };

  const filteredRecommendations = recommendations.filter(candidate => {
    if (searchFilters.experience === 'all' && 
        searchFilters.location === 'all' && 
        candidate.matchPercentage >= searchFilters.matchThreshold) {
      return true;
    }
    
    const experienceMatch = searchFilters.experience === 'all' || 
                          candidate.experience.includes(searchFilters.experience);
    const locationMatch = searchFilters.location === 'all' || 
                         candidate.location.includes(searchFilters.location);
    const matchMatch = candidate.matchPercentage >= searchFilters.matchThreshold;
    
    return experienceMatch && locationMatch && matchMatch;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
            <Star className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
              AI Recommendations
            </h1>
            <p className="text-gold-300/80">Get AI-powered candidate recommendations for your job openings</p>
          </div>
        </div>
      </div>

      {/* Job Description Input */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Job Description</h2>
        <div className="space-y-4">
          <textarea
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            className="w-full h-32 px-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300 resize-none"
            placeholder="Paste your job description here or describe the role you're looking to fill..."
          />
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={handleGetRecommendations}
              disabled={!jobDescription.trim() || isLoading}
              className="flex-1 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 disabled:from-gray-500 disabled:to-gray-600 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Analyzing...
                </>
              ) : (
                <>
                  <Search size={18} />
                  Get Recommendations
                </>
              )}
            </button>
            <button className="bg-white/5 hover:bg-white/10 text-gold-200 font-semibold py-3 px-6 rounded-xl transition-all duration-300 border border-white/20 hover:border-white/30">
              Use Template
            </button>
          </div>
        </div>
      </div>

      {/* Filters */}
      {recommendations.length > 0 && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Filter Results</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gold-200 mb-2">Experience Level</label>
              <select
                value={searchFilters.experience}
                onChange={(e) => setSearchFilters({...searchFilters, experience: e.target.value})}
                className="w-full px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
              >
                <option value="all">All Experience</option>
                <option value="3+">3+ Years</option>
                <option value="5+">5+ Years</option>
                <option value="7+">7+ Years</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gold-200 mb-2">Location</label>
              <select
                value={searchFilters.location}
                onChange={(e) => setSearchFilters({...searchFilters, location: e.target.value})}
                className="w-full px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
              >
                <option value="all">All Locations</option>
                <option value="San Francisco">San Francisco</option>
                <option value="New York">New York</option>
                <option value="Austin">Austin</option>
                <option value="Seattle">Seattle</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gold-200 mb-2">Min Match %</label>
              <select
                value={searchFilters.matchThreshold}
                onChange={(e) => setSearchFilters({...searchFilters, matchThreshold: parseInt(e.target.value)})}
                className="w-full px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
              >
                <option value={60}>60%+</option>
                <option value={70}>70%+</option>
                <option value={80}>80%+</option>
                <option value={90}>90%+</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Results */}
      {filteredRecommendations.length > 0 && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">
              Recommended Candidates ({filteredRecommendations.length})
            </h2>
            <div className="flex gap-2">
              <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-4 py-2 rounded-xl transition-all duration-300 border border-white/20 hover:border-white/30 flex items-center gap-2">
                <Download size={16} />
                Export
              </button>
              <button 
                onClick={() => onNavigate(NavigationPages.SHORTLIST)}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-4 py-2 rounded-xl transition-all duration-300 flex items-center gap-2"
              >
                <UserPlus size={16} />
                View Shortlist
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredRecommendations.map((candidate) => (
              <div
                key={candidate.id}
                className="backdrop-blur-sm bg-white/5 rounded-xl border border-white/10 p-6 hover:border-gold-400/30 transition-all duration-300 group"
              >
                <div className="flex items-start gap-4 mb-4">
                  <img
                    src={candidate.avatar}
                    alt={candidate.name}
                    className="w-16 h-16 rounded-xl object-cover border-2 border-gold-400/30"
                  />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg font-semibold text-white group-hover:text-gold-200 transition-colors">
                        {candidate.name}
                      </h3>
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <Star className="text-gold-400 w-4 h-4" />
                          <span className="text-gold-400 font-bold text-lg">{candidate.matchPercentage}%</span>
                        </div>
                        <p className="text-gold-300/60 text-xs">Match</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gold-300/70 mb-3">
                      <div className="flex items-center gap-1">
                        <Briefcase className="w-4 h-4" />
                        {candidate.experience}
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {candidate.location}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gold-200 mb-2">Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {candidate.skills.slice(0, 4).map((skill) => (
                      <span
                        key={skill}
                        className="bg-gold-500/20 text-gold-200 px-2 py-1 rounded-lg text-xs border border-gold-400/30"
                      >
                        {skill}
                      </span>
                    ))}
                    {candidate.skills.length > 4 && (
                      <span className="text-gold-300/60 text-xs px-2 py-1">
                        +{candidate.skills.length - 4} more
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => handleShortlist(candidate.id)}
                    disabled={candidate.isShortlisted}
                    className={`flex-1 py-2 px-4 rounded-xl font-medium transition-all duration-300 flex items-center justify-center gap-2 ${
                      candidate.isShortlisted
                        ? 'bg-green-500/20 text-green-400 border border-green-400/30 cursor-not-allowed'
                        : 'bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white shadow-lg shadow-gold-500/25'
                    }`}
                  >
                    {candidate.isShortlisted ? (
                      <>
                        <Award size={16} />
                        Shortlisted
                      </>
                    ) : (
                      <>
                        <UserPlus size={16} />
                        Shortlist
                      </>
                    )}
                  </button>
                  <button className="flex-1 bg-white/5 hover:bg-white/10 text-gold-200 py-2 px-4 rounded-xl font-medium transition-all duration-300 border border-white/20 hover:border-white/30 flex items-center justify-center gap-2">
                    <Download size={16} />
                    Resume
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {recommendations.length === 0 && !isLoading && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-gold-500 to-gold-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Star className="text-white w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Ready to Find Great Candidates?</h3>
          <p className="text-gold-300/70 mb-6">Enter a job description above to get AI-powered candidate recommendations</p>
        </div>
      )}
    </div>
  );
}