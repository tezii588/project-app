import React, { useState } from 'react';
import { Users, Calendar, Mail, Download, MapPin, Briefcase, Star, Award } from 'lucide-react';
import { mockCandidates } from '../data/mockData';
import { NavigationPages } from '../types';

export default function Shortlist({ onNavigate }) {
  const [shortlistedCandidates] = useState(
    mockCandidates.filter(candidate => candidate.isShortlisted)
  );

  const handleScheduleInterview = (candidateId) => {
    console.log('Schedule interview for candidate:', candidateId);
    onNavigate(NavigationPages.INTERVIEWS);
  };

  const handleSendEmail = (candidateId) => {
    console.log('Send email to candidate:', candidateId);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
              <Users className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
                Shortlisted Candidates
              </h1>
              <p className="text-gold-300/80">Manage your top candidate selections</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="backdrop-blur-sm bg-gold-500/20 border border-gold-400/30 rounded-xl px-4 py-2">
              <span className="text-gold-200 font-semibold">{shortlistedCandidates.length} Candidates</span>
            </div>
            <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-4 py-2 rounded-xl transition-all duration-300 border border-white/20 hover:border-white/30 flex items-center gap-2">
              <Download size={16} />
              Export List
            </button>
          </div>
        </div>
      </div>

      {/* Candidates Table */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl overflow-hidden">
        <div className="p-6 border-b border-white/10">
          <h2 className="text-lg font-semibold text-white">Candidate Overview</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white/5 border-b border-white/10">
              <tr>
                <th className="text-left py-4 px-6 text-gold-200 font-semibold">Candidate</th>
                <th className="text-left py-4 px-6 text-gold-200 font-semibold">Match %</th>
                <th className="text-left py-4 px-6 text-gold-200 font-semibold">Experience</th>
                <th className="text-left py-4 px-6 text-gold-200 font-semibold">Location</th>
                <th className="text-left py-4 px-6 text-gold-200 font-semibold">Top Skills</th>
                <th className="text-center py-4 px-6 text-gold-200 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {shortlistedCandidates.map((candidate, index) => (
                <tr 
                  key={candidate.id} 
                  className={`hover:bg-white/5 transition-all duration-300 ${
                    index !== shortlistedCandidates.length - 1 ? 'border-b border-white/5' : ''
                  }`}
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <img
                        src={candidate.avatar}
                        alt={candidate.name}
                        className="w-12 h-12 rounded-xl object-cover border-2 border-gold-400/30"
                      />
                      <div>
                        <h3 className="font-semibold text-white">{candidate.name}</h3>
                        <p className="text-gold-300/70 text-sm">{candidate.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      <Star className="text-gold-400 w-4 h-4" />
                      <span className="text-gold-400 font-bold">{candidate.matchPercentage}%</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2 text-gold-300">
                      <Briefcase className="w-4 h-4" />
                      {candidate.experience}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2 text-gold-300">
                      <MapPin className="w-4 h-4" />
                      {candidate.location}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex flex-wrap gap-1">
                      {candidate.skills.slice(0, 3).map((skill) => (
                        <span
                          key={skill}
                          className="bg-gold-500/20 text-gold-200 px-2 py-1 rounded-lg text-xs border border-gold-400/30"
                        >
                          {skill}
                        </span>
                      ))}
                      {candidate.skills.length > 3 && (
                        <span className="text-gold-300/60 text-xs px-2 py-1">
                          +{candidate.skills.length - 3}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => handleScheduleInterview(candidate.id)}
                        className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-3 py-2 rounded-lg font-medium transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40 flex items-center gap-2 text-sm"
                      >
                        <Calendar size={14} />
                        Interview
                      </button>
                      <button
                        onClick={() => handleSendEmail(candidate.id)}
                        className="bg-white/5 hover:bg-white/10 text-gold-200 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-white/20 hover:border-white/30 flex items-center gap-2 text-sm"
                      >
                        <Mail size={14} />
                        Email
                      </button>
                      <button className="bg-white/5 hover:bg-white/10 text-gold-200 px-3 py-2 rounded-lg font-medium transition-all duration-300 border border-white/20 hover:border-white/30 flex items-center gap-2 text-sm">
                        <Download size={14} />
                        Resume
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
              <Award className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{shortlistedCandidates.length}</p>
              <p className="text-gold-300/70 text-sm">Total Shortlisted</p>
            </div>
          </div>
        </div>

        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Star className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">
                {Math.round(shortlistedCandidates.reduce((acc, c) => acc + c.matchPercentage, 0) / shortlistedCandidates.length)}%
              </p>
              <p className="text-gold-300/70 text-sm">Avg Match Score</p>
            </div>
          </div>
        </div>

        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Calendar className="text-white w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">0</p>
              <p className="text-gold-300/70 text-sm">Interviews Scheduled</p>
            </div>
          </div>
        </div>
      </div>

      {/* Empty State */}
      {shortlistedCandidates.length === 0 && (
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-gold-500 to-gold-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Users className="text-white w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No Shortlisted Candidates Yet</h3>
          <p className="text-gold-300/70 mb-6">Start by getting AI recommendations and shortlisting your top candidates</p>
          <button
            onClick={() => onNavigate(NavigationPages.RECOMMENDATIONS)}
            className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40"
          >
            Find Candidates
          </button>
        </div>
      )}
    </div>
  );
}