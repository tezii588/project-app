// import React, { useState } from 'react';
// import { Mail, Lock, Crown, Eye, EyeOff } from 'lucide-react';
// import { NavigationPages } from '../types';

// export default function Login({ onNavigate }) {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [showPassword, setShowPassword] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setIsLoading(true);
    
//     // Simulate API call
//     setTimeout(() => {
//       setIsLoading(false);
//       onNavigate(NavigationPages.DASHBOARD);
//     }, 1500);
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
//       {/* Background Pattern */}
//       <div className="fixed inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(212,175,55,0.15),transparent_50%)] pointer-events-none"></div>
//       <div className="fixed inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(59,130,246,0.15),transparent_50%)] pointer-events-none"></div>
      
//       <div className="w-full max-w-md">
//         {/* Login Card */}
//         <div className="backdrop-blur-2xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl shadow-black/20 p-8">
//           {/* Header */}
//           <div className="text-center mb-8">
//             <div className="flex justify-center mb-4">
//               <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 via-gold-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-gold-500/25">
//                 <Crown className="text-white w-8 h-8" />
//               </div>
//             </div>
//             <h1 className="text-3xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent mb-2">
//               AI4Hr
//             </h1>
//             <p className="text-gold-300/80 text-sm">Premium Recruiting Platform</p>
//           </div>

//           {/* Login Form */}
//           <form onSubmit={handleSubmit} className="space-y-6">
//             {/* Email Field */}
//             <div className="space-y-2">
//               <label className="block text-sm font-medium text-gold-200">
//                 Email Address
//               </label>
//               <div className="relative">
//                 <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold-400 w-5 h-5" />
//                 <input
//                   type="email"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                   className="w-full pl-10 pr-4 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
//                   placeholder="Enter your email"
//                   required
//                 />
//               </div>
//             </div>

//             {/* Password Field */}
//             <div className="space-y-2">
//               <label className="block text-sm font-medium text-gold-200">
//                 Password
//               </label>
//               <div className="relative">
//                 <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold-400 w-5 h-5" />
//                 <input
//                   type={showPassword ? 'text' : 'password'}
//                   value={password}
//                   onChange={(e) => setPassword(e.target.value)}
//                   className="w-full pl-10 pr-12 py-3 bg-white/5 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-gold-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-400/20 focus:outline-none transition-all duration-300"
//                   placeholder="Enter your password"
//                   required
//                 />
//                 <button
//                   type="button"
//                   onClick={() => setShowPassword(!showPassword)}
//                   className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gold-400 hover:text-gold-300 transition-colors"
//                 >
//                   {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
//                 </button>
//               </div>
//             </div>

//             {/* Remember Me & Forgot Password */}
//             <div className="flex items-center justify-between text-sm">
//               <label className="flex items-center gap-2 text-gold-300">
//                 <input 
//                   type="checkbox" 
//                   className="w-4 h-4 bg-white/5 border border-white/20 rounded text-gold-500 focus:ring-gold-400/20 focus:ring-2"
//                 />
//                 Remember me
//               </label>
//               <button type="button" className="text-gold-400 hover:text-gold-300 transition-colors">
//                 Forgot password?
//               </button>
//             </div>

//             {/* Login Button */}
//             <button
//               type="submit"
//               disabled={isLoading}
//               className="w-full bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white font-semibold py-3 rounded-xl transition-all duration-300 shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
//             >
//               {isLoading ? (
//                 <>
//                   <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
//                   Signing in...
//                 </>
//               ) : (
//                 'Sign In'
//               )}
//             </button>
//           </form>

//           {/* Divider */}
//           <div className="my-6 flex items-center">
//             <div className="flex-1 border-t border-white/10"></div>
//             <span className="px-4 text-gold-300/60 text-sm">or</span>
//             <div className="flex-1 border-t border-white/10"></div>
//           </div>

//           {/* Demo Login */}
//           <button
//             onClick={() => onNavigate(NavigationPages.DASHBOARD)}
//             className="w-full bg-white/5 hover:bg-white/10 text-gold-200 font-medium py-3 rounded-xl transition-all duration-300 border border-white/10 hover:border-white/20 backdrop-blur-sm"
//           >
//             Continue with Demo Account
//           </button>

//           {/* Footer */}
//           <div className="mt-6 text-center text-xs text-gold-300/60">
//             <p>By signing in, you agree to our Terms of Service and Privacy Policy</p>
//           </div>
//         </div>

//         {/* Features */}
//         <div className="mt-8 grid grid-cols-3 gap-4 text-center">
//           <div className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10">
//             <Crown className="w-6 h-6 text-gold-400 mx-auto mb-2" />
//             <p className="text-xs text-gold-300">Premium AI</p>
//           </div>
//           <div className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10">
//             <Lock className="w-6 h-6 text-gold-400 mx-auto mb-2" />
//             <p className="text-xs text-gold-300">Secure Platform</p>
//           </div>
//           <div className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10">
//             <Mail className="w-6 h-6 text-gold-400 mx-auto mb-2" />
//             <p className="text-xs text-gold-300">24/7 Support</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }



import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login({ onLoginSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('recruiter'); // or 'candidate'
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', {
        email,
        password,
        role
      });

      // ✅ Paste this here
      if (response.data.message.toLowerCase().includes('success')) {
        alert('✅ ' + response.data.message);

        // Save role to localStorage if needed
        localStorage.setItem("role", role);

        onLoginSuccess(); // update auth state in App

        if (role === 'recruiter') {
          navigate('/recruiter/dashboard'); // ✅ fixed path
        } else {
          navigate('/candidate/dashboard');
        }
      } else {
        alert('❌ Login failed');
      }

    } catch (err) {
      console.error(err);
      alert('❌ Something went wrong during login');
    }
  };

  return (
    <form onSubmit={handleLogin} className="p-6">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
        className="block mb-3"
        required
      />
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        className="block mb-3"
        required
      />
      <select value={role} onChange={(e) => setRole(e.target.value)} className="block mb-3">
        <option value="recruiter">Recruiter</option>
        <option value="candidate">Candidate</option>
      </select>
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
        Login
      </button>
    </form>
  );
}

export default Login;
