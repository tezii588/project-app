export const mockUser = {
  id: '1',
  name: 'tejswi vinod',
  email: 'tejswi.johnson@ai4hr.com',
  avatar: 'https://images.pexels.com/photos/3992656/pexels-photo-3992656.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
  company: 'AI4Hr Technologies'
};

export const mockJobs = [
  {
    id: '1',
    title: 'Senior React Developer',
    description: 'We are looking for an experienced React developer to join our frontend team.',
    skills: ['React', 'TypeScript', 'Node.js', 'GraphQL'],
    experience: '5+ years',
    location: 'San Francisco, CA',
    type: 'Full-time',
    salary: '$120,000 - $150,000',
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    title: 'Product Manager',
    description: 'Strategic product manager to lead our AI-powered hiring platform development.',
    skills: ['Product Strategy', 'Agile', 'Analytics', 'AI/ML'],
    experience: '7+ years',
    location: 'Remote',
    type: 'Full-time',
    salary: '$140,000 - $180,000',
    createdAt: new Date('2024-01-10')
  }
];

export const mockCandidates = [
  {
    id: '1',
    name: 'Alex Chen',
    email: 'alex.chen@email.com',
    skills: ['React', 'TypeScript', 'Node.js', 'GraphQL', 'AWS'],
    experience: '6 years',
    resumeLink: '#',
    matchPercentage: 95,
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    location: 'San Francisco, CA',
    isShortlisted: true
  },
  {
    id: '2',
    name: 'Maria Rodriguez',
    email: 'maria.rodriguez@email.com',
    skills: ['React', 'JavaScript', 'Python', 'Docker'],
    experience: '5 years',
    resumeLink: '#',
    matchPercentage: 88,
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    location: 'Austin, TX',
    isShortlisted: true
  },
  {
    id: '3',
    name: 'David Kim',
    email: 'david.kim@email.com',
    skills: ['React', 'Vue.js', 'Node.js', 'MongoDB'],
    experience: '4 years',
    resumeLink: '#',
    matchPercentage: 82,
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    location: 'Seattle, WA',
    isShortlisted: false
  },
  {
    id: '4',
    name: 'tej',
    email: 'emily.johnson@email.com',
    skills: ['Product Strategy', 'Agile', 'Scrum', 'Analytics', 'Roadmapping'],
    experience: '8 years',
    resumeLink: '#',
    matchPercentage: 92,
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    location: 'New York, NY',
    isShortlisted: true
  }
];

export const mockInterviews = [
  {
    id: '1',
    candidateId: '1',
    candidateName: 'Alex Chen',
    jobTitle: 'Senior React Developer',
    date: '2024-01-25',
    time: '14:00',
    type: 'Video',
    status: 'Scheduled',
    meetingLink: 'https://meet.google.com/abc-defg-hij'
  },
  {
    id: '2',
    candidateId: '2',
    candidateName: 'Maria Rodriguez',
    jobTitle: 'Senior React Developer',
    date: '2024-01-26',
    time: '10:30',
    type: 'In-Person',
    status: 'Scheduled'
  },
  {
    id: '3',
    candidateId: '4',
    candidateName: 'tej',
    jobTitle: 'Product Manager',
    date: '2024-01-24',
    time: '16:00',
    type: 'Video',
    status: 'Completed',
    meetingLink: 'https://meet.google.com/xyz-uvwx-yz'
  }
];

export const mockOffers = [
  {
    id: '1',
    candidateId: '4',
    candidateName: 'tej',
    jobTitle: 'Product Manager',
    salary: '$160,000',
    startDate: '2024-02-15',
    status: 'Sent',
    createdAt: new Date('2024-01-20')
  },
  {
    id: '2',
    candidateId: '1',
    candidateName: 'Alex Chen',
    jobTitle: 'Senior React Developer',
    salary: '$135,000',
    startDate: '2024-02-01',
    status: 'Draft',
    createdAt: new Date('2024-01-22')
  }
];