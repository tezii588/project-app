import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "../index.css"
import { AIProvider } from "./website/contexts/AIContext";

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AIProvider>
      <App />
    </AIProvider>
  </React.StrictMode>
);
