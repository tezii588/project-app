import { useEffect, useState } from "react";
import axios from "axios";

const RecruiterApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/applications");
        setApplications(response.data);
      } catch (err) {
        console.error("Failed to fetch applications", err);
        setError("Failed to load applications. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchApplications();
  }, []);

  const updateStatus = async (id, status) => {
    try {
      await axios.put(`http://localhost:5000/api/applications/${id}/status`, { status });
      setApplications(apps =>
        apps.map(app => app.id === id ? { ...app, status } : app)
      );
    } catch (error) {
      console.error("Failed to update status", error);
      setError("Failed to update application status. Please try again.");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline"> {error}</span>
        </div>
      </div>
    );
  }

  if (applications.length === 0) {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">All Job Applications</h2>
        <div className="bg-white p-8 rounded-lg shadow text-center">
          <p className="text-gray-600">No applications found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <h2 className="text-2xl md:text-3xl font-bold mb-6 text-white">All Job Applications</h2>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {applications.map(app => (
          <div key={app.id} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 border border-gray-100">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{app.applicant_name}</h3>
                <p className="text-gray-600 text-sm">{app.email}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(app.status)}`}>
                {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium text-gray-500">Job Title</p>
                <p className="text-gray-800">{app.job_title}</p>
              </div>

              {app.ai_score && (
                <div>
                  <p className="text-sm font-medium text-gray-500">AI Match Score</p>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${app.ai_score > 70 ? 'bg-green-500' : app.ai_score > 40 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                      style={{ width: `${app.ai_score}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{app.ai_score}% match</p>
                </div>
              )}

              <div>
                <p className="text-sm font-medium text-gray-500">Resume</p>
                <a 
                  href={app.resume_url} 
                  target="_blank" 
                  rel="noreferrer" 
                  className="text-blue-600 hover:text-blue-800 text-sm underline inline-flex items-center"
                >
                  View Resume
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </a>
              </div>

              {app.cover_letter && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Cover Letter</p>
                  <p className="text-gray-700 text-sm line-clamp-3">{app.cover_letter}</p>
                </div>
              )}
            </div>

            {app.status === "pending" && (
              <div className="mt-6 flex space-x-3">
                <button 
                  onClick={() => updateStatus(app.id, "accepted")} 
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200"
                >
                  Accept
                </button>
                <button 
                  onClick={() => updateStatus(app.id, "rejected")} 
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200"
                >
                  Reject
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecruiterApplications;