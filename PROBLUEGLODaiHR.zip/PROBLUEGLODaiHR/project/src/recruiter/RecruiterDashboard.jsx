// import React from 'react';
// import { 
//   Users, 
//   Briefcase, 
//   Calendar, 
//   FileText, 
//   TrendingUp, 
//   Star,
//   Clock,
//   Award,
//   ChevronRight,
//   Activity
// } from 'lucide-react';
// import { mockCandidates, mockJobs, mockInterviews, mockOffers } from '../data/mockData';
// import { NavigationPages } from '../types';

// export default function Dashboard({ onNavigate }) {
//   const stats = [
//     {
//       label: 'Active Jobs',
//       value: mockJobs.length,
//       icon: Briefcase,
//       change: '+12%',
//       color: 'from-gold-500 to-gold-600'
//     },
//     {
//       label: 'Total Candidates',
//       value: mockCandidates.length,
//       icon: Users,
//       change: '+8%',
//       color: 'from-blue-500 to-blue-600'
//     },
//     {
//       label: 'Scheduled Interviews',
//       value: mockInterviews.filter(i => i.status === 'Scheduled').length,
//       icon: Calendar,
//       change: '+5%',
//       color: 'from-emerald-500 to-emerald-600'
//     },
//     {
//       label: 'Pending Offers',
//       value: mockOffers.filter(o => o.status === 'Sent').length,
//       icon: FileText,
//       change: '+3%',
//       color: 'from-purple-500 to-purple-600'
//     }
//   ];

//   const recentActivity = [
//     { type: 'interview', message: 'Interview scheduled with Alex Chen', time: '2 hours ago' },
//     { type: 'candidate', message: 'New candidate Maria Rodriguez shortlisted', time: '4 hours ago' },
//     { type: 'offer', message: 'Offer letter sent to tej', time: '1 day ago' },
//     { type: 'job', message: 'New job posted: Senior React Developer', time: '2 days ago' }
//   ];

//   const topCandidates = mockCandidates
//     .sort((a, b) => b.matchPercentage - a.matchPercentage)
//     .slice(0, 3);

//   return (
//     <div className="space-y-8">
//       {/* Header */}
//       <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-6">
//         <div className="flex items-center justify-between">
//           <div>
//             <h1 className="text-3xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
//               Welcome back, tejswi! 👋
//             </h1>
//             <p className="text-gold-300/80 mt-2">Here's what's happening with your recruitment today</p>
//           </div>
//           <div className="hidden md:flex items-center gap-4">
//             <div className="text-right">
//               <p className="text-sm text-gold-300/60">Today's Date</p>
//               <p className="text-gold-200 font-semibold">{new Date().toLocaleDateString()}</p>
//             </div>
//             <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
//               <Activity className="text-white w-6 h-6" />
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Stats Cards */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//         {stats.map((stat, index) => {
//           const Icon = stat.icon;
//           return (
//             <div key={index} className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6 hover:shadow-2xl transition-all duration-300 hover:bg-white/15 group">
//               <div className="flex items-center justify-between mb-4">
//                 <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-xl flex items-center justify-center shadow-lg shadow-black/10 group-hover:scale-110 transition-transform duration-300`}>
//                   <Icon className="text-white w-6 h-6" />
//                 </div>
//                 <span className="text-green-400 text-sm font-medium bg-green-400/10 px-2 py-1 rounded-lg">
//                   {stat.change}
//                 </span>
//               </div>
//               <div>
//                 <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
//                 <p className="text-gold-300/70 text-sm">{stat.label}</p>
//               </div>
//             </div>
//           );
//         })}
//       </div>

//       <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
//         {/* Top Candidates */}
//         <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
//           <div className="flex items-center justify-between mb-6">
//             <h2 className="text-xl font-bold text-white flex items-center gap-2">
//               <Star className="text-gold-400 w-5 h-5" />
//               Top Candidates
//             </h2>
//             <button
//               onClick={() => onNavigate(NavigationPages.RECOMMENDATIONS)}
//               className="text-gold-400 hover:text-gold-300 transition-colors text-sm font-medium flex items-center gap-1"
//             >
//               View All <ChevronRight size={16} />
//             </button>
//           </div>
//           <div className="space-y-4">
//             {topCandidates.map((candidate) => (
//               <div key={candidate.id} className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10 hover:border-gold-400/30 transition-all duration-300 group">
//                 <div className="flex items-center gap-4">
//                   <img
//                     src={candidate.avatar}
//                     alt={candidate.name}
//                     className="w-12 h-12 rounded-xl object-cover border-2 border-gold-400/30"
//                   />
//                   <div className="flex-1">
//                     <h3 className="font-semibold text-white group-hover:text-gold-200 transition-colors">
//                       {candidate.name}
//                     </h3>
//                     <p className="text-gold-300/60 text-sm">{candidate.experience} experience</p>
//                   </div>
//                   <div className="text-right">
//                     <div className="flex items-center gap-2 mb-1">
//                       <div className="w-2 h-2 bg-green-400 rounded-full"></div>
//                       <span className="text-green-400 font-bold text-lg">{candidate.matchPercentage}%</span>
//                     </div>
//                     <p className="text-gold-300/60 text-xs">Match</p>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>

//         {/* Recent Activity */}
//         <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
//           <div className="flex items-center justify-between mb-6">
//             <h2 className="text-xl font-bold text-white flex items-center gap-2">
//               <Clock className="text-gold-400 w-5 h-5" />
//               Recent Activity
//             </h2>
//             <button className="text-gold-400 hover:text-gold-300 transition-colors text-sm font-medium">
//               View All
//             </button>
//           </div>
//           <div className="space-y-4">
//             {recentActivity.map((activity, index) => (
//               <div key={index} className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10">
//                 <div className="flex items-start gap-3">
//                   <div className="w-2 h-2 bg-gold-400 rounded-full mt-2 flex-shrink-0"></div>
//                   <div className="flex-1">
//                     <p className="text-white text-sm">{activity.message}</p>
//                     <p className="text-gold-300/60 text-xs mt-1">{activity.time}</p>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* Quick Actions */}
//       <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
//         <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
//           <TrendingUp className="text-gold-400 w-5 h-5" />
//           Quick Actions
//         </h2>
//         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//           <button
//             onClick={() => onNavigate(NavigationPages.POST_JOB)}
//             className="backdrop-blur-sm bg-gradient-to-r from-gold-500/20 to-gold-600/20 border border-gold-400/30 rounded-xl p-6 text-left hover:from-gold-500/30 hover:to-gold-600/30 transition-all duration-300 group"
//           >
//             <Briefcase className="text-gold-400 w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
//             <h3 className="font-semibold text-white mb-2">Post New Job</h3>
//             <p className="text-gold-300/70 text-sm">Create and publish a new job opening</p>
//           </button>
          
//           <button
//             onClick={() => onNavigate(NavigationPages.RECOMMENDATIONS)}
//             className="backdrop-blur-sm bg-gradient-to-r from-blue-500/20 to-blue-600/20 border border-blue-400/30 rounded-xl p-6 text-left hover:from-blue-500/30 hover:to-blue-600/30 transition-all duration-300 group"
//           >
//             <Star className="text-blue-400 w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
//             <h3 className="font-semibold text-white mb-2">Find Candidates</h3>
//             <p className="text-gold-300/70 text-sm">Get AI-powered candidate recommendations</p>
//           </button>
          
//           <button
//             onClick={() => onNavigate(NavigationPages.INTERVIEWS)}
//             className="backdrop-blur-sm bg-gradient-to-r from-emerald-500/20 to-emerald-600/20 border border-emerald-400/30 rounded-xl p-6 text-left hover:from-emerald-500/30 hover:to-emerald-600/30 transition-all duration-300 group"
//           >
//             <Calendar className="text-emerald-400 w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
//             <h3 className="font-semibold text-white mb-2">Schedule Interview</h3>
//             <p className="text-gold-300/70 text-sm">Book interviews with shortlisted candidates</p>
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }

import React from 'react';
import {
  Users,
  Briefcase,
  Calendar,
  FileText,
  TrendingUp,
  Star,
  Clock,
  ChevronRight,
  Activity,
} from 'lucide-react';
import { mockCandidates, mockJobs, mockInterviews, mockOffers } from '../data/mockData';
import { NavigationPages } from '../types';


export default function RecruiterDashboard({ onNavigate }) {
  const stats = [
    {
      label: 'Active Jobs',
      value: mockJobs.length,
      icon: Briefcase,
      change: '+12%',
      color: 'from-gold-500 to-gold-600',
    },
    {
      label: 'Total Candidates',
      value: mockCandidates.length,
      icon: Users,
      change: '+8%',
      color: 'from-blue-500 to-blue-600',
    },
    {
      label: 'Scheduled Interviews',
      value: mockInterviews.filter(i => i.status === 'Scheduled').length,
      icon: Calendar,
      change: '+5%',
      color: 'from-emerald-500 to-emerald-600',
    },
    {
      label: 'Pending Offers',
      value: mockOffers.filter(o => o.status === 'Sent').length,
      icon: FileText,
      change: '+3%',
      color: 'from-purple-500 to-purple-600',
    },
  ];

  const recentActivity = [
    { type: 'interview', message: 'Interview scheduled with Alex Chen', time: '2 hours ago' },
    { type: 'candidate', message: 'New candidate Maria Rodriguez shortlisted', time: '4 hours ago' },
    { type: 'offer', message: 'Offer letter sent to tej', time: '1 day ago' },
    { type: 'job', message: 'New job posted: Senior React Developer', time: '2 days ago' },
  ];

  const topCandidates = mockCandidates
    .sort((a, b) => b.matchPercentage - a.matchPercentage)
    .slice(0, 3);

  return (
    <div className="space-y-8 p-6">
      {/* Header */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-gold-400 to-gold-200 bg-clip-text text-transparent">
              Welcome back, Tejaswi! 👋
            </h1>
            <p className="text-gold-300/80 mt-2">
              Here's what's happening with your recruitment today
            </p>
          </div>
          <div className="hidden md:flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-gold-300/60">Today's Date</p>
              <p className="text-gold-200 font-semibold">{new Date().toLocaleDateString()}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
              <Activity className="text-white w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6 hover:shadow-2xl transition-all duration-300 hover:bg-white/15 group"
            >
              <div className="flex items-center justify-between mb-4">
                <div
                  className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}
                >
                  <Icon className="text-white w-6 h-6" />
                </div>
                <span className="text-green-400 text-sm font-medium bg-green-400/10 px-2 py-1 rounded-lg">
                  {stat.change}
                </span>
              </div>
              <div>
                <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                <p className="text-gold-300/70 text-sm">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Top Candidates + Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Top Candidates */}
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Star className="text-gold-400 w-5 h-5" />
              Top Candidates
            </h2>
            <button
              onClick={() => onNavigate && onNavigate(NavigationPages.RECOMMENDATIONS)}
              className="text-gold-400 hover:text-gold-300 transition-colors text-sm font-medium flex items-center gap-1"
            >
              View All <ChevronRight size={16} />
            </button>
          </div>
          <div className="space-y-4">
            {topCandidates.map((candidate) => (
              <div
                key={candidate.id}
                className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10 hover:border-gold-400/30 transition-all duration-300 group"
              >
                <div className="flex items-center gap-4">
                  <img
                    src={candidate.avatar}
                    alt={candidate.name}
                    className="w-12 h-12 rounded-xl object-cover border-2 border-gold-400/30"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-white group-hover:text-gold-200 transition-colors">
                      {candidate.name}
                    </h3>
                    <p className="text-gold-300/60 text-sm">{candidate.experience} experience</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                      <span className="text-green-400 font-bold text-lg">{candidate.matchPercentage}%</span>
                    </div>
                    <p className="text-gold-300/60 text-xs">Match</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Clock className="text-gold-400 w-5 h-5" />
              Recent Activity
            </h2>
            <button className="text-gold-400 hover:text-gold-300 transition-colors text-sm font-medium">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="backdrop-blur-sm bg-white/5 rounded-xl p-4 border border-white/10"
              >
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-gold-400 rounded-full mt-2 flex-shrink-0"></div>
                  <div className="flex-1">
                    <p className="text-white text-sm">{activity.message}</p>
                    <p className="text-gold-300/60 text-xs mt-1">{activity.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <TrendingUp className="text-gold-400 w-5 h-5" />
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => onNavigate && onNavigate(NavigationPages.POST_JOB)}
            className="backdrop-blur-sm bg-gradient-to-r from-gold-500/20 to-gold-600/20 border border-gold-400/30 rounded-xl p-6 text-left hover:from-gold-500/30 hover:to-gold-600/30 transition-all duration-300 group"
          >
            <Briefcase className="text-gold-400 w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-white mb-2">Post New Job</h3>
            <p className="text-gold-300/70 text-sm">Create and publish a new job opening</p>
          </button>

          <button
            onClick={() => onNavigate && onNavigate(NavigationPages.RECOMMENDATIONS)}
            className="backdrop-blur-sm bg-gradient-to-r from-blue-500/20 to-blue-600/20 border border-blue-400/30 rounded-xl p-6 text-left hover:from-blue-500/30 hover:to-blue-600/30 transition-all duration-300 group"
          >
            <Star className="text-blue-400 w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-white mb-2">Find Candidates</h3>
            <p className="text-gold-300/70 text-sm">AI-powered candidate recommendations</p>
          </button>

          <button
            onClick={() => onNavigate && onNavigate(NavigationPages.INTERVIEWS)}
            className="backdrop-blur-sm bg-gradient-to-r from-emerald-500/20 to-emerald-600/20 border border-emerald-400/30 rounded-xl p-6 text-left hover:from-emerald-500/30 hover:to-emerald-600/30 transition-all duration-300 group"
          >
            <Calendar className="text-emerald-400 w-8 h-8 mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-white mb-2">Schedule Interview</h3>
            <p className="text-gold-300/70 text-sm">Book interviews with shortlisted candidates</p>
          </button>
        </div>
      </div>
    </div>
  );
}
