export const NavigationPages = {
  DASHBOARD: 'dashboard',
  POST_JOB: 'post-job',
  RECOMMENDATIONS: 'recommendations',
  SHORTLIST: 'shortlist',
  INTERVIEWS: 'interviews',
  OFFERS: 'offers',
  LOGIN: 'login'
};

export const InterviewTypes = {
  VIDEO: 'Video',
  IN_PERSON: 'In-Person',
  PHONE: 'Phone'
};

export const InterviewStatus = {
  SCHEDULED: 'Scheduled',
  COMPLETED: 'Completed',
  CANCELLED: 'Cancelled'
};

export const OfferStatus = {
  DRAFT: 'Draft',
  SENT: 'Sent',
  ACCEPTED: 'Accepted',
  REJECTED: 'Rejected'
};

export const JobTypes = {
  FULL_TIME: 'Full-time',
  PART_TIME: 'Part-time',
  CONTRACT: 'Contract'
};