export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  company: string;
}

export interface Job {
  id: string;
  title: string;
  description: string;
  skills: string[];
  experience: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Contract';
  salary?: string;
  createdAt: Date;
}

export interface Candidate {
  id: string;
  name: string;
  email: string;
  skills: string[];
  experience: string;
  resumeLink: string;
  matchPercentage: number;
  avatar?: string;
  location: string;
  isShortlisted: boolean;
}

export interface Interview {
  id: string;
  candidateId: string;
  candidateName: string;
  jobTitle: string;
  date: string;
  time: string;
  type: 'Video' | 'In-Person' | 'Phone';
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  meetingLink?: string;
}

export interface OfferLetter {
  id: string;
  candidateId: string;
  candidateName: string;
  jobTitle: string;
  salary: string;
  startDate: string;
  status: 'Draft' | 'Sent' | 'Accepted' | 'Rejected';
  createdAt: Date;
}

export type NavigationPage = 
  | 'dashboard' 
  | 'post-job' 
  | 'recommendations' 
  | 'shortlist' 
  | 'interviews' 
  | 'offers';