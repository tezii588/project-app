import React, { useState } from 'react';
import { Bot, FileText, Target, Search, Users, Sparkles, ArrowRight, Loader } from 'lucide-react';
import { useAI } from '../contexts/AIContext';

const AIFeatures = () => {
  const { generateResume, calculateJobMatch, optimizeJobSearch, generateCandidateRecommendations, isLoading } = useAI();
  const [activeFeature, setActiveFeature] = useState(null);
  const [results, setResults] = useState({});

  const features = [
    {
      id: 'resume',
      icon: FileText,
      title: 'AI Resume Generator',
      description: 'Create professional, ATS-optimized resumes in seconds',
      color: 'from-blue-500 to-cyan-500',
      demo: async () => {
        const sampleData = {
          name: 'John Doe',
          title: 'Software Developer',
          experience: '3 years in React and Node.js',
          skills: ['JavaScript', 'React', 'Node.js', 'MongoDB']
        };
        const result = await generateResume(sampleData);
        setResults(prev => ({ ...prev, resume: result }));
      }
    },
    {
      id: 'match',
      icon: Target,
      title: 'Job Match Score',
      description: 'Calculate compatibility between candidates and positions',
      color: 'from-green-500 to-emerald-500',
      demo: async () => {
        const sampleResume = 'Experienced React developer with 3 years experience';
        const sampleJob = 'Looking for React developer with JavaScript expertise';
        const result = await calculateJobMatch(sampleResume, sampleJob);
        setResults(prev => ({ ...prev, match: result }));
      }
    },
    {
      id: 'search',
      icon: Search,
      title: 'Smart Job Search',
      description: 'AI-powered job recommendations based on your profile',
      color: 'from-purple-500 to-pink-500',
      demo: async () => {
        const skills = ['React', 'JavaScript', 'Node.js'];
        const preferences = { location: 'Remote', experience: 'Mid-level' };
        const result = await optimizeJobSearch(skills, preferences);
        setResults(prev => ({ ...prev, search: result }));
      }
    },
    {
      id: 'candidates',
      icon: Users,
      title: 'Candidate Recommendations',
      description: 'Find perfect candidates for your job openings',
      color: 'from-orange-500 to-red-500',
      demo: async () => {
        const jobReqs = 'Senior React Developer with 5+ years experience, team leadership skills';
        const result = await generateCandidateRecommendations(jobReqs);
        setResults(prev => ({ ...prev, candidates: result }));
      }
    }
  ];

  const handleFeatureClick = async (feature) => {
    setActiveFeature(feature.id);
    try {
      await feature.demo();
    } catch (error) {
      console.error('Error running demo:', error);
    }
  };

  return (
    <section id="ai-features" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 px-6 py-3 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-yellow-400 mb-6">
            <Sparkles className="w-5 h-5" />
            <span className="text-sm font-semibold">AI-Powered Features</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-6">
            Experience the Future of
            <br />
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent">
              Recruitment Technology
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Our advanced AI algorithms transform every aspect of the hiring process, 
            making it faster, smarter, and more accurate than ever before.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {features.map((feature) => {
            const Icon = feature.icon;
            const isActive = activeFeature === feature.id;
            
            return (
              <div
                key={feature.id}
                className="group relative p-8 rounded-2xl bg-white/5 backdrop-blur-md border border-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer"
                onClick={() => handleFeatureClick(feature)}
              >
                {/* Background Gradient */}
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
                
                <div className="relative">
                  {/* Icon */}
                  <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${feature.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  {/* Content */}
                  <h3 className="text-2xl font-bold text-white mb-4">{feature.title}</h3>
                  <p className="text-gray-300 mb-6">{feature.description}</p>
                  
                  {/* Demo Button */}
                  <button
                    className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300 font-semibold group-hover:translate-x-1 transition-all duration-200"
                    disabled={isLoading}
                  >
                    {isLoading && isActive ? (
                      <>
                        <Loader className="w-5 h-5 animate-spin" />
                        <span>Processing...</span>
                      </>
                    ) : (
                      <>
                        <span>Try Demo</span>
                        <ArrowRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                  
                  {/* Results */}
                  {results[feature.id] && (
                    <div className="mt-6 p-4 rounded-xl bg-black/20 border border-white/10">
                      <h4 className="text-sm font-semibold text-yellow-400 mb-2">AI Result:</h4>
                      <p className="text-sm text-gray-300 line-clamp-4">{results[feature.id]}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive Demo Section */}
        <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-white mb-4">Ready to Experience AI Magic?</h3>
            <p className="text-gray-300">
              Click on any feature above to see our AI in action, or start building your perfect resume now.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-gradient-to-r from-yellow-400 to-yellow-500 text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
              <Bot className="w-5 h-5" />
              <span>Start Free Trial</span>
            </button>
            <button className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all duration-200">
              <span>View All Features</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIFeatures;