// // import React, { useState, useEffect } from 'react';
// // import { Link, useLocation } from 'react-router-dom';
// // import { Menu, X, Bot, Users, FileText } from 'lucide-react';

// // const Navbar = () => {
// //   const [isOpen, setIsOpen] = useState(false);
// //   const [isScrolled, setIsScrolled] = useState(false);
// //   const location = useLocation();

// //   useEffect(() => {
// //     const handleScroll = () => {
// //       setIsScrolled(window.scrollY > 20);
// //     };
// //     window.addEventListener('scroll', handleScroll);
// //     return () => window.removeEventListener('scroll', handleScroll);
// //   }, []);

// //   const navItems = [
// //     { name: 'Home', path: '/' },
// //     { name: 'Jobs', path: '/#jobs' },
// //     { name: 'AI Tools', path: '/#ai-features' },
// //     { name: 'Dashboard', path: '/candidate-dashboard' },
// //   ];

// //   return (
// //     <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
// //       isScrolled 
// //         ? 'bg-slate-900/90 backdrop-blur-md shadow-xl' 
// //         : 'bg-transparent'
// //     }`}>
// //       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
// //         <div className="flex items-center justify-between h-16">
// //           {/* Logo */}
// //           <Link to="/" className="flex items-center space-x-2 group">
// //             <div className="p-2 rounded-xl bg-gradient-to-r from-yellow-400 to-yellow-500 group-hover:scale-110 transition-transform duration-200">
// //               <Bot className="w-6 h-6 text-slate-900" />
// //             </div>
// //             <span className="text-xl font-bold text-white">AI Recruit</span>
// //           </Link>

// //           {/* Desktop Navigation */}
// //           <div className="hidden md:block">
// //             <div className="ml-10 flex items-baseline space-x-8">
// //               {navItems.map((item) => (
// //                 <Link
// //                   key={item.name}
// //                   to={item.path}
// //                   className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-white/10 hover:text-yellow-400 ${
// //                     location.pathname === item.path 
// //                       ? 'text-yellow-400 bg-white/10' 
// //                       : 'text-gray-300'
// //                   }`}
// //                 >
// //                   {item.name}
// //                 </Link>
// //               ))}
// //             </div>
// //           </div>

// //           {/* CTA Buttons */}
// //           <div className="hidden md:flex items-center space-x-4">
// //             <Link
// //               to="/resume-builder"
// //               className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-200 backdrop-blur-sm border border-white/20"
// //             >
// //               <FileText className="w-4 h-4" />
// //               <span>Resume Builder</span>
// //             </Link>
// //             <Link
// //               to="/recruiter-dashboard"
// //               className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-yellow-500 text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
// //             >
// //               <Users className="w-4 h-4" />
// //               <span>For Recruiters</span>
// //             </Link>
// //           </div>

// //           {/* Mobile menu button */}
// //           <div className="md:hidden">
// //             <button
// //               onClick={() => setIsOpen(!isOpen)}
// //               className="p-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 transition-all duration-200"
// //             >
// //               {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
// //             </button>
// //           </div>
// //         </div>

// //         {/* Mobile Navigation */}
// //         {isOpen && (
// //           <div className="md:hidden">
// //             <div className="px-2 pt-2 pb-3 space-y-1 bg-slate-900/95 backdrop-blur-md rounded-b-2xl mt-2">
// //               {navItems.map((item) => (
// //                 <Link
// //                   key={item.name}
// //                   to={item.path}
// //                   className={`block px-3 py-2 rounded-lg text-base font-medium transition-all duration-200 ${
// //                     location.pathname === item.path 
// //                       ? 'text-yellow-400 bg-white/10' 
// //                       : 'text-gray-300 hover:text-white hover:bg-white/10'
// //                   }`}
// //                   onClick={() => setIsOpen(false)}
// //                 >
// //                   {item.name}
// //                 </Link>
// //               ))}
// //               <div className="pt-4 border-t border-white/10">
// //                 <Link
// //                   to="/resume-builder"
// //                   className="block px-3 py-2 rounded-lg text-base font-medium text-gray-300 hover:text-white hover:bg-white/10 transition-all duration-200"
// //                   onClick={() => setIsOpen(false)}
// //                 >
// //                   Resume Builder
// //                 </Link>
// //                 <Link
// //                   to="/recruiter-dashboard"
// //                   className="block px-3 py-2 rounded-lg text-base font-medium text-yellow-400 hover:text-yellow-300 transition-all duration-200"
// //                   onClick={() => setIsOpen(false)}
// //                 >
// //                   For Recruiters
// //                 </Link>
// //               </div>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //     </nav>
// //   );
// // };

// // export default Navbar;


// import React, { useState, useEffect } from 'react';
// import { Link, useLocation } from 'react-router-dom';
// import { Menu, X, Bot, Users, FileText, LayoutDashboard } from 'lucide-react';

// const Navbar = () => {
//   const [isOpen, setIsOpen] = useState(false);
//   const [isScrolled, setIsScrolled] = useState(false);
//   const location = useLocation();

//   useEffect(() => {
//     const handleScroll = () => {
//       setIsScrolled(window.scrollY > 20);
//     };
//     window.addEventListener('scroll', handleScroll);
//     return () => window.removeEventListener('scroll', handleScroll);
//   }, []);

//   const navItems = [
//     { name: 'Home', path: '/' },
//     { name: 'Jobs', path: '/#jobs' },
//     { name: 'AI Tools', path: '/#ai-features' }
//   ];

//   return (
//     <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
//       isScrolled 
//         ? 'bg-slate-900/90 backdrop-blur-md shadow-xl' 
//         : 'bg-transparent'
//     }`}>
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//         <div className="flex items-center justify-between h-16">
//           {/* Logo */}
//           <Link to="/" className="flex items-center space-x-2 group">
//             <div className="p-2 rounded-xl bg-gradient-to-r from-yellow-400 to-yellow-500 group-hover:scale-110 transition-transform duration-200">
//               <Bot className="w-6 h-6 text-slate-900" />
//             </div>
//             <span className="text-xl font-bold text-white">AI Recruit</span>
//           </Link>

//           {/* Desktop Navigation */}
//           <div className="hidden md:block">
//             <div className="ml-10 flex items-baseline space-x-8">
//               {navItems.map((item) => (
//                 <Link
//                   key={item.name}
//                   to={item.path}
//                   className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-white/10 hover:text-yellow-400 ${
//                     location.pathname === item.path 
//                       ? 'text-yellow-400 bg-white/10' 
//                       : 'text-gray-300'
//                   }`}
//                 >
//                   {item.name}
//                 </Link>
//               ))}
//             </div>
//           </div>

//           {/* CTA Buttons */}
//           <div className="hidden md:flex items-center space-x-4">
//             <Link
//               to="/resume-builder"
//               className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-200 backdrop-blur-sm border border-white/20"
//             >
//               <FileText className="w-4 h-4" />
//               <span>Resume Builder</span>
//             </Link>
//             <Link
//               to="/dashboard-select"
//               className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-yellow-400 to-yellow-500 text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
//             >
//               <LayoutDashboard className="w-4 h-4" />
//               <span>Open Dashboard</span>
//             </Link>
//           </div>

//           {/* Mobile menu button */}
//           <div className="md:hidden">
//             <button
//               onClick={() => setIsOpen(!isOpen)}
//               className="p-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 transition-all duration-200"
//             >
//               {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
//             </button>
//           </div>
//         </div>

//         {/* Mobile Navigation */}
//         {isOpen && (
//           <div className="md:hidden">
//             <div className="px-2 pt-2 pb-3 space-y-1 bg-slate-900/95 backdrop-blur-md rounded-b-2xl mt-2">
//               {navItems.map((item) => (
//                 <Link
//                   key={item.name}
//                   to={item.path}
//                   className={`block px-3 py-2 rounded-lg text-base font-medium transition-all duration-200 ${
//                     location.pathname === item.path 
//                       ? 'text-yellow-400 bg-white/10' 
//                       : 'text-gray-300 hover:text-white hover:bg-white/10'
//                   }`}
//                   onClick={() => setIsOpen(false)}
//                 >
//                   {item.name}
//                 </Link>
//               ))}
//               <div className="pt-4 border-t border-white/10">
//                 <Link
//                   to="/resume-builder"
//                   className="block px-3 py-2 rounded-lg text-base font-medium text-gray-300 hover:text-white hover:bg-white/10 transition-all duration-200"
//                   onClick={() => setIsOpen(false)}
//                 >
//                   Resume Builder
//                 </Link>
//                 <Link
//                   to="/dashboard-select"
//                   className="block px-3 py-2 rounded-lg text-base font-medium text-yellow-400 hover:text-yellow-300 transition-all duration-200"
//                   onClick={() => setIsOpen(false)}
//                 >
//                   Open Dashboard
//                 </Link>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </nav>
//   );
// };

// export default Navbar;


import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Bot } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Jobs', path: '/#jobs' },
    { name: 'AI Tools', path: '/#ai-features' }
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-slate-900/90 backdrop-blur-md shadow-xl' 
        : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="p-2 rounded-xl bg-gradient-to-r from-yellow-400 to-yellow-500 group-hover:scale-110 transition-transform duration-200">
              <Bot className="w-6 h-6 text-slate-900" />
            </div>
            <span className="text-xl font-bold text-white">AI Recruit</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-white/10 hover:text-yellow-400 ${
                  location.pathname === item.path 
                    ? 'text-yellow-400 bg-white/10' 
                    : 'text-gray-300'
                }`}
              >
                {item.name}
              </Link>
            ))}

            {/* SINGLE CTA BUTTON */}
            <Link
              to="/login"
              className="ml-6 px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 text-slate-900 font-semibold rounded-xl hover:scale-105 transition-transform duration-200"
            >
              Begin with Visys
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 transition-all duration-200"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-slate-900/95 backdrop-blur-md rounded-b-2xl mt-2">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`block px-3 py-2 rounded-lg text-base font-medium transition-all duration-200 ${
                    location.pathname === item.path 
                      ? 'text-yellow-400 bg-white/10' 
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              {/* Mobile CTA */}
              <div className="pt-4 border-t border-white/10">
                <Link
                  to="/login"
                  className="block px-3 py-2 rounded-lg text-base font-medium text-yellow-400 hover:text-yellow-300 transition-all duration-200"
                  onClick={() => setIsOpen(false)}
                >
                  Begin with Visys
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
