import React, { useState } from 'react';
import { Plus, Users, Briefcase, BarChart3, Settings, Search, Filter, Star } from 'lucide-react';
import { useAI } from '../contexts/AIContext.jsx';

const RecruiterDashboard = () => {
  const { generateCandidateRecommendations, isLoading } = useAI();
  const [activeTab, setActiveTab] = useState('overview');
  const [candidates, setCandidates] = useState([]);

  const jobs = [
    {
      id: 1,
      title: 'Senior React Developer',
      department: 'Engineering',
      status: 'Active',
      applicants: 24,
      posted: '2024-01-15',
      views: 156
    },
    {
      id: 2,
      title: 'Product Manager',
      department: 'Product',
      status: 'Draft',
      applicants: 0,
      posted: '2024-01-20',
      views: 0
    }
  ];

  const handleFindCandidates = async (jobRequirements) => {
    try {
      const result = await generateCandidateRecommendations(jobRequirements);
      // Parse and format the AI response into candidate objects
      setCandidates([
        {
          id: 1,
          name: 'Sarah Johnson',
          title: 'Senior React Developer',
          experience: '5+ years',
          skills: ['React', 'TypeScript', 'Node.js'],
          matchScore: 94,
          location: 'San Francisco, CA'
        },
        {
          id: 2,
          name: 'Mike Chen',
          title: 'Frontend Engineer',
          experience: '4 years',
          skills: ['React', 'JavaScript', 'CSS'],
          matchScore: 89,
          location: 'Remote'
        }
      ]);
    } catch (error) {
      console.error('Error finding candidates:', error);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'jobs', label: 'Job Postings', icon: Briefcase },
    { id: 'candidates', label: 'Candidates', icon: Users },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Recruiter Dashboard</h1>
            <p className="text-gray-300">Manage your job postings and find the perfect candidates</p>
          </div>
          <button className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
            <Plus className="w-5 h-5" />
            <span>Post New Job</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 sticky top-24">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/20'
                          : 'text-gray-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Active Jobs</p>
                        <p className="text-2xl font-bold text-white">8</p>
                      </div>
                      <div className="p-3 bg-blue-500/10 rounded-xl">
                        <Briefcase className="w-6 h-6 text-blue-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Total Applicants</p>
                        <p className="text-2xl font-bold text-white">142</p>
                      </div>
                      <div className="p-3 bg-green-500/10 rounded-xl">
                        <Users className="w-6 h-6 text-green-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Interviews</p>
                        <p className="text-2xl font-bold text-white">28</p>
                      </div>
                      <div className="p-3 bg-yellow-500/10 rounded-xl">
                        <Star className="w-6 h-6 text-yellow-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Hire Rate</p>
                        <p className="text-2xl font-bold text-white">24%</p>
                      </div>
                      <div className="p-3 bg-purple-500/10 rounded-xl">
                        <BarChart3 className="w-6 h-6 text-purple-400" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* AI Insights */}
                <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                  <h3 className="text-xl font-bold text-white mb-4">AI Insights</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-yellow-400/10 border border-yellow-400/20 rounded-xl">
                      <p className="text-yellow-400 font-semibold mb-2">Recommendation</p>
                      <p className="text-gray-300">Consider expanding your React Developer search to include remote candidates to increase your candidate pool by 40%.</p>
                    </div>
                    <div className="p-4 bg-blue-400/10 border border-blue-400/20 rounded-xl">
                      <p className="text-blue-400 font-semibold mb-2">Trend Alert</p>
                      <p className="text-gray-300">JavaScript and React skills are in high demand. Average time-to-hire for these roles has increased by 15%.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Jobs Tab */}
            {activeTab === 'jobs' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Job Postings</h3>
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="text"
                        placeholder="Search jobs..."
                        className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      />
                    </div>
                    <button className="p-2 bg-white/10 border border-white/20 rounded-lg text-gray-400 hover:text-white">
                      <Filter className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  {jobs.map((job) => (
                    <div key={job.id} className="p-6 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="text-lg font-semibold text-white">{job.title}</h4>
                          <p className="text-gray-300">{job.department}</p>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
                          job.status === 'Active' 
                            ? 'bg-green-400/10 text-green-400' 
                            : 'bg-gray-400/10 text-gray-400'
                        }`}>
                          {job.status}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                        <div>
                          <p className="text-gray-400">Applicants</p>
                          <p className="text-white font-medium">{job.applicants}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Views</p>
                          <p className="text-white">{job.views}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Posted</p>
                          <p className="text-white">{job.posted}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <button
                          onClick={() => handleFindCandidates(`${job.title} requirements`)}
                          disabled={isLoading}
                          className="flex items-center space-x-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/20 rounded-lg text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200"
                        >
                          <Users className="w-4 h-4" />
                          <span>Find Candidates</span>
                        </button>
                        <div className="flex space-x-2">
                          <button className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 transition-all duration-200">
                            Edit
                          </button>
                          <button className="px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 hover:bg-blue-500/20 transition-all duration-200">
                            View Details
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Candidates Tab */}
            {activeTab === 'candidates' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">AI-Recommended Candidates</h3>
                
                {candidates.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No candidates found yet</p>
                    <p className="text-sm text-gray-500">Use "Find Candidates" on your job postings to discover AI-matched talent</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {candidates.map((candidate) => (
                      <div key={candidate.id} className="p-6 bg-white/5 rounded-xl border border-white/10">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-semibold text-white">{candidate.name}</h4>
                            <p className="text-gray-300">{candidate.title}</p>
                          </div>
                          <div className="flex items-center space-x-1 px-3 py-1 bg-green-400/10 rounded-full text-green-400 text-sm font-semibold">
                            <Star className="w-4 h-4" />
                            <span>{candidate.matchScore}%</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-4">
                          {candidate.skills.map((skill, index) => (
                            <span key={index} className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300 border border-white/20">
                              {skill}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-400">
                            <span>{candidate.experience} • {candidate.location}</span>
                          </div>
                          <div className="flex space-x-2">
                            <button className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 transition-all duration-200">
                              View Profile
                            </button>
                            <button className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-lg text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                              Contact
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecruiterDashboard;