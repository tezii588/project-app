// import { createContext, useContext, useState, useCallback } from 'react'

// const CurrencyContext = createContext()

// export const useCurrency = () => useContext(CurrencyContext)

// export const CurrencyProvider = ({ children }) => {
//   const [currency, setCurrency] = useState({
//     code: 'USD',
//     symbol: '$',
//     rate: 1
//   })

//   // Exchange rates (simplified for demonstration)
//   // In a real app, you would fetch these from an API
//   const exchangeRates = {
//     USD: 1,
//     INR: 83.24,
//     EUR: 0.92,
//     GBP: 0.79,
//     CAD: 1.36,
//     AUD: 1.51
//   }

//   const currencySymbols = {
//     USD: '$',
//     INR: '₹',
//     EUR: '€',
//     GBP: '£',
//     CAD: 'C$',
//     AUD: 'A$'
//   }

//   const detectUserCurrency = useCallback(async () => {
//     try {
//       // Using a geolocation API to detect user's country
//       const response = await fetch('https://ipapi.co/json/')
//       const data = await response.json()
      
//       // Define country to currency mapping
//       const countryCurrency = {
//         IN: 'INR',
//         US: 'USD',
//         GB: 'GBP',
//         CA: 'CAD',
//         AU: 'AUD',
//         // Add more countries as needed
//       }
      
//       // Default to USD if country not found in mapping
//       const detectedCurrencyCode = countryCurrency[data.country_code] || 'USD'
      
//       setCurrency({
//         code: detectedCurrencyCode,
//         symbol: currencySymbols[detectedCurrencyCode],
//         rate: exchangeRates[detectedCurrencyCode]
//       })
//     } catch (error) {
//       console.error('Error detecting user currency:', error)
//       // Default to USD on error
//       setCurrency({
//         code: 'USD',
//         symbol: '$',
//         rate: 1
//       })
//     }
//   }, [])

//   const changeCurrency = (currencyCode) => {
//     if (exchangeRates[currencyCode]) {
//       setCurrency({
//         code: currencyCode,
//         symbol: currencySymbols[currencyCode],
//         rate: exchangeRates[currencyCode]
//       })
//     }
//   }

//   const formatPrice = (priceInUSD) => {
//     const convertedPrice = priceInUSD * currency.rate
    
//     // Format based on currency
//     if (currency.code === 'INR') {
//       return `${currency.symbol}${Math.round(convertedPrice)}`
//     }
    
//     return `${currency.symbol}${convertedPrice.toFixed(2)}`
//   }

//   return (
//     <CurrencyContext.Provider value={{ 
//       currency, 
//       changeCurrency, 
//       formatPrice,
//       detectUserCurrency,
//       availableCurrencies: Object.keys(exchangeRates)
//     }}>
//       {children}
//     </CurrencyContext.Provider>
//   )
// }




// import React, { createContext, useContext, useState } from 'react';

// const CurrencyContext = createContext(undefined);

// // Exchange rate (1 USD = 75 INR)
// const USD_TO_INR = 75;

// export const CurrencyProvider = ({ children }) => {
//   const [currency, setCurrency] = useState('USD');

//   const convertPrice = (price) => {
//     if (currency === 'INR') {
//       return price * USD_TO_INR;
//     }
//     return price;
//   };

//   const formatPrice = (price) => {
//     const convertedPrice = convertPrice(price);

// if (currency === 'INR') {
//   return `₹${convertedPrice.toFixed(2)}`;
// }

// return `$${convertedPrice.toFixed(2)}`;
//   };

//   return (
//     <CurrencyContext.Provider value={{ currency, setCurrency, formatPrice, convertPrice }}>
//       {children}
//     </CurrencyContext.Provider>
//   );
// };

// export const useCurrency = () => {
//   const context = useContext(CurrencyContext);
//   if (!context) {
//     throw new Error('useCurrency must be used within a CurrencyProvider');
//   }
//   return context;
// };



// context/CurrencyContext.js
import { createContext, useContext, useState, useEffect } from 'react'

const CurrencyContext = createContext(undefined)
const USD_TO_INR = 75

export const CurrencyProvider = ({ children }) => {
  const [currency, setCurrency] = useState(() => {
    const saved = localStorage.getItem('currency')
    return saved || 'USD'
  })

  useEffect(() => {
    const detectCurrency = async () => {
      if (!localStorage.getItem('currency')) {
        try {
          const response = await fetch('https://ipapi.co/json/')
          const data = await response.json()
          if (data.country_code === 'IN') setCurrency('INR')
        } catch (error) {
          console.error('Error detecting location:', error)
        }
      }
    }
    detectCurrency()
  }, [])

  const convertPrice = (price) => 
    currency === 'INR' ? price * USD_TO_INR : price

  const formatPrice = (price) => {
    const converted = convertPrice(price)
    return currency === 'INR' 
      ? `₹${converted.toFixed(2)}`
      : `$${converted.toFixed(2)}`
  }

  const updateCurrency = (newCurrency) => {
    localStorage.setItem('currency', newCurrency)
    setCurrency(newCurrency)
  }

  return (
    <CurrencyContext.Provider 
      value={{ currency, setCurrency: updateCurrency, formatPrice, convertPrice }}
    >
      {children}
    </CurrencyContext.Provider>
  )
}

// Add this custom hook export
export const useCurrency = () => {
  const context = useContext(CurrencyContext)
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider')
  }
  return context
}