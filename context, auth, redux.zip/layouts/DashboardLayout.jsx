// import { useState } from 'react';
// import { Outlet, Link, NavLink, useNavigate } from 'react-router-dom';
// import { motion } from 'framer-motion';
// import { 
//   BookOpen, Home, Layers, User, LogOut, Menu, X, Bell, 
//   Settings, ChevronDown
// } from 'lucide-react';
// import { useAuth } from '../context/AuthContext';

// const DashboardLayout = () => {
//   const [isSidebarOpen, setIsSidebarOpen] = useState(false);
//   const [isProfileOpen, setIsProfileOpen] = useState(false);
//   const { user, logout } = useAuth();
  
//   const toggleSidebar = () => {
//     setIsSidebarOpen(!isSidebarOpen);
//   };
  
//   const navLinkClasses = ({ isActive }) => 
//     `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
//       isActive 
//         ? 'text-primary-600 bg-primary-50 font-medium' 
//         : 'text-gray-600 hover:text-primary-600 hover:bg-gray-50'
//     }`;
  
//   const sidebarLinks = [
//     { to: '/dashboard', icon: <Home className="h-5 w-5" />, label: 'Dashboard' },
//     { to: '/dashboard/courses', icon: <Layers className="h-5 w-5" />, label: 'My Courses' },
//     { to: '/dashboard/profile', icon: <User className="h-5 w-5" />, label: 'Profile' },
//   ];
  
//   return (
//     <div className="min-h-screen bg-gray-50 flex">
//       {/* Mobile sidebar backdrop */}
//       {isSidebarOpen && (
//         <div 
//           className="fixed inset-0 bg-gray-900 bg-opacity-50 z-20 md:hidden"
//           onClick={toggleSidebar}
//         ></div>
//       )}
      
//       {/* Sidebar */}
//       <motion.aside
//         className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform ${
//           isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
//         } md:translate-x-0 transition-transform duration-300 ease-in-out`}
//         initial={false}
//       >
//         <div className="h-full flex flex-col">
//           {/* Sidebar header */}
//           <div className="h-16 flex items-center justify-center border-b px-4">
//             <Link to="/" className="flex items-center space-x-2">
//               <BookOpen className="h-7 w-7 text-primary-600" />
//               <span className="text-xl font-bold text-gray-900">AI4CoolKids</span>
//             </Link>
//             <button 
//               className="md:hidden absolute top-4 right-4 text-gray-500"
//               onClick={toggleSidebar}
//             >
//               <X className="h-5 w-5" />
//             </button>
//           </div>
          
//           {/* Navigation links */}
//           <nav className="flex-1 py-6 px-3 overflow-y-auto">
//             <div className="space-y-1">
//               {sidebarLinks.map((link) => (
//                 <NavLink
//                   key={link.to}
//                   to={link.to}
//                   className={navLinkClasses}
//                   onClick={() => setIsSidebarOpen(false)}
//                 >
//                   {link.icon}
//                   <span>{link.label}</span>
//                 </NavLink>
//               ))}
//             </div>
            
//             <div className="mt-10 pt-6 border-t">
//               <button
//                 onClick={logout}
//                 className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-600 hover:text-red-600 hover:bg-gray-50 w-full transition-colors"
//               >
//                 <LogOut className="h-5 w-5" />
//                 <span>Logout</span>
//               </button>
//             </div>
//           </nav>
//         </div>
//       </motion.aside>
      
//       {/* Main content */}
//       <div className="flex-1 flex flex-col md:pl-64">
//         {/* Topbar */}
//         <header className="bg-white shadow-sm h-16 flex items-center px-4">
//           <button
//             className="md:hidden text-gray-600 hover:text-gray-900"
//             onClick={toggleSidebar}
//           >
//             <Menu className="h-6 w-6" />
//           </button>
          
//           <div className="flex-1"></div>
          
//           <div className="flex items-center space-x-4">
//             {/* Notifications */}
//             <button className="relative text-gray-600 hover:text-gray-900">
//               <Bell className="h-5 w-5" />
//               <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-primary-600"></span>
//             </button>
            
//             {/* User Profile */}
//             <div className="relative">
//               <button
//                 className="flex items-center space-x-2"
//                 onClick={() => setIsProfileOpen(!isProfileOpen)}
//               >
//                 <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
//                   <img 
//                     src="https://randomuser.me/api/portraits/men/32.jpg" 
//                     alt="Profile" 
//                     className="w-full h-full object-cover"
//                   />
//                 </div>
//                 <span className="hidden md:block text-sm font-medium text-gray-700">
//                   {user?.name || 'User'}
//                 </span>
//                 <ChevronDown className="h-4 w-4 text-gray-500" />
//               </button>
              
//               {/* Dropdown menu */}
//               {isProfileOpen && (
//                 <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
//                   <Link
//                     to="/dashboard/profile"
//                     className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                     onClick={() => setIsProfileOpen(false)}
//                   >
//                     Your Profile
//                   </Link>
//                   <Link
//                     to="/dashboard/settings"
//                     className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
//                     onClick={() => setIsProfileOpen(false)}
//                   >
//                     Settings
//                   </Link>
//                   <div className="border-t border-gray-100 my-1"></div>
//                   <button
//                     onClick={() => {
//                       logout();
//                       setIsProfileOpen(false);
//                     }}
//                     className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
//                   >
//                     Sign out
//                   </button>
//                 </div>
//               )}
//             </div>
//           </div>
//         </header>
        
//         {/* Page content */}
//         <motion.main 
//           className="flex-1 p-6"
//           initial={{ opacity: 0 }}
//           animate={{ opacity: 1 }}
//           transition={{ duration: 0.3 }}
//         >
//           <Outlet />
//         </motion.main>
//       </div>
//     </div>
//   );
// };

// export default DashboardLayout;



import { motion } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import {
    Bell,
    BookOpen,
    ChevronDown,
    Home, Layers,
    LogOut as LogOutIcon, Menu,
    User as UserIcon,
    X,
    Megaphone,
    FileText
} from 'lucide-react';

import { useDispatch, useSelector } from 'react-redux';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { logout } from '../redux/slices/authSlice';

const DashboardLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.auth.user);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };


  const [profileImage, setProfileImage] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    const savedImage = localStorage.getItem("profileImage");
    if (savedImage) {
      setProfileImage(savedImage);
    }
  }, []);

  useEffect(() => {
    if (profileImage) {
      localStorage.setItem("profileImage", profileImage);
    }
  }, [profileImage]);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };





  
  // const navLinkClasses = ({ isActive }) => 
  //   `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
  //     isActive 
  //       ? 'text-primary-600 bg-primary-50 font-medium' 
  //       : 'text-gray-600 hover:text-primary-600 hover:bg-gray-50'
  //   }`;
  
  const sidebarLinks = [
    { to: '/dashboard', icon: <Home className="h-5 w-5" />, label: 'Dashboard' },
    { to: '/dashboard/courses', icon: <Layers className="h-5 w-5" />, label: 'My Courses' },
    // { to: '/dashboard/profile', icon: <UserIcon className="h-5 w-5" />, label: 'Profile' },
    { to: '/dashboard/lessons', icon: <FileText className="h-5 w-5" />, label: 'Lessons' },
      { to: '/dashboard/annnouncementlist', icon: <Megaphone className="h-5 w-5" />, label: 'Announcements' },
  ];
  
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-900 bg-opacity-50 z-20 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
      
      {/* Sidebar */}
      <motion.aside
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0 transition-transform duration-300 ease-in-out`}
        initial={false}
      >
        <div className="h-full flex flex-col">
          {/* Sidebar header */}
          <div className="h-16 flex items-center justify-center border-b px-4">
            <Link to="/" className="flex items-center space-x-2">
              <BookOpen className="h-7 w-7 text-primary-600" />
              <span className="text-xl font-bold text-gray-900">AI4CoolKids</span>
            </Link>
            <button 
              className="md:hidden absolute top-4 right-4 text-gray-500"
              onClick={toggleSidebar}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          {/* Navigation links */}
          <nav className="flex-1 py-6 px-3 overflow-y-auto">
            <div className="space-y-1">
              {sidebarLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  // className={navLinkClasses}
                  onClick={() => setIsSidebarOpen(false)}
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50 transition-colors"
                  
                >
                  {link.icon}
                  <span>{link.label}</span>
                </NavLink>
              ))}

              {/* <a href="http://94.136.184.245:5174/" target="_blank" rel="noopener noreferrer">
                Play Ground
              </a> */}
              <a
                href="http://94.136.184.245:5174/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-600 hover:text-primary-600 hover:bg-gray-50 transition-colors"
              >
                <Layers className="h-5 w-5" />
                <span>Play Ground</span>
              </a>
            </div>
            
            
            <div className="mt-10 pt-6 border-t">
              <button
                onClick={handleLogout}
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-600 hover:text-red-600 hover:bg-gray-50 w-full transition-colors"
              >
                <LogOutIcon className="h-5 w-5" />
                <span>Logout</span>
              </button>
            </div>
          </nav>
        </div>
      </motion.aside>
      
      {/* Main content */}
      <div className="flex-1 flex flex-col md:pl-64">
        {/* Topbar */}
        <header className="bg-white shadow-sm h-16 flex items-center px-4">
          <button
            className="md:hidden text-gray-600 hover:text-gray-900"
            onClick={toggleSidebar}
          >
            <Menu className="h-6 w-6" />
          </button>
          
          <div className="flex-1"></div>
          
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <button className="relative text-gray-600 hover:text-gray-900">
              <Bell className="h-5 w-5" />
              <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-primary-600"></span>
            </button>
            
            {/* User Profile */}
            <div className="relative">
              <button
                className="flex items-center space-x-2"
                onClick={() => setIsProfileOpen(!isProfileOpen)}
              >
                {/* <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                  <img 
                    src="https://randomuser.me/api/portraits/men/10.jpg" 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                </div> */}

                
                <span className="hidden md:block text-sm font-medium text-gray-700">
                  {user?.name || 'User'}
                </span>
                <ChevronDown className="h-4 w-4 text-gray-500" />
              </button>
              
              {/* Dropdown menu */}
              {isProfileOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
                  {/* <Link
                    to="/dashboard/profile"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={() => setIsProfileOpen(false)}
                  >
                    Your Profile
                  </Link>
                  <Link
                    to="/dashboard/settings"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    onClick={() => setIsProfileOpen(false)}
                  >
                    Settings
                  </Link> */}
                  <div className="border-t border-gray-100 my-1"></div>
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsProfileOpen(false);
                    }}
                    className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                  >
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>
        
        {/* Page content */}
        <motion.main 
          className="flex-1 p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Outlet />
        </motion.main>
      </div>
    </div>
  );
};

export default DashboardLayout;






