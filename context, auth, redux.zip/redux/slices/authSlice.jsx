
import { createSlice } from '@reduxjs/toolkit';

// Hydrate initial state from localStorage
const storedToken = localStorage.getItem('authToken');
const storedUser  = localStorage.getItem('authUser');

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: storedUser ? JSON.parse(storedUser) : null,
    token: storedToken || null,
  },
  reducers: {
    loginSuccess: (state, action) => {
      const { user, token } = action.payload;
      state.user  = user;
      state.token = token;
      // persist to localStorage
      localStorage.setItem('authUser', JSON.stringify(user));
      localStorage.setItem('authToken', token);
    },
    logout: (state) => {
      state.user  = null;
      state.token = null;
      // clear storage
      localStorage.removeItem('authUser');
      localStorage.removeItem('authToken');
    },
  },
});

export const { loginSuccess, logout } = authSlice.actions;
export default authSlice.reducer;
