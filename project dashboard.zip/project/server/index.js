const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const { Pool } = require('pg');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: "http://localhost:5173",
  credentials: true
}));
app.use(express.json());

// Database connection
const pool = new Pool({
  user: 'hradmin',
  host: '156.67.104.162',
  database: 'ai4hrdb',
  password: 'sysivwelcome@321',
  port: 5432,
  ssl: {
    rejectUnauthorized: false
  }
});

// Test database connection
pool.connect((err, client, release) => {
  if (err) {
    console.error('Error acquiring client', err.stack);
  } else {
    console.log('Connected to PostgreSQL database');
    release();
  }
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Join room based on user role
  socket.on('join', (data) => {
    const { userRole, userId } = data;
    socket.join(`${userRole}_${userId}`);
    console.log(`User ${userId} joined ${userRole} room`);
  });

  // Handle new job application
  socket.on('newApplication', (applicationData) => {
    // Broadcast to all recruiters
    socket.broadcast.emit('newApplication', applicationData);
  });

  // Handle application status updates
  socket.on('updateApplicationStatus', (updateData) => {
    // Broadcast to specific candidate
    socket.broadcast.emit('applicationStatusUpdate', updateData);
  });

  // Handle interview scheduling
  socket.on('scheduleInterview', (interviewData) => {
    // Broadcast to candidate
    socket.broadcast.emit('interviewScheduled', interviewData);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// API Routes

// Jobs routes
app.get('/api/jobs', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM jobs ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/jobs', async (req, res) => {
  try {
    const { title, department, location, type, requirements, responsibilities, description, salary, skills } = req.body;
    
    const result = await pool.query(
      `INSERT INTO jobs (title, department, location, type, requirements, responsibilities, description, salary, skills, status, created_at) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW()) 
       RETURNING *`,
      [title, department, location, type, requirements, responsibilities, description, salary, skills, 'Active']
    );
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Applications routes
app.get('/api/applications', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT a.*, j.title as job_title, u.name as candidate_name, u.email as candidate_email
      FROM applications a
      JOIN jobs j ON a.job_id = j.id
      JOIN users u ON a.candidate_id = u.id
      ORDER BY a.created_at DESC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/applications', async (req, res) => {
  try {
    const { candidateId, jobId, resumeUrl, coverLetter } = req.body;
    
    const result = await pool.query(
      `INSERT INTO applications (candidate_id, job_id, resume_url, cover_letter, status, created_at) 
       VALUES ($1, $2, $3, $4, $5, NOW()) 
       RETURNING *`,
      [candidateId, jobId, resumeUrl, coverLetter, 'Under Review']
    );
    
    // Emit real-time notification
    io.emit('newApplication', result.rows[0]);
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update application status
app.put('/api/applications/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    const result = await pool.query(
      'UPDATE applications SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
      [status, id]
    );
    
    // Emit real-time notification
    io.emit('applicationStatusUpdate', result.rows[0]);
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Interview routes
app.get('/api/interviews', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT i.*, a.candidate_id, u.name as candidate_name, j.title as job_title
      FROM interviews i
      JOIN applications a ON i.application_id = a.id
      JOIN users u ON a.candidate_id = u.id
      JOIN jobs j ON a.job_id = j.id
      ORDER BY i.scheduled_date ASC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/interviews', async (req, res) => {
  try {
    const { applicationId, scheduledDate, type, location, notes } = req.body;
    
    const result = await pool.query(
      `INSERT INTO interviews (application_id, scheduled_date, type, location, notes, status, created_at) 
       VALUES ($1, $2, $3, $4, $5, $6, NOW()) 
       RETURNING *`,
      [applicationId, scheduledDate, type, location, notes, 'Scheduled']
    );
    
    // Emit real-time notification
    io.emit('interviewScheduled', result.rows[0]);
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Analytics routes
app.get('/api/analytics/dashboard', async (req, res) => {
  try {
    const activeJobs = await pool.query('SELECT COUNT(*) FROM jobs WHERE status = $1', ['Active']);
    const totalApplications = await pool.query('SELECT COUNT(*) FROM applications');
    const shortlistedApplications = await pool.query('SELECT COUNT(*) FROM applications WHERE status = $1', ['Shortlisted']);
    const scheduledInterviews = await pool.query('SELECT COUNT(*) FROM interviews WHERE status = $1', ['Scheduled']);
    
    const shortlistRatio = totalApplications.rows[0].count > 0 
      ? Math.round((shortlistedApplications.rows[0].count / totalApplications.rows[0].count) * 100)
      : 0;
    
    res.json({
      activeJobs: parseInt(activeJobs.rows[0].count),
      totalApplications: parseInt(totalApplications.rows[0].count),
      shortlistRatio,
      interviewsScheduled: parseInt(scheduledInterviews.rows[0].count)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});