import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import RecruiterDashboard from './components/RecruiterDashboard';
import CandidateDashboard from './components/CandidateDashboard';
import Navigation from './components/Navigation';
import { Toaster } from 'react-hot-toast';
import { initializeSocket } from './services/socket';

function App() {
  const [userRole, setUserRole] = useState('recruiter'); // Default to recruiter
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    // Initialize socket connection
    const socketInstance = initializeSocket();
    setSocket(socketInstance);

    return () => {
      if (socketInstance) {
        socketInstance.disconnect();
      }
    };
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-primary-900 via-purple-900 to-primary-800">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-purple-500/20 to-gold-500/20"></div>
        <div className="relative z-10">
          <Navigation userRole={userRole} setUserRole={setUserRole} />
          
          <Routes>
            <Route 
              path="/" 
              element={<Navigate to={userRole === 'recruiter' ? '/recruiter' : '/candidate'} replace />} 
            />
            <Route 
              path="/recruiter" 
              element={<RecruiterDashboard socket={socket} />} 
            />
            <Route 
              path="/candidate" 
              element={<CandidateDashboard socket={socket} />} 
            />
          </Routes>
          
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                color: '#fff',
              },
            }}
          />
        </div>
      </div>
    </Router>
  );
}

export default App;