import React, { useState, useEffect } from 'react';
import { 
  Search, 
  MapPin, 
  Clock, 
  DollarSign,
  BookOpen,
  TrendingUp,
  FileText,
  Award,
  Target,
  Eye,
  Heart,
  Send
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import ResumeAnalyzer from './ResumeAnalyzer';
import JobRecommendations from './JobRecommendations';
import { toast } from 'react-hot-toast';

const CandidateDashboard = ({ socket }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [profile, setProfile] = useState({
    name: 'Alex Johnson',
    title: 'Full Stack Developer',
    location: 'San Francisco, CA',
    experience: '5 years',
    skills: ['React', 'Node.js', 'Python', 'AWS', 'PostgreSQL'],
    resumeScore: 78
  });

  const [applications, setApplications] = useState([
    {
      id: 1,
      jobTitle: 'Senior React Developer',
      company: 'Tech Corp',
      location: 'Remote',
      salary: '$120k - $150k',
      status: 'Under Review',
      appliedDate: '2024-01-20',
      matchScore: 87
    },
    {
      id: 2,
      jobTitle: 'Full Stack Engineer',
      company: 'StartupXYZ',
      location: 'San Francisco',
      salary: '$100k - $130k',
      status: 'Interview Scheduled',
      appliedDate: '2024-01-18',
      matchScore: 92
    }
  ]);

  const [jobRecommendations, setJobRecommendations] = useState([
    {
      id: 3,
      title: 'Frontend Developer',
      company: 'Design Studio',
      location: 'New York',
      salary: '$90k - $120k',
      type: 'Full-time',
      matchScore: 85,
      skills: ['React', 'TypeScript', 'CSS'],
      posted: '2 days ago'
    },
    {
      id: 4,
      title: 'Backend Engineer',
      company: 'DataCorp',
      location: 'Austin',
      salary: '$110k - $140k',
      type: 'Full-time',
      matchScore: 79,
      skills: ['Node.js', 'Python', 'PostgreSQL'],
      posted: '1 day ago'
    }
  ]);

  const skillsData = [
    { skill: 'React', current: 85, market: 90 },
    { skill: 'Node.js', current: 80, market: 85 },
    { skill: 'Python', current: 75, market: 88 },
    { skill: 'AWS', current: 60, market: 82 },
    { skill: 'PostgreSQL', current: 70, market: 78 },
  ];

  const radarData = [
    { subject: 'Technical Skills', A: 85, fullMark: 100 },
    { subject: 'Communication', A: 78, fullMark: 100 },
    { subject: 'Problem Solving', A: 92, fullMark: 100 },
    { subject: 'Leadership', A: 65, fullMark: 100 },
    { subject: 'Teamwork', A: 88, fullMark: 100 },
    { subject: 'Adaptability', A: 82, fullMark: 100 },
  ];

  useEffect(() => {
    if (socket) {
      socket.on('applicationUpdate', (update) => {
        setApplications(prev => 
          prev.map(app => 
            app.id === update.id ? { ...app, ...update } : app
          )
        );
        toast.success(`Application status updated: ${update.status}`);
      });

      socket.on('newJobRecommendation', (job) => {
        setJobRecommendations(prev => [job, ...prev]);
        toast.success('New job recommendation available!');
      });
    }

    return () => {
      if (socket) {
        socket.off('applicationUpdate');
        socket.off('newJobRecommendation');
      }
    };
  }, [socket]);

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Profile Summary */}
      <div className="glass p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-primary-500 to-gold-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xl font-bold">{profile.name.split(' ').map(n => n[0]).join('')}</span>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">{profile.name}</h2>
              <p className="text-white/70">{profile.title}</p>
              <div className="flex items-center text-white/60 text-sm mt-1">
                <MapPin className="w-4 h-4 mr-1" />
                {profile.location} • {profile.experience} experience
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-white">{profile.resumeScore}%</div>
            <div className="text-white/70 text-sm">Resume Score</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Applications</p>
                <p className="text-2xl font-bold text-white">{applications.length}</p>
              </div>
              <Send className="w-8 h-8 text-primary-400" />
            </div>
          </div>
          
          <div className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Profile Views</p>
                <p className="text-2xl font-bold text-white">24</p>
              </div>
              <Eye className="w-8 h-8 text-gold-400" />
            </div>
          </div>
          
          <div className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm">Saved Jobs</p>
                <p className="text-2xl font-bold text-white">8</p>
              </div>
              <Heart className="w-8 h-8 text-red-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Skills Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Skills vs Market Demand</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={skillsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="skill" stroke="rgba(255,255,255,0.7)" />
              <YAxis stroke="rgba(255,255,255,0.7)" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  backdropFilter: 'blur(10px)'
                }}
              />
              <Bar dataKey="current" fill="#3b82f6" name="Your Level" />
              <Bar dataKey="market" fill="#f59e0b" name="Market Demand" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Competency Radar</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(255,255,255,0.2)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: 'rgba(255,255,255,0.7)' }} />
              <PolarRadiusAxis tick={{ fill: 'rgba(255,255,255,0.7)' }} />
              <Radar name="Score" dataKey="A" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Applications */}
      <div className="glass p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Recent Applications</h3>
          <button 
            onClick={() => setActiveTab('applications')}
            className="text-primary-400 hover:text-primary-300 text-sm"
          >
            View All
          </button>
        </div>
        <div className="space-y-3">
          {applications.map((app) => (
            <div key={app.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
              <div className="flex-1">
                <h4 className="text-white font-medium">{app.jobTitle}</h4>
                <p className="text-white/60 text-sm">{app.company} • {app.location}</p>
                <p className="text-white/60 text-sm">Applied {app.appliedDate}</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-white font-medium">{app.matchScore}%</p>
                  <p className="text-white/60 text-sm">Match</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  app.status === 'Interview Scheduled' ? 'bg-green-500/20 text-green-300' :
                  app.status === 'Under Review' ? 'bg-blue-500/20 text-blue-300' :
                  'bg-gray-500/20 text-gray-300'
                }`}>
                  {app.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-4 space-y-6">
      {/* Tab Navigation */}
      <div className="flex space-x-1 glass p-1 w-fit">
        {[
          { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
          { id: 'jobs', label: 'Job Search', icon: Search },
          { id: 'applications', label: 'Applications', icon: FileText },
          { id: 'resume', label: 'Resume Tools', icon: Award },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                activeTab === tab.id
                  ? 'bg-gold-500 text-white shadow-lg'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'dashboard' && renderDashboard()}
      {activeTab === 'jobs' && <JobRecommendations jobs={jobRecommendations} />}
      {activeTab === 'applications' && (
        <div className="glass p-6">
          <h2 className="text-2xl font-bold text-white mb-6">My Applications</h2>
          <div className="space-y-4">
            {applications.map((app) => (
              <div key={app.id} className="bg-white/5 border border-white/10 rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{app.jobTitle}</h3>
                    <p className="text-white/70">{app.company}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    app.status === 'Interview Scheduled' ? 'bg-green-500/20 text-green-300' :
                    app.status === 'Under Review' ? 'bg-blue-500/20 text-blue-300' :
                    'bg-gray-500/20 text-gray-300'
                  }`}>
                    {app.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-white/60 text-sm">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center"><MapPin className="w-4 h-4 mr-1" />{app.location}</span>
                    <span className="flex items-center"><DollarSign className="w-4 h-4 mr-1" />{app.salary}</span>
                    <span className="flex items-center"><Clock className="w-4 h-4 mr-1" />Applied {app.appliedDate}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-white font-medium">{app.matchScore}% Match</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {activeTab === 'resume' && <ResumeAnalyzer profile={profile} />}
    </div>
  );
};

export default CandidateDashboard;