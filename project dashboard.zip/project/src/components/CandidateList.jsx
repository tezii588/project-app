import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Star, 
  Mail, 
  Calendar, 
  MoreVertical,
  User,
  Award,
  MapPin,
  Clock
} from 'lucide-react';

const CandidateList = ({ applications }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [sortBy, setSortBy] = useState('score');

  const filteredApplications = applications
    .filter(app => {
      const matchesSearch = app.candidateName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filterStatus === 'all' || app.status === filterStatus;
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      if (sortBy === 'score') return b.score - a.score;
      if (sortBy === 'date') return new Date(b.appliedDate) - new Date(a.appliedDate);
      return a.candidateName.localeCompare(b.candidateName);
    });

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-gold-400';
    return 'text-red-400';
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Shortlisted': return 'bg-gold-500/20 text-gold-300';
      case 'Under Review': return 'bg-blue-500/20 text-blue-300';
      case 'Interview Scheduled': return 'bg-green-500/20 text-green-300';
      case 'Rejected': return 'bg-red-500/20 text-red-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Candidate Applications</h2>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50" />
            <input
              type="text"
              placeholder="Search candidates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="all">All Status</option>
            <option value="Under Review">Under Review</option>
            <option value="Shortlisted">Shortlisted</option>
            <option value="Interview Scheduled">Interview Scheduled</option>
            <option value="Rejected">Rejected</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="score">Sort by Score</option>
            <option value="date">Sort by Date</option>
            <option value="name">Sort by Name</option>
          </select>
        </div>
      </div>

      {/* Candidates Grid */}
      <div className="glass p-6">
        <div className="space-y-4">
          {filteredApplications.map((app) => (
            <div key={app.id} className="bg-white/5 border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-all">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-gold-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {app.candidateName.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{app.candidateName}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(app.status)}`}>
                        {app.status}
                      </span>
                    </div>
                    
                    <p className="text-white/70 mb-2">{app.jobTitle}</p>
                    
                    <div className="flex items-center space-x-4 text-white/60 text-sm mb-3">
                      <span className="flex items-center">
                        <Mail className="w-4 h-4 mr-1" />
                        {app.email}
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        Applied {app.appliedDate}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2 mb-3">
                      <span className="text-white/70 text-sm">{app.experience} experience</span>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {app.skills.map((skill, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-primary-500/20 text-primary-300 rounded-full text-xs"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(app.score)}`}>
                      {app.score}%
                    </div>
                    <div className="text-white/60 text-sm">Match Score</div>
                  </div>

                  <div className="flex flex-col space-y-2">
                    <button className="flex items-center space-x-2 px-3 py-2 bg-green-500/20 text-green-300 rounded-lg hover:bg-green-500/30 transition-all">
                      <Star className="w-4 h-4" />
                      <span>Shortlist</span>
                    </button>
                    
                    <button className="flex items-center space-x-2 px-3 py-2 bg-primary-500/20 text-primary-300 rounded-lg hover:bg-primary-500/30 transition-all">
                      <Calendar className="w-4 h-4" />
                      <span>Schedule</span>
                    </button>
                    
                    <button className="flex items-center space-x-2 px-3 py-2 bg-gold-500/20 text-gold-300 rounded-lg hover:bg-gold-500/30 transition-all">
                      <Mail className="w-4 h-4" />
                      <span>Email</span>
                    </button>
                  </div>

                  <button className="p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-lg">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredApplications.length === 0 && (
          <div className="text-center py-12">
            <User className="w-12 h-12 text-white/30 mx-auto mb-4" />
            <p className="text-white/60">No candidates found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CandidateList;