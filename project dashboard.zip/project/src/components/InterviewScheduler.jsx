import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  Video, 
  MapPin, 
  Plus,
  Edit,
  Trash2,
  User,
  Mail
} from 'lucide-react';

const InterviewScheduler = () => {
  const [interviews, setInterviews] = useState([
    {
      id: 1,
      candidateName: 'John Doe',
      jobTitle: 'Senior React Developer',
      date: '2024-01-25',
      time: '10:00 AM',
      type: 'Virtual',
      status: 'Scheduled',
      interviewer: 'Sarah Wilson',
      meetingLink: 'https://zoom.us/j/123456789'
    },
    {
      id: 2,
      candidateName: 'Jane Smith',
      jobTitle: 'Product Manager',
      date: '2024-01-26',
      time: '2:00 PM',
      type: 'In-person',
      status: 'Scheduled',
      interviewer: 'Mike Johnson',
      location: 'Conference Room A'
    }
  ]);

  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [selectedInterview, setSelectedInterview] = useState(null);

  const getStatusColor = (status) => {
    switch (status) {
      case 'Scheduled': return 'bg-blue-500/20 text-blue-300';
      case 'Completed': return 'bg-green-500/20 text-green-300';
      case 'Cancelled': return 'bg-red-500/20 text-red-300';
      default: return 'bg-gray-500/20 text-gray-300';
    }
  };

  const getTypeIcon = (type) => {
    return type === 'Virtual' ? <Video className="w-4 h-4" /> : <MapPin className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Interview Scheduler</h2>
        <button
          onClick={() => setShowScheduleModal(true)}
          className="bg-gradient-to-r from-primary-500 to-primary-600 text-white px-4 py-2 rounded-lg hover:from-primary-600 hover:to-primary-700 transition-all flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule Interview</span>
        </button>
      </div>

      {/* Calendar View */}
      <div className="glass p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Upcoming Interviews</h3>
          <div className="flex items-center space-x-2">
            <button className="px-3 py-1 bg-white/10 text-white/70 rounded-lg hover:bg-white/20 transition-all">
              Today
            </button>
            <button className="px-3 py-1 bg-white/10 text-white/70 rounded-lg hover:bg-white/20 transition-all">
              This Week
            </button>
            <button className="px-3 py-1 bg-primary-500/20 text-primary-300 rounded-lg">
              All
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {interviews.map((interview) => (
            <div key={interview.id} className="bg-white/5 border border-white/10 rounded-lg p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-gold-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">
                      {interview.candidateName.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="text-lg font-semibold text-white">{interview.candidateName}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(interview.status)}`}>
                        {interview.status}
                      </span>
                    </div>
                    
                    <p className="text-white/70 mb-3">{interview.jobTitle}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-white/60 text-sm">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4" />
                        <span>{interview.date}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4" />
                        <span>{interview.time}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        {getTypeIcon(interview.type)}
                        <span>{interview.type}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4" />
                        <span>{interview.interviewer}</span>
                      </div>
                    </div>

                    {interview.type === 'Virtual' && interview.meetingLink && (
                      <div className="mt-3">
                        <a
                          href={interview.meetingLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary-400 hover:text-primary-300 text-sm"
                        >
                          Join Meeting: {interview.meetingLink}
                        </a>
                      </div>
                    )}

                    {interview.type === 'In-person' && interview.location && (
                      <div className="mt-3">
                        <span className="text-white/60 text-sm">Location: {interview.location}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      setSelectedInterview(interview);
                      setShowScheduleModal(true);
                    }}
                    className="p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-lg"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  
                  <button className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg">
                    <Trash2 className="w-4 h-4" />
                  </button>
                  
                  <button className="px-3 py-2 bg-gold-500/20 text-gold-300 rounded-lg hover:bg-gold-500/30 transition-all">
                    <Mail className="w-4 h-4 inline mr-1" />
                    Send Reminder
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {interviews.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="w-12 h-12 text-white/30 mx-auto mb-4" />
            <p className="text-white/60">No interviews scheduled yet.</p>
          </div>
        )}
      </div>

      {/* Schedule Modal (placeholder) */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass max-w-md w-full">
            <div className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">
                {selectedInterview ? 'Edit Interview' : 'Schedule Interview'}
              </h3>
              <p className="text-white/70 mb-4">
                Interview scheduling form would go here with date/time picker, candidate selection, etc.
              </p>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => {
                    setShowScheduleModal(false);
                    setSelectedInterview(null);
                  }}
                  className="px-4 py-2 text-white/70 hover:text-white"
                >
                  Cancel
                </button>
                <button className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600">
                  {selectedInterview ? 'Update' : 'Schedule'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InterviewScheduler;