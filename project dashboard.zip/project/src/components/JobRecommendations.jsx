import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  DollarSign, 
  Clock, 
  Bookmark,
  ExternalLink,
  Filter,
  TrendingUp,
  Star,
  Heart
} from 'lucide-react';

const JobRecommendations = ({ jobs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [salaryFilter, setSalaryFilter] = useState('');
  const [savedJobs, setSavedJobs] = useState(new Set());

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation = !locationFilter || job.location.toLowerCase().includes(locationFilter.toLowerCase());
    return matchesSearch && matchesLocation;
  });

  const toggleSaveJob = (jobId) => {
    setSavedJobs(prev => {
      const newSaved = new Set(prev);
      if (newSaved.has(jobId)) {
        newSaved.delete(jobId);
      } else {
        newSaved.add(jobId);
      }
      return newSaved;
    });
  };

  const getMatchScoreColor = (score) => {
    if (score >= 85) return 'text-green-400';
    if (score >= 70) return 'text-gold-400';
    return 'text-orange-400';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Job Recommendations</h2>
        <div className="text-white/70">
          {filteredJobs.length} jobs found
        </div>
      </div>

      {/* Search and Filters */}
      <div className="glass p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50" />
            <input
              type="text"
              placeholder="Search jobs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          
          <div className="relative">
            <MapPin className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50" />
            <input
              type="text"
              placeholder="Location"
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          
          <select
            value={salaryFilter}
            onChange={(e) => setSalaryFilter(e.target.value)}
            className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="">All Salaries</option>
            <option value="60k">$60k+</option>
            <option value="80k">$80k+</option>
            <option value="100k">$100k+</option>
            <option value="120k">$120k+</option>
          </select>
        </div>
      </div>

      {/* Job Listings */}
      <div className="space-y-4">
        {filteredJobs.map((job) => (
          <div key={job.id} className="glass p-6 hover:bg-white/10 transition-all">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-xl font-semibold text-white hover:text-primary-400 cursor-pointer">
                      {job.title}
                    </h3>
                    <p className="text-white/70 text-lg">{job.company}</p>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${getMatchScoreColor(job.matchScore)}`}>
                        {job.matchScore}%
                      </div>
                      <div className="text-white/60 text-sm">Match</div>
                    </div>
                    
                    <button
                      onClick={() => toggleSaveJob(job.id)}
                      className={`p-2 rounded-lg transition-all ${
                        savedJobs.has(job.id)
                          ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                          : 'bg-white/10 text-white/50 hover:bg-white/20 hover:text-white'
                      }`}
                    >
                      <Heart className={`w-5 h-5 ${savedJobs.has(job.id) ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                <div className="flex items-center space-x-6 text-white/60 text-sm mb-4">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{job.location}</span>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <DollarSign className="w-4 h-4" />
                    <span>{job.salary}</span>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{job.posted}</span>
                  </div>
                  
                  <span className="px-2 py-1 bg-primary-500/20 text-primary-300 rounded-full text-xs">
                    {job.type}
                  </span>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {job.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-white/10 text-white/80 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>

                <div className="flex items-center space-x-4">
                  <button className="px-6 py-2 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-lg hover:from-primary-600 hover:to-primary-700 transition-all">
                    Apply Now
                  </button>
                  
                  <button className="px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-all">
                    View Details
                  </button>
                  
                  <button className="p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-lg">
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredJobs.length === 0 && (
        <div className="glass p-12 text-center">
          <Search className="w-12 h-12 text-white/30 mx-auto mb-4" />
          <p className="text-white/60 text-lg">No jobs found matching your criteria.</p>
          <p className="text-white/40 text-sm mt-2">Try adjusting your search filters.</p>
        </div>
      )}
    </div>
  );
};

export default JobRecommendations;