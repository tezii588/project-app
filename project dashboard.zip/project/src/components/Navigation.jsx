import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Users, Briefcase, Bell, Settings } from 'lucide-react';

const Navigation = ({ userRole, setUserRole }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const switchRole = (role) => {
    setUserRole(role);
    navigate(`/${role}`);
  };

  return (
    <nav className="glass sticky top-0 z-50 m-4 mb-0">
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-primary-500 to-gold-500 rounded-lg flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">AI Recruit</span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex bg-white/10 rounded-lg p-1">
            <button
              onClick={() => switchRole('recruiter')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                userRole === 'recruiter'
                  ? 'bg-primary-500 text-white shadow-lg'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4 inline mr-2" />
              Recruiter
            </button>
            <button
              onClick={() => switchRole('candidate')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                userRole === 'candidate'
                  ? 'bg-gold-500 text-white shadow-lg'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              <Briefcase className="w-4 h-4 inline mr-2" />
              Candidate
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all">
              <Bell className="w-5 h-5" />
            </button>
            <button className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;