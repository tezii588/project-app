import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Briefcase, 
  TrendingUp, 
  Calendar,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Star,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import JobCreationModal from './JobCreationModal';
import CandidateList from './CandidateList';
import InterviewScheduler from './InterviewScheduler';
import { toast } from 'react-hot-toast';

const RecruiterDashboard = ({ socket }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showJobModal, setShowJobModal] = useState(false);
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [stats, setStats] = useState({
    activeJobs: 12,
    totalApplications: 156,
    shortlistRatio: 23,
    interviewsScheduled: 8
  });

  useEffect(() => {
    // Load initial data
    fetchJobs();
    fetchApplications();
    
    // Listen for real-time updates
    if (socket) {
      socket.on('newApplication', (application) => {
        setApplications(prev => [application, ...prev]);
        toast.success('New application received!');
      });

      socket.on('applicationStatusUpdate', (update) => {
        setApplications(prev => 
          prev.map(app => 
            app.id === update.id ? { ...app, status: update.status } : app
          )
        );
      });
    }

    return () => {
      if (socket) {
        socket.off('newApplication');
        socket.off('applicationStatusUpdate');
      }
    };
  }, [socket]);

  const fetchJobs = async () => {
    // Mock data - replace with actual API call
    setJobs([
      {
        id: 1,
        title: 'Senior React Developer',
        department: 'Engineering',
        location: 'Remote',
        type: 'Full-time',
        status: 'Active',
        applications: 45,
        posted: '2024-01-15'
      },
      {
        id: 2,
        title: 'Product Manager',
        department: 'Product',
        location: 'San Francisco',
        type: 'Full-time',
        status: 'Active',
        applications: 32,
        posted: '2024-01-12'
      }
    ]);
  };

  const fetchApplications = async () => {
    // Mock data - replace with actual API call
    setApplications([
      {
        id: 1,
        candidateName: 'John Doe',
        jobTitle: 'Senior React Developer',
        email: 'john@example.com',
        score: 87,
        status: 'Under Review',
        appliedDate: '2024-01-20',
        skills: ['React', 'Node.js', 'JavaScript'],
        experience: '5 years'
      },
      {
        id: 2,
        candidateName: 'Jane Smith',
        jobTitle: 'Product Manager',
        email: 'jane@example.com',
        score: 92,
        status: 'Shortlisted',
        appliedDate: '2024-01-19',
        skills: ['Product Strategy', 'Analytics', 'Agile'],
        experience: '7 years'
      }
    ]);
  };

  const chartData = [
    { month: 'Jan', applications: 45, hires: 8 },
    { month: 'Feb', applications: 52, hires: 12 },
    { month: 'Mar', applications: 38, hires: 6 },
    { month: 'Apr', applications: 61, hires: 15 },
  ];

  const pieData = [
    { name: 'Under Review', value: 40, color: '#3b82f6' },
    { name: 'Shortlisted', value: 25, color: '#f59e0b' },
    { name: 'Interviewed', value: 20, color: '#10b981' },
    { name: 'Rejected', value: 15, color: '#ef4444' },
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="glass p-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Active Jobs</p>
              <p className="text-2xl font-bold text-white">{stats.activeJobs}</p>
            </div>
            <div className="w-12 h-12 bg-primary-500/20 rounded-lg flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-primary-400" />
            </div>
          </div>
        </div>

        <div className="glass p-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Total Applications</p>
              <p className="text-2xl font-bold text-white">{stats.totalApplications}</p>
            </div>
            <div className="w-12 h-12 bg-gold-500/20 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-gold-400" />
            </div>
          </div>
        </div>

        <div className="glass p-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Shortlist Ratio</p>
              <p className="text-2xl font-bold text-white">{stats.shortlistRatio}%</p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </div>

        <div className="glass p-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/70 text-sm">Interviews Scheduled</p>
              <p className="text-2xl font-bold text-white">{stats.interviewsScheduled}</p>
            </div>
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Application Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="month" stroke="rgba(255,255,255,0.7)" />
              <YAxis stroke="rgba(255,255,255,0.7)" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  border: '1px solid rgba(255,255,255,0.2)',
                  borderRadius: '8px',
                  backdropFilter: 'blur(10px)'
                }}
              />
              <Bar dataKey="applications" fill="#3b82f6" />
              <Bar dataKey="hires" fill="#f59e0b" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Application Status</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Applications */}
      <div className="glass p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Recent Applications</h3>
          <button 
            onClick={() => setActiveTab('applications')}
            className="text-primary-400 hover:text-primary-300 text-sm"
          >
            View All
          </button>
        </div>
        <div className="space-y-3">
          {applications.slice(0, 3).map((app) => (
            <div key={app.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-primary-500 to-gold-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-medium">{app.candidateName.charAt(0)}</span>
                </div>
                <div>
                  <p className="text-white font-medium">{app.candidateName}</p>
                  <p className="text-white/60 text-sm">{app.jobTitle}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-white font-medium">{app.score}%</p>
                  <p className="text-white/60 text-sm">Match</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  app.status === 'Shortlisted' ? 'bg-gold-500/20 text-gold-300' :
                  app.status === 'Under Review' ? 'bg-blue-500/20 text-blue-300' :
                  'bg-gray-500/20 text-gray-300'
                }`}>
                  {app.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderJobs = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Job Management</h2>
        <button
          onClick={() => setShowJobModal(true)}
          className="bg-gradient-to-r from-primary-500 to-primary-600 text-white px-4 py-2 rounded-lg hover:from-primary-600 hover:to-primary-700 transition-all flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Create Job</span>
        </button>
      </div>

      <div className="glass p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50" />
              <input
                type="text"
                placeholder="Search jobs..."
                className="bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <button className="flex items-center space-x-2 px-3 py-2 bg-white/10 rounded-lg text-white/70 hover:text-white">
              <Filter className="w-4 h-4" />
              <span>Filter</span>
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {jobs.map((job) => (
            <div key={job.id} className="bg-white/5 border border-white/10 rounded-lg p-6 hover:bg-white/10 transition-all">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-white">{job.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      job.status === 'Active' ? 'bg-green-500/20 text-green-300' :
                      'bg-gray-500/20 text-gray-300'
                    }`}>
                      {job.status}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-white/60 text-sm">
                    <span>{job.department}</span>
                    <span>•</span>
                    <span>{job.location}</span>
                    <span>•</span>
                    <span>{job.type}</span>
                    <span>•</span>
                    <span>Posted {job.posted}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-white font-medium">{job.applications}</p>
                    <p className="text-white/60 text-sm">Applications</p>
                  </div>
                  <button className="p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-lg">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-4 space-y-6">
      {/* Tab Navigation */}
      <div className="flex space-x-1 glass p-1 w-fit">
        {[
          { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
          { id: 'jobs', label: 'Jobs', icon: Briefcase },
          { id: 'applications', label: 'Applications', icon: Users },
          { id: 'interviews', label: 'Interviews', icon: Calendar },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                activeTab === tab.id
                  ? 'bg-primary-500 text-white shadow-lg'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'dashboard' && renderDashboard()}
      {activeTab === 'jobs' && renderJobs()}
      {activeTab === 'applications' && <CandidateList applications={applications} />}
      {activeTab === 'interviews' && <InterviewScheduler />}

      {/* Job Creation Modal */}
      {showJobModal && (
        <JobCreationModal
          isOpen={showJobModal}
          onClose={() => setShowJobModal(false)}
          onJobCreated={(job) => {
            setJobs(prev => [job, ...prev]);
            setShowJobModal(false);
            toast.success('Job created successfully!');
          }}
        />
      )}
    </div>
  );
};

export default RecruiterDashboard;