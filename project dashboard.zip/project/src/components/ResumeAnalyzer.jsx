import React, { useState } from 'react';
import { 
  Upload, 
  FileText, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  Target,
  Lightbulb,
  Download
} from 'lucide-react';
import { useDropzone } from 'react-dropzone';

const ResumeAnalyzer = ({ profile }) => {
  const [analyzedResume, setAnalyzedResume] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    multiple: false,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        analyzeResume(acceptedFiles[0]);
      }
    }
  });

  const analyzeResume = async (file) => {
    setIsAnalyzing(true);
    
    // Simulate API call
    setTimeout(() => {
      setAnalyzedResume({
        score: 78,
        strengths: [
          'Strong technical skills in React and Node.js',
          'Good experience progression',
          'Relevant project examples',
          'Clear education background'
        ],
        improvements: [
          'Add more quantifiable achievements',
          'Include soft skills section',
          'Optimize for ATS keywords',
          'Add professional summary'
        ],
        atsCompatibility: 85,
        skillsMatch: {
          present: ['React', 'Node.js', 'JavaScript', 'CSS'],
          missing: ['TypeScript', 'AWS', 'Docker', 'GraphQL']
        },
        suggestions: [
          'Quantify your achievements with specific numbers and percentages',
          'Add a professional summary at the top highlighting your key strengths',
          'Include relevant certifications or courses',
          'Optimize formatting for better ATS scanning'
        ]
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  const generateCoverLetter = () => {
    // Placeholder for cover letter generation
    alert('Cover letter generation feature would integrate with OpenAI API');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Resume Analysis & Tools</h2>
      </div>

      {/* Upload Section */}
      <div className="glass p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Upload Resume for Analysis</h3>
        
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
            isDragActive 
              ? 'border-primary-400 bg-primary-500/10' 
              : 'border-white/30 hover:border-primary-400 hover:bg-white/5'
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="w-12 h-12 text-white/50 mx-auto mb-4" />
          {isDragActive ? (
            <p className="text-white">Drop your resume here...</p>
          ) : (
            <div>
              <p className="text-white mb-2">Drag & drop your resume here, or click to select</p>
              <p className="text-white/60 text-sm">Supports PDF, DOC, DOCX files</p>
            </div>
          )}
        </div>

        {isAnalyzing && (
          <div className="mt-4 text-center">
            <div className="inline-flex items-center space-x-2 text-primary-400">
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-primary-400 border-t-transparent"></div>
              <span>Analyzing your resume...</span>
            </div>
          </div>
        )}
      </div>

      {/* Analysis Results */}
      {analyzedResume && (
        <div className="space-y-6">
          {/* Score Overview */}
          <div className="glass p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Analysis Results</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary-400 mb-2">
                  {analyzedResume.score}%
                </div>
                <div className="text-white/70">Overall Score</div>
              </div>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-gold-400 mb-2">
                  {analyzedResume.atsCompatibility}%
                </div>
                <div className="text-white/70">ATS Compatible</div>
              </div>
              
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">
                  {analyzedResume.skillsMatch.present.length}
                </div>
                <div className="text-white/70">Skills Matched</div>
              </div>
            </div>
          </div>

          {/* Strengths */}
          <div className="glass p-6">
            <div className="flex items-center space-x-2 mb-4">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <h3 className="text-lg font-semibold text-white">Strengths</h3>
            </div>
            
            <div className="space-y-2">
              {analyzedResume.strengths.map((strength, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-white/80">{strength}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Improvements */}
          <div className="glass p-6">
            <div className="flex items-center space-x-2 mb-4">
              <AlertCircle className="w-5 h-5 text-yellow-400" />
              <h3 className="text-lg font-semibold text-white">Areas for Improvement</h3>
            </div>
            
            <div className="space-y-2">
              {analyzedResume.improvements.map((improvement, index) => (
                <div key={index} className="flex items-start space-x-2">
                  <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                  <span className="text-white/80">{improvement}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Skills Analysis */}
          <div className="glass p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Target className="w-5 h-5 text-primary-400" />
              <h3 className="text-lg font-semibold text-white">Skills Analysis</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-white font-medium mb-3">Skills Found</h4>
                <div className="flex flex-wrap gap-2">
                  {analyzedResume.skillsMatch.present.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-green-500/20 text-green-300 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="text-white font-medium mb-3">Missing Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {analyzedResume.skillsMatch.missing.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-red-500/20 text-red-300 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* AI Suggestions */}
          <div className="glass p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Lightbulb className="w-5 h-5 text-gold-400" />
              <h3 className="text-lg font-semibold text-white">AI Suggestions</h3>
            </div>
            
            <div className="space-y-3">
              {analyzedResume.suggestions.map((suggestion, index) => (
                <div key={index} className="p-3 bg-white/5 rounded-lg">
                  <span className="text-white/80">{suggestion}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4">
            <button
              onClick={generateCoverLetter}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-primary-500 to-primary-600 text-white rounded-lg hover:from-primary-600 hover:to-primary-700 transition-all"
            >
              <FileText className="w-4 h-4" />
              <span>Generate Cover Letter</span>
            </button>
            
            <button className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-gold-500 to-gold-600 text-white rounded-lg hover:from-gold-600 hover:to-gold-700 transition-all">
              <Download className="w-4 h-4" />
              <span>Download Report</span>
            </button>
            
            <button className="flex items-center space-x-2 px-4 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-all">
              <TrendingUp className="w-4 h-4" />
              <span>Skill Recommendations</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResumeAnalyzer;