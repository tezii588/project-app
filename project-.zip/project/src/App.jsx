import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import AIFeatures from './components/AIFeatures.jsx';
import JobPortal from './components/JobPortal.jsx';
import CandidateDashboard from './components/CandidateDashboard.jsx';
import RecruiterDashboard from './components/RecruiterDashboard.jsx';
import ResumeBuilder from './components/ResumeBuilder.jsx';
import Testimonials from './components/Testimonials.jsx';
import Blog from './components/Blog.jsx';
import Newsletter from './components/Newsletter.jsx';
import Footer from './components/Footer.jsx';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      <Navbar />
      <Routes>
        <Route path="/" element={
          <main>
            <Hero />
            <AIFeatures />
            <JobPortal />
            <Testimonials />
            <Blog />
            <Newsletter />
          </main>
        } />
        <Route path="/candidate-dashboard" element={<CandidateDashboard />} />
        <Route path="/recruiter-dashboard" element={<RecruiterDashboard />} />
        <Route path="/resume-builder" element={<ResumeBuilder />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;