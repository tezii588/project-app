import React from 'react';
import { Calendar, Clock, ArrowRight, TrendingUp } from 'lucide-react';

const Blog = () => {
  const posts = [
    {
      id: 1,
      title: 'How AI is Revolutionizing Resume Screening in 2024',
      excerpt: 'Discover how artificial intelligence is transforming the way companies screen resumes and what it means for job seekers.',
      category: 'AI Trends',
      readTime: '5 min read',
      date: 'Jan 20, 2024',
      image: 'https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 2,
      title: 'The Ultimate Guide to ATS-Friendly Resume Writing',
      excerpt: 'Learn how to optimize your resume for Applicant Tracking Systems and increase your chances of getting noticed.',
      category: 'Career Tips',
      readTime: '8 min read',
      date: 'Jan 18, 2024',
      image: 'https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 3,
      title: 'Remote Work: Top Skills Employers Look For in 2024',
      excerpt: 'Explore the most in-demand skills for remote positions and how to highlight them in your job applications.',
      category: 'Remote Work',
      readTime: '6 min read',
      date: 'Jan 15, 2024',
      image: 'https://images.pexels.com/photos/4050314/pexels-photo-4050314.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const trendingTopics = [
    'AI in Recruitment',
    'Remote Work Trends',
    'Salary Negotiation',
    'Interview Preparation',
    'Career Development'
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-6">
            Career
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent"> Insights</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Stay ahead of the curve with expert advice, industry trends, and actionable career guidance
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Featured Post */}
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden mb-8 group hover:border-white/20 transition-all duration-300">
              <div className="relative">
                <img
                  src={posts[0].image}
                  alt={posts[0].title}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-yellow-400 text-slate-900 rounded-full text-sm font-semibold">
                    Featured
                  </span>
                </div>
              </div>
              <div className="p-8">
                <div className="flex items-center space-x-4 text-sm text-gray-400 mb-4">
                  <span className="px-3 py-1 bg-white/10 rounded-full">{posts[0].category}</span>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{posts[0].date}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{posts[0].readTime}</span>
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-yellow-400 transition-colors duration-200">
                  {posts[0].title}
                </h3>
                <p className="text-gray-300 leading-relaxed mb-6">{posts[0].excerpt}</p>
                <button className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300 font-semibold group">
                  <span>Read More</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                </button>
              </div>
            </div>

            {/* Blog Posts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {posts.slice(1).map((post) => (
                <article
                  key={post.id}
                  className="group bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 overflow-hidden hover:border-white/20 hover:bg-white/10 transition-all duration-300"
                >
                  <div className="relative">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center space-x-4 text-sm text-gray-400 mb-3">
                      <span className="px-2 py-1 bg-white/10 rounded text-xs">{post.category}</span>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    <h3 className="text-lg font-bold text-white mb-3 group-hover:text-yellow-400 transition-colors duration-200 line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500 text-sm">{post.date}</span>
                      <button className="text-yellow-400 hover:text-yellow-300 text-sm font-medium flex items-center space-x-1 group">
                        <span>Read</span>
                        <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform duration-200" />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            {/* Trending Topics */}
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
              <div className="flex items-center space-x-2 mb-6">
                <TrendingUp className="w-5 h-5 text-yellow-400" />
                <h3 className="text-lg font-bold text-white">Trending Topics</h3>
              </div>
              <div className="space-y-3">
                {trendingTopics.map((topic, index) => (
                  <button
                    key={index}
                    className="block w-full text-left px-3 py-2 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200"
                  >
                    {topic}
                  </button>
                ))}
              </div>
            </div>

            {/* Newsletter Signup */}
            <div className="bg-gradient-to-br from-yellow-400/10 to-yellow-500/5 backdrop-blur-md rounded-2xl border border-yellow-400/20 p-6">
              <h3 className="text-lg font-bold text-white mb-3">Stay Updated</h3>
              <p className="text-gray-300 text-sm mb-4">
                Get the latest career insights and AI recruitment trends delivered to your inbox.
              </p>
              <div className="space-y-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                />
                <button className="w-full px-4 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <button className="px-8 py-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200">
            Load More Articles
          </button>
        </div>
      </div>
    </section>
  );
};

export default Blog;