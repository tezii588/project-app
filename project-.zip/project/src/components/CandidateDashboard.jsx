import React, { useState } from 'react';
import { User, FileText, Target, Bell, Settings, TrendingUp, Calendar, Star } from 'lucide-react';

const CandidateDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const applications = [
    {
      id: 1,
      position: 'Senior React Developer',
      company: 'TechCorp Inc.',
      status: 'Interview Scheduled',
      appliedDate: '2024-01-15',
      matchScore: 95,
      stage: 'Technical Interview',
      nextStep: 'Jan 25, 2024 - 2:00 PM'
    },
    {
      id: 2,
      position: 'Frontend Engineer',
      company: 'StartupXYZ',
      status: 'Under Review',
      appliedDate: '2024-01-12',
      matchScore: 88,
      stage: 'HR Review',
      nextStep: 'Waiting for response'
    }
  ];

  const recommendations = [
    {
      id: 1,
      title: 'Full Stack Developer',
      company: 'InnovateLab',
      matchScore: 92,
      salary: '$110k - $140k',
      location: 'Remote'
    },
    {
      id: 2,
      title: 'React Native Developer',
      company: 'MobileFirst',
      matchScore: 89,
      salary: '$100k - $130k',
      location: 'San Francisco'
    }
  ];

  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'applications', label: 'Applications', icon: FileText },
    { id: 'recommendations', label: 'Recommendations', icon: Target },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Candidate Dashboard</h1>
          <p className="text-gray-300">Track your job applications and discover new opportunities</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 sticky top-24">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/20'
                          : 'text-gray-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Active Applications</p>
                        <p className="text-2xl font-bold text-white">12</p>
                      </div>
                      <div className="p-3 bg-blue-500/10 rounded-xl">
                        <FileText className="w-6 h-6 text-blue-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Interview Rate</p>
                        <p className="text-2xl font-bold text-white">68%</p>
                      </div>
                      <div className="p-3 bg-green-500/10 rounded-xl">
                        <TrendingUp className="w-6 h-6 text-green-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Avg Match Score</p>
                        <p className="text-2xl font-bold text-white">87%</p>
                      </div>
                      <div className="p-3 bg-yellow-500/10 rounded-xl">
                        <Target className="w-6 h-6 text-yellow-400" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                  <h3 className="text-xl font-bold text-white mb-6">Recent Activity</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl">
                      <div className="p-2 bg-green-500/10 rounded-lg">
                        <Calendar className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Interview scheduled with TechCorp Inc.</p>
                        <p className="text-gray-400 text-sm">2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl">
                      <div className="p-2 bg-blue-500/10 rounded-lg">
                        <Bell className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">New job recommendation available</p>
                        <p className="text-gray-400 text-sm">1 day ago</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Applications Tab */}
            {activeTab === 'applications' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Job Applications</h3>
                <div className="space-y-4">
                  {applications.map((app) => (
                    <div key={app.id} className="p-6 bg-white/5 rounded-xl border border-white/10">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="text-lg font-semibold text-white">{app.position}</h4>
                          <p className="text-gray-300">{app.company}</p>
                        </div>
                        <div className="text-right">
                          <div className="px-3 py-1 bg-yellow-400/10 rounded-full text-yellow-400 text-sm font-semibold">
                            {app.matchScore}% match
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-400">Status</p>
                          <p className="text-white font-medium">{app.status}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Applied</p>
                          <p className="text-white">{app.appliedDate}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Stage</p>
                          <p className="text-white">{app.stage}</p>
                        </div>
                        <div>
                          <p className="text-gray-400">Next Step</p>
                          <p className="text-white">{app.nextStep}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recommendations Tab */}
            {activeTab === 'recommendations' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">AI Recommendations</h3>
                <div className="space-y-6">
                  {recommendations.map((job) => (
                    <div key={job.id} className="p-6 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="text-lg font-semibold text-white">{job.title}</h4>
                          <p className="text-gray-300">{job.company}</p>
                        </div>
                        <div className="flex items-center space-x-1 px-3 py-1 bg-green-400/10 rounded-full text-green-400 text-sm font-semibold">
                          <Star className="w-4 h-4" />
                          <span>{job.matchScore}%</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-sm text-gray-400">
                          <span>{job.salary}</span>
                          <span>•</span>
                          <span>{job.location}</span>
                        </div>
                        <button className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-lg text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                          Apply Now
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Profile Settings</h3>
                <p className="text-gray-300">Manage your profile information and preferences.</p>
              </div>
            )}

            {/* Settings Tab */}
            {activeTab === 'settings' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Account Settings</h3>
                <p className="text-gray-300">Configure your account settings and notifications.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateDashboard;