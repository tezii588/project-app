import React, { useState } from 'react';
import { Search, MapPin, Clock, DollarSign, Filter, Star, Briefcase, Users } from 'lucide-react';

const JobPortal = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const jobs = [
    {
      id: 1,
      title: 'Senior React Developer',
      company: 'TechCorp Inc.',
      location: 'San Francisco, CA',
      type: 'Full-time',
      salary: '$120k - $150k',
      posted: '2 days ago',
      matchScore: 95,
      skills: ['React', 'JavaScript', 'TypeScript', 'Node.js'],
      description: 'We are looking for an experienced React developer to join our growing team...',
      logo: '🚀'
    },
    {
      id: 2,
      title: 'AI/ML Engineer',
      company: 'DataFlow Solutions',
      location: 'New York, NY',
      type: 'Full-time',
      salary: '$130k - $170k',
      posted: '1 day ago',
      matchScore: 88,
      skills: ['Python', 'TensorFlow', 'Machine Learning', 'AI'],
      description: 'Join our AI team to build cutting-edge machine learning solutions...',
      logo: '🤖'
    },
    {
      id: 3,
      title: 'Product Manager',
      company: 'InnovateLab',
      location: 'Austin, TX',
      type: 'Full-time',
      salary: '$110k - $140k',
      posted: '3 days ago',
      matchScore: 82,
      skills: ['Product Strategy', 'Analytics', 'Leadership', 'Agile'],
      description: 'Lead product development and strategy for our innovative platform...',
      logo: '💡'
    },
    {
      id: 4,
      title: 'DevOps Engineer',
      company: 'CloudNine Systems',
      location: 'Remote',
      type: 'Full-time',
      salary: '$115k - $145k',
      posted: '1 week ago',
      matchScore: 90,
      skills: ['AWS', 'Docker', 'Kubernetes', 'CI/CD'],
      description: 'Build and maintain scalable cloud infrastructure...',
      logo: '☁️'
    },
    {
      id: 5,
      title: 'UX Designer',
      company: 'DesignStudio Pro',
      location: 'Los Angeles, CA',
      type: 'Contract',
      salary: '$80k - $100k',
      posted: '4 days ago',
      matchScore: 76,
      skills: ['Figma', 'User Research', 'Prototyping', 'Design Systems'],
      description: 'Create beautiful and intuitive user experiences...',
      logo: '🎨'
    },
    {
      id: 6,
      title: 'Data Scientist',
      company: 'Analytics Hub',
      location: 'Seattle, WA',
      type: 'Full-time',
      salary: '$125k - $155k',
      posted: '5 days ago',
      matchScore: 85,
      skills: ['Python', 'R', 'SQL', 'Statistics'],
      description: 'Analyze complex datasets to drive business insights...',
      logo: '📊'
    }
  ];

  const filteredJobs = jobs.filter(job => {
    return (
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (selectedLocation === '' || job.location.includes(selectedLocation)) &&
      (selectedType === '' || job.type === selectedType)
    );
  });

  const getMatchScoreColor = (score) => {
    if (score >= 90) return 'text-green-400 bg-green-400/10';
    if (score >= 80) return 'text-yellow-400 bg-yellow-400/10';
    return 'text-orange-400 bg-orange-400/10';
  };

  return (
    <section id="jobs" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-6">
            Discover Your
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent"> Dream Job</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Browse thousands of opportunities from top companies, powered by AI matching technology
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 mb-12">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search jobs, companies, or skills..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
              />
            </div>

            {/* Location Filter */}
            <div className="relative">
              <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="pl-12 pr-8 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none transition-colors duration-200 appearance-none"
              >
                <option value="">All Locations</option>
                <option value="San Francisco">San Francisco</option>
                <option value="New York">New York</option>
                <option value="Austin">Austin</option>
                <option value="Remote">Remote</option>
                <option value="Los Angeles">Los Angeles</option>
                <option value="Seattle">Seattle</option>
              </select>
            </div>

            {/* Job Type Filter */}
            <div className="relative">
              <Briefcase className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="pl-12 pr-8 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none transition-colors duration-200 appearance-none"
              >
                <option value="">All Types</option>
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Remote">Remote</option>
              </select>
            </div>

            {/* Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-3 bg-yellow-400/10 border border-yellow-400/20 rounded-xl text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200"
            >
              <Filter className="w-5 h-5" />
              <span>Filters</span>
            </button>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-white/10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Salary Range</label>
                  <select className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:border-yellow-400 focus:outline-none">
                    <option value="">Any Salary</option>
                    <option value="50k-80k">$50k - $80k</option>
                    <option value="80k-120k">$80k - $120k</option>
                    <option value="120k+">$120k+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Experience Level</label>
                  <select className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:border-yellow-400 focus:outline-none">
                    <option value="">Any Level</option>
                    <option value="entry">Entry Level</option>
                    <option value="mid">Mid Level</option>
                    <option value="senior">Senior Level</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Company Size</label>
                  <select className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:border-yellow-400 focus:outline-none">
                    <option value="">Any Size</option>
                    <option value="startup">Startup</option>
                    <option value="medium">Medium</option>
                    <option value="large">Large</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="text-white">
            <span className="text-lg font-semibold">{filteredJobs.length} jobs found</span>
            {searchTerm && <span className="text-gray-400 ml-2">for "{searchTerm}"</span>}
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-gray-400 text-sm">Sort by:</span>
            <select className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:border-yellow-400 focus:outline-none">
              <option value="relevance">Relevance</option>
              <option value="date">Date Posted</option>
              <option value="salary">Salary</option>
              <option value="match">Match Score</option>
            </select>
          </div>
        </div>

        {/* Job Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredJobs.map((job) => (
            <div key={job.id} className="group bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:border-white/20 transition-all duration-300 p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-xl flex items-center justify-center text-2xl">
                    {job.logo}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white group-hover:text-yellow-400 transition-colors duration-200">
                      {job.title}
                    </h3>
                    <p className="text-gray-300">{job.company}</p>
                  </div>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getMatchScoreColor(job.matchScore)}`}>
                  {job.matchScore}% match
                </div>
              </div>

              {/* Job Details */}
              <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-gray-400">
                <div className="flex items-center space-x-1">
                  <MapPin className="w-4 h-4" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Briefcase className="w-4 h-4" />
                  <span>{job.type}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <DollarSign className="w-4 h-4" />
                  <span>{job.salary}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{job.posted}</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-gray-300 mb-4 line-clamp-2">{job.description}</p>

              {/* Skills */}
              <div className="flex flex-wrap gap-2 mb-6">
                {job.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300 border border-white/20"
                  >
                    {skill}
                  </span>
                ))}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between">
                <button className="flex items-center space-x-1 text-yellow-400 hover:text-yellow-300 transition-colors duration-200">
                  <Star className="w-4 h-4" />
                  <span>Save</span>
                </button>
                <div className="flex space-x-3">
                  <button className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 transition-all duration-200">
                    View Details
                  </button>
                  <button className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-lg text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <button className="flex items-center space-x-2 mx-auto px-8 py-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200">
            <Users className="w-5 h-5" />
            <span>Load More Jobs</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default JobPortal;