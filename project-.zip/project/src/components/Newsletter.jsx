import React, { useState } from 'react';
import { Mail, Check, Sparkles } from 'lucide-react';

const Newsletter = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle newsletter subscription
    setSubscribed(true);
    setTimeout(() => {
      setSubscribed(false);
      setEmail('');
    }, 3000);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="relative">
          {/* Background Elements */}
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 to-yellow-500/5 rounded-3xl blur-xl" />
          <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/20 rounded-full blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-400/20 rounded-full blur-2xl" />
          
          {/* Content */}
          <div className="relative bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-8 md:p-12">
            <div className="text-center mb-8">
              {/* Icon */}
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-2xl mb-6">
                <Mail className="w-10 h-10 text-slate-900" />
              </div>
              
              {/* Headlines */}
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                Stay Ahead of the
                <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent"> Curve</span>
              </h2>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
                Get exclusive AI insights, career tips, and job market trends delivered straight to your inbox. 
                Join 10,000+ professionals already subscribed.
              </p>
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-white/10 rounded-xl mb-4">
                  <Sparkles className="w-6 h-6 text-yellow-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">AI Insights</h3>
                <p className="text-gray-400 text-sm">Latest AI recruitment trends and technologies</p>
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-white/10 rounded-xl mb-4">
                  <Check className="w-6 h-6 text-green-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">Career Tips</h3>
                <p className="text-gray-400 text-sm">Expert advice to advance your career</p>
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-white/10 rounded-xl mb-4">
                  <Mail className="w-6 h-6 text-blue-400" />
                </div>
                <h3 className="text-white font-semibold mb-2">Exclusive Content</h3>
                <p className="text-gray-400 text-sm">Access to premium resources and guides</p>
              </div>
            </div>

            {/* Subscription Form */}
            {!subscribed ? (
              <form onSubmit={handleSubmit} className="max-w-md mx-auto">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      required
                      className="w-full pl-12 pr-4 py-4 bg-white/10 border-2 border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-all duration-200"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-bold hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-yellow-400/25 whitespace-nowrap"
                  >
                    Subscribe Free
                  </button>
                </div>
                <p className="text-gray-400 text-sm text-center mt-4">
                  No spam, unsubscribe at any time. We respect your privacy.
                </p>
              </form>
            ) : (
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 rounded-full mb-4">
                  <Check className="w-8 h-8 text-green-400" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Welcome aboard! 🎉</h3>
                <p className="text-gray-300">
                  Thank you for subscribing. Check your email for a welcome message and your first insights.
                </p>
              </div>
            )}

            {/* Social Proof */}
            {!subscribed && (
              <div className="mt-8 text-center">
                <div className="flex items-center justify-center space-x-8 text-sm text-gray-400">
                  <span>✨ 10,000+ subscribers</span>
                  <span>📧 Weekly insights</span>
                  <span>🔒 Privacy protected</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;