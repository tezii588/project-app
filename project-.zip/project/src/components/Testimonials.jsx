import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      role: 'Software Engineer',
      company: 'TechCorp',
      content: 'The AI resume builder transformed my job search completely. I got 3x more interview calls and landed my dream job within 2 weeks!',
      rating: 5,
      image: '👩‍💻'
    },
    {
      id: 2,
      name: 'Michael Chen',
      role: 'HR Director',
      company: 'InnovateLab',
      content: 'Finding quality candidates used to take weeks. Now with AI matching, we identify perfect fits in minutes. Game-changing technology!',
      rating: 5,
      image: '👨‍💼'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      role: 'Product Manager',
      company: 'StartupXYZ',
      content: 'The job match scores are incredibly accurate. I only apply to positions where I have a real chance, saving time and increasing success rate.',
      rating: 5,
      image: '👩‍🚀'
    },
    {
      id: 4,
      name: 'David Park',
      role: 'Talent Acquisition Lead',
      company: 'GlobalTech',
      content: 'Our hiring efficiency improved by 400% after implementing this platform. The AI insights help us make better decisions faster.',
      rating: 5,
      image: '👨‍🎓'
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-6">
            Trusted by
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent"> Thousands</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            See how professionals and companies are transforming their hiring process with our AI platform
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="group bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-8 hover:border-white/20 hover:bg-white/10 transition-all duration-300"
            >
              {/* Quote Icon */}
              <div className="mb-6">
                <Quote className="w-8 h-8 text-yellow-400 opacity-50" />
              </div>

              {/* Content */}
              <blockquote className="text-gray-300 text-lg leading-relaxed mb-6">
                "{testimonial.content}"
              </blockquote>

              {/* Rating */}
              <div className="flex items-center space-x-1 mb-6">
                {[...Array(testimonial.rating)].map((_, index) => (
                  <Star key={index} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>

              {/* Author */}
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center text-2xl">
                  {testimonial.image}
                </div>
                <div>
                  <div className="text-white font-semibold">{testimonial.name}</div>
                  <div className="text-gray-400 text-sm">
                    {testimonial.role} at {testimonial.company}
                  </div>
                </div>
              </div>

              {/* Decorative Element */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-400/5 to-transparent rounded-full blur-xl group-hover:scale-110 transition-transform duration-500" />
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-20 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl sm:text-4xl font-bold text-yellow-400 mb-2">10,000+</div>
              <div className="text-gray-300">Happy Users</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-bold text-yellow-400 mb-2">95%</div>
              <div className="text-gray-300">Success Rate</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-bold text-yellow-400 mb-2">24/7</div>
              <div className="text-gray-300">AI Support</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-bold text-yellow-400 mb-2">500+</div>
              <div className="text-gray-300">Companies</div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center space-x-4 p-8 bg-gradient-to-r from-yellow-400/10 to-yellow-500/10 backdrop-blur-md rounded-2xl border border-yellow-400/20">
            <div className="text-left">
              <h3 className="text-2xl font-bold text-white mb-2">Ready to join them?</h3>
              <p className="text-gray-300">Start your AI-powered career journey today</p>
            </div>
            <button className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200 whitespace-nowrap">
              Get Started Free
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;