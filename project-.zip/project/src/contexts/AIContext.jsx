import React, { createContext, useContext, useState } from 'react';
import OpenAI from 'openai';

const AIContext = createContext();

const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true
});

export const AIProvider = ({ children }) => {
  const [isLoading, setIsLoading] = useState(false);

  const generateResume = async (userInput) => {
    setIsLoading(true);
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a professional resume writer. Create a well-structured, ATS-friendly resume based on the provided information. Format it in a clean, professional manner."
          },
          {
            role: "user",
            content: `Please create a professional resume based on this information: ${JSON.stringify(userInput)}`
          }
        ],
        max_tokens: 1500,
        temperature: 0.7
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('Error generating resume:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const calculateJobMatch = async (resume, jobDescription) => {
    setIsLoading(true);
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are an AI recruitment specialist. Analyze the match between a candidate's resume and job description. Provide a match score (0-100) and key insights."
          },
          {
            role: "user",
            content: `Resume: ${resume}\n\nJob Description: ${jobDescription}\n\nPlease provide a match score and analysis.`
          }
        ],
        max_tokens: 500,
        temperature: 0.3
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('Error calculating job match:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const optimizeJobSearch = async (skills, preferences) => {
    setIsLoading(true);
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a career advisor AI. Suggest relevant job positions and provide search optimization tips based on skills and preferences."
          },
          {
            role: "user",
            content: `Skills: ${skills.join(', ')}\nPreferences: ${JSON.stringify(preferences)}\n\nSuggest optimized job search strategies and relevant positions.`
          }
        ],
        max_tokens: 800,
        temperature: 0.6
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('Error optimizing job search:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const generateCandidateRecommendations = async (jobRequirements) => {
    setIsLoading(true);
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are an AI recruiter. Generate candidate profiles that would be ideal matches for the given job requirements."
          },
          {
            role: "user",
            content: `Job Requirements: ${jobRequirements}\n\nGenerate 3-5 ideal candidate profiles with skills, experience, and qualifications.`
          }
        ],
        max_tokens: 1000,
        temperature: 0.7
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('Error generating candidate recommendations:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    generateResume,
    calculateJobMatch,
    optimizeJobSearch,
    generateCandidateRecommendations,
    isLoading
  };

  return <AIContext.Provider value={value}>{children}</AIContext.Provider>;
};

export const useAI = () => {
  const context = useContext(AIContext);
  if (!context) {
    throw new Error('useAI must be used within an AIProvider');
  }
  return context;
};