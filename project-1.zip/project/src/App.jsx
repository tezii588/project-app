import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import AIFeatures from './components/AIFeatures.jsx';
import JobPortal from './components/Jobs/JobPortal.jsx';
import CandidateDashboard from './components/Dashboard/CandidateDashboard.jsx';
import RecruiterDashboard from './components/Dashboard/RecruiterDashboard.jsx';
import ResumeBuilder from './components/ResumeBuilder/ResumeBuilder.jsx';
import LoginForm from './components/Auth/LoginForm.jsx';
import RegisterForm from './components/Auth/RegisterForm.jsx';
import ProtectedRoute from './components/Auth/ProtectedRoute.jsx';
import Testimonials from './components/Testimonials.jsx';
import Blog from './components/Blog.jsx';
import Newsletter from './components/Newsletter.jsx';
import Footer from './components/Footer.jsx';

function App() {
  const { isAuthenticated, user } = useSelector(state => state.auth);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      <Navbar />
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={
          <main>
            <Hero />
            <AIFeatures />
            <JobPortal />
            <Testimonials />
            <Blog />
            <Newsletter />
          </main>
        } />
        <Route path="/jobs" element={<JobPortal />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/register" element={<RegisterForm />} />

        {/* Protected Routes */}
        <Route path="/candidate-dashboard" element={
          <ProtectedRoute requiredRole="candidate">
            <CandidateDashboard />
          </ProtectedRoute>
        } />
        <Route path="/recruiter-dashboard" element={
          <ProtectedRoute requiredRole="recruiter">
            <RecruiterDashboard />
          </ProtectedRoute>
        } />
        <Route path="/resume-builder" element={
          <ProtectedRoute requiredRole="candidate">
            <ResumeBuilder />
          </ProtectedRoute>
        } />

        {/* Fallback Route */}
        <Route path="*" element={
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-white mb-4">404 - Page Not Found</h1>
              <p className="text-gray-300 mb-8">The page you're looking for doesn't exist.</p>
              <a href="/" className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                Go Home
              </a>
            </div>
          </div>
        } />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;