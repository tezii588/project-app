import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { User, FileText, Target, Bell, Settings, TrendingUp, Calendar, Star, Plus } from 'lucide-react';
import { fetchApplications } from '../../store/slices/applicationSlice';
import { Link } from 'react-router-dom';

const CandidateDashboard = () => {
  const dispatch = useDispatch();
  const { user } = useSelector(state => state.auth);
  const { applications, stats, loading } = useSelector(state => state.applications);
  const { savedResumes } = useSelector(state => state.resume);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (user?.id) {
      dispatch(fetchApplications(user.id));
    }
  }, [dispatch, user?.id]);

  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'applications', label: 'Applications', icon: FileText },
    { id: 'resumes', label: 'My Resumes', icon: FileText },
    { id: 'recommendations', label: 'Job Matches', icon: Target },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'interview_scheduled':
        return 'bg-green-500/10 text-green-400 border-green-500/20';
      case 'under_review':
        return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      case 'applied':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'rejected':
        return 'bg-red-500/10 text-red-400 border-red-500/20';
      default:
        return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'interview_scheduled':
        return 'Interview Scheduled';
      case 'under_review':
        return 'Under Review';
      case 'applied':
        return 'Applied';
      case 'rejected':
        return 'Rejected';
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-gray-300">Track your job applications and discover new opportunities</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 sticky top-24">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/20'
                          : 'text-gray-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Applications</p>
                        <p className="text-2xl font-bold text-white">{stats.total}</p>
                      </div>
                      <div className="p-3 bg-blue-500/10 rounded-xl">
                        <FileText className="w-6 h-6 text-blue-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Interviews</p>
                        <p className="text-2xl font-bold text-white">{stats.interviews}</p>
                      </div>
                      <div className="p-3 bg-green-500/10 rounded-xl">
                        <Calendar className="w-6 h-6 text-green-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Pending</p>
                        <p className="text-2xl font-bold text-white">{stats.pending}</p>
                      </div>
                      <div className="p-3 bg-yellow-500/10 rounded-xl">
                        <TrendingUp className="w-6 h-6 text-yellow-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Success Rate</p>
                        <p className="text-2xl font-bold text-white">
                          {stats.total > 0 ? Math.round((stats.interviews / stats.total) * 100) : 0}%
                        </p>
                      </div>
                      <div className="p-3 bg-purple-500/10 rounded-xl">
                        <Target className="w-6 h-6 text-purple-400" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                  <h3 className="text-xl font-bold text-white mb-6">Quick Actions</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Link
                      to="/resume-builder"
                      className="flex items-center space-x-3 p-4 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 hover:bg-white/10 transition-all duration-200"
                    >
                      <div className="p-2 bg-yellow-400/10 rounded-lg">
                        <FileText className="w-5 h-5 text-yellow-400" />
                      </div>
                      <div>
                        <h4 className="text-white font-medium">Build Resume</h4>
                        <p className="text-gray-400 text-sm">Create AI-powered resume</p>
                      </div>
                    </Link>

                    <Link
                      to="/jobs"
                      className="flex items-center space-x-3 p-4 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 hover:bg-white/10 transition-all duration-200"
                    >
                      <div className="p-2 bg-blue-400/10 rounded-lg">
                        <Target className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <h4 className="text-white font-medium">Find Jobs</h4>
                        <p className="text-gray-400 text-sm">Browse opportunities</p>
                      </div>
                    </Link>

                    <button className="flex items-center space-x-3 p-4 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 hover:bg-white/10 transition-all duration-200">
                      <div className="p-2 bg-green-400/10 rounded-lg">
                        <Bell className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <h4 className="text-white font-medium">Job Alerts</h4>
                        <p className="text-gray-400 text-sm">Set up notifications</p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                  <h3 className="text-xl font-bold text-white mb-6">Recent Activity</h3>
                  <div className="space-y-4">
                    {applications.slice(0, 3).map((app) => (
                      <div key={app.id} className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl">
                        <div className="p-2 bg-blue-500/10 rounded-lg">
                          <FileText className="w-5 h-5 text-blue-400" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white font-medium">Applied to {app.jobTitle}</p>
                          <p className="text-gray-400 text-sm">{app.company} • {app.appliedDate}</p>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-sm font-semibold border ${getStatusColor(app.status)}`}>
                          {getStatusText(app.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Applications Tab */}
            {activeTab === 'applications' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Job Applications</h3>
                {loading ? (
                  <div className="text-center py-8">
                    <div className="w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                    <p className="text-gray-400">Loading applications...</p>
                  </div>
                ) : applications.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No applications yet</p>
                    <Link
                      to="/jobs"
                      className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                    >
                      <span>Browse Jobs</span>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {applications.map((app) => (
                      <div key={app.id} className="p-6 bg-white/5 rounded-xl border border-white/10">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-semibold text-white">{app.jobTitle}</h4>
                            <p className="text-gray-300">{app.company}</p>
                          </div>
                          <div className="text-right">
                            <div className="px-3 py-1 bg-yellow-400/10 rounded-full text-yellow-400 text-sm font-semibold mb-2">
                              {app.matchScore}% match
                            </div>
                            <div className={`px-3 py-1 rounded-full text-sm font-semibold border ${getStatusColor(app.status)}`}>
                              {getStatusText(app.status)}
                            </div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-gray-400">Applied</p>
                            <p className="text-white">{app.appliedDate}</p>
                          </div>
                          <div>
                            <p className="text-gray-400">Stage</p>
                            <p className="text-white">{app.stage}</p>
                          </div>
                          <div>
                            <p className="text-gray-400">Next Step</p>
                            <p className="text-white">{app.nextStep}</p>
                          </div>
                          <div>
                            <p className="text-gray-400">Match Score</p>
                            <p className="text-white">{app.matchScore}%</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Resumes Tab */}
            {activeTab === 'resumes' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">My Resumes</h3>
                  <Link
                    to="/resume-builder"
                    className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                  >
                    <Plus className="w-4 h-4" />
                    <span>New Resume</span>
                  </Link>
                </div>

                {savedResumes.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No resumes created yet</p>
                    <Link
                      to="/resume-builder"
                      className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Create Your First Resume</span>
                    </Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {savedResumes.map((resume) => (
                      <div key={resume.id} className="p-6 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-semibold text-white">{resume.name}</h4>
                            <p className="text-gray-400 text-sm">
                              Updated {new Date(resume.updatedAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="p-2 bg-yellow-400/10 rounded-lg">
                            <FileText className="w-5 h-5 text-yellow-400" />
                          </div>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Link
                            to={`/resume-builder?resume=${resume.id}`}
                            className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-center hover:bg-white/20 transition-all duration-200"
                          >
                            Edit
                          </Link>
                          <button className="flex-1 px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 hover:bg-blue-500/20 transition-all duration-200">
                            Download
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Other tabs content */}
            {activeTab === 'recommendations' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">AI Job Recommendations</h3>
                <div className="text-center py-12">
                  <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">Job recommendations will appear here based on your profile</p>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Profile Settings</h3>
                <p className="text-gray-300">Manage your profile information and preferences.</p>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Account Settings</h3>
                <p className="text-gray-300">Configure your account settings and notifications.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateDashboard;