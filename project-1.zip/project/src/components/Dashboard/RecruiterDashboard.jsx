import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Plus, Users, Briefcase, BarChart3, Settings, Search, Filter, Star, Eye } from 'lucide-react';
import { fetchJobs, createJob } from '../../store/slices/jobSlice';
import { useForm } from 'react-hook-form';
import { toast } from 'react-hot-toast';

const RecruiterDashboard = () => {
  const dispatch = useDispatch();
  const { user } = useSelector(state => state.auth);
  const { jobs, loading } = useSelector(state => state.jobs);
  const [activeTab, setActiveTab] = useState('overview');
  const [showJobForm, setShowJobForm] = useState(false);
  const [candidates, setCandidates] = useState([]);

  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  useEffect(() => {
    dispatch(fetchJobs());
  }, [dispatch]);

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'jobs', label: 'Job Postings', icon: Briefcase },
    { id: 'candidates', label: 'Candidates', icon: Users },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const onSubmitJob = async (data) => {
    try {
      await dispatch(createJob({
        ...data,
        skills: data.skills.split(',').map(skill => skill.trim()),
        requirements: data.requirements.split('\n').filter(req => req.trim()),
        benefits: data.benefits.split('\n').filter(benefit => benefit.trim())
      })).unwrap();
      
      toast.success('Job posted successfully!');
      setShowJobForm(false);
      reset();
    } catch (error) {
      toast.error('Failed to post job');
    }
  };

  const handleFindCandidates = async (jobTitle) => {
    // Mock AI candidate generation
    const mockCandidates = [
      {
        id: 1,
        name: 'Sarah Johnson',
        title: 'Senior React Developer',
        experience: '5+ years',
        skills: ['React', 'TypeScript', 'Node.js'],
        matchScore: 94,
        location: 'San Francisco, CA',
        email: 'sarah.j@email.com'
      },
      {
        id: 2,
        name: 'Mike Chen',
        title: 'Frontend Engineer',
        experience: '4 years',
        skills: ['React', 'JavaScript', 'CSS'],
        matchScore: 89,
        location: 'Remote',
        email: 'mike.chen@email.com'
      },
      {
        id: 3,
        name: 'Alex Rodriguez',
        title: 'Full Stack Developer',
        experience: '6 years',
        skills: ['React', 'Node.js', 'MongoDB'],
        matchScore: 87,
        location: 'New York, NY',
        email: 'alex.r@email.com'
      }
    ];
    
    setCandidates(mockCandidates);
    setActiveTab('candidates');
    toast.success(`Found ${mockCandidates.length} matching candidates for ${jobTitle}`);
  };

  const stats = {
    activeJobs: jobs.filter(job => job.status === 'active').length,
    totalApplicants: jobs.reduce((sum, job) => sum + job.applicants, 0),
    interviews: Math.floor(jobs.reduce((sum, job) => sum + job.applicants, 0) * 0.2),
    hireRate: 24
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">
              Welcome, {user?.name}
            </h1>
            <p className="text-gray-300">Manage your job postings and find the perfect candidates</p>
          </div>
          <button
            onClick={() => setShowJobForm(true)}
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
          >
            <Plus className="w-5 h-5" />
            <span>Post New Job</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 sticky top-24">
              <div className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                        activeTab === tab.id
                          ? 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/20'
                          : 'text-gray-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Active Jobs</p>
                        <p className="text-2xl font-bold text-white">{stats.activeJobs}</p>
                      </div>
                      <div className="p-3 bg-blue-500/10 rounded-xl">
                        <Briefcase className="w-6 h-6 text-blue-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Total Applicants</p>
                        <p className="text-2xl font-bold text-white">{stats.totalApplicants}</p>
                      </div>
                      <div className="p-3 bg-green-500/10 rounded-xl">
                        <Users className="w-6 h-6 text-green-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Interviews</p>
                        <p className="text-2xl font-bold text-white">{stats.interviews}</p>
                      </div>
                      <div className="p-3 bg-yellow-500/10 rounded-xl">
                        <Star className="w-6 h-6 text-yellow-400" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-400 text-sm">Hire Rate</p>
                        <p className="text-2xl font-bold text-white">{stats.hireRate}%</p>
                      </div>
                      <div className="p-3 bg-purple-500/10 rounded-xl">
                        <BarChart3 className="w-6 h-6 text-purple-400" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* AI Insights */}
                <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                  <h3 className="text-xl font-bold text-white mb-4">AI Insights</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-yellow-400/10 border border-yellow-400/20 rounded-xl">
                      <p className="text-yellow-400 font-semibold mb-2">Recommendation</p>
                      <p className="text-gray-300">Consider expanding your React Developer search to include remote candidates to increase your candidate pool by 40%.</p>
                    </div>
                    <div className="p-4 bg-blue-400/10 border border-blue-400/20 rounded-xl">
                      <p className="text-blue-400 font-semibold mb-2">Trend Alert</p>
                      <p className="text-gray-300">JavaScript and React skills are in high demand. Average time-to-hire for these roles has increased by 15%.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Jobs Tab */}
            {activeTab === 'jobs' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Job Postings</h3>
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <input
                        type="text"
                        placeholder="Search jobs..."
                        className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      />
                    </div>
                    <button className="p-2 bg-white/10 border border-white/20 rounded-lg text-gray-400 hover:text-white">
                      <Filter className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {loading ? (
                  <div className="text-center py-8">
                    <div className="w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                    <p className="text-gray-400">Loading jobs...</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {jobs.map((job) => (
                      <div key={job.id} className="p-6 bg-white/5 rounded-xl border border-white/10 hover:border-white/20 transition-all duration-300">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-semibold text-white">{job.title}</h4>
                            <p className="text-gray-300">{job.company}</p>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
                            job.status === 'active' 
                              ? 'bg-green-400/10 text-green-400' 
                              : 'bg-gray-400/10 text-gray-400'
                          }`}>
                            {job.status}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 text-sm mb-4">
                          <div>
                            <p className="text-gray-400">Applicants</p>
                            <p className="text-white font-medium">{job.applicants}</p>
                          </div>
                          <div>
                            <p className="text-gray-400">Views</p>
                            <p className="text-white">{job.views}</p>
                          </div>
                          <div>
                            <p className="text-gray-400">Posted</p>
                            <p className="text-white">{job.posted}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <button
                            onClick={() => handleFindCandidates(job.title)}
                            className="flex items-center space-x-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/20 rounded-lg text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200"
                          >
                            <Users className="w-4 h-4" />
                            <span>Find Candidates</span>
                          </button>
                          <div className="flex space-x-2">
                            <button className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 transition-all duration-200">
                              Edit
                            </button>
                            <button className="flex items-center space-x-2 px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 hover:bg-blue-500/20 transition-all duration-200">
                              <Eye className="w-4 h-4" />
                              <span>View</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Candidates Tab */}
            {activeTab === 'candidates' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">AI-Recommended Candidates</h3>
                
                {candidates.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No candidates found yet</p>
                    <p className="text-sm text-gray-500">Use "Find Candidates" on your job postings to discover AI-matched talent</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {candidates.map((candidate) => (
                      <div key={candidate.id} className="p-6 bg-white/5 rounded-xl border border-white/10">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-semibold text-white">{candidate.name}</h4>
                            <p className="text-gray-300">{candidate.title}</p>
                            <p className="text-gray-400 text-sm">{candidate.email}</p>
                          </div>
                          <div className="flex items-center space-x-1 px-3 py-1 bg-green-400/10 rounded-full text-green-400 text-sm font-semibold">
                            <Star className="w-4 h-4" />
                            <span>{candidate.matchScore}%</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-4">
                          {candidate.skills.map((skill, index) => (
                            <span key={index} className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300 border border-white/20">
                              {skill}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-400">
                            <span>{candidate.experience} • {candidate.location}</span>
                          </div>
                          <div className="flex space-x-2">
                            <button className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 transition-all duration-200">
                              View Profile
                            </button>
                            <button className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-lg text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                              Contact
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Settings Tab */}
            {activeTab === 'settings' && (
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Account Settings</h3>
                <p className="text-gray-300">Configure your account settings and preferences.</p>
              </div>
            )}
          </div>
        </div>

        {/* Job Creation Modal */}
        {showJobForm && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-slate-900 rounded-2xl border border-white/10 p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-white">Post New Job</h3>
                <button
                  onClick={() => setShowJobForm(false)}
                  className="text-gray-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSubmit(onSubmitJob)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Job Title</label>
                    <input
                      type="text"
                      {...register('title', { required: 'Job title is required' })}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      placeholder="e.g. Senior React Developer"
                    />
                    {errors.title && <p className="mt-1 text-sm text-red-400">{errors.title.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Company</label>
                    <input
                      type="text"
                      {...register('company', { required: 'Company is required' })}
                      defaultValue={user?.company || ''}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      placeholder="Company name"
                    />
                    {errors.company && <p className="mt-1 text-sm text-red-400">{errors.company.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Location</label>
                    <input
                      type="text"
                      {...register('location', { required: 'Location is required' })}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      placeholder="e.g. San Francisco, CA or Remote"
                    />
                    {errors.location && <p className="mt-1 text-sm text-red-400">{errors.location.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Job Type</label>
                    <select
                      {...register('type', { required: 'Job type is required' })}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none"
                    >
                      <option value="">Select type</option>
                      <option value="Full-time">Full-time</option>
                      <option value="Part-time">Part-time</option>
                      <option value="Contract">Contract</option>
                      <option value="Remote">Remote</option>
                    </select>
                    {errors.type && <p className="mt-1 text-sm text-red-400">{errors.type.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Salary Range</label>
                    <input
                      type="text"
                      {...register('salary', { required: 'Salary range is required' })}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      placeholder="e.g. $120k - $150k"
                    />
                    {errors.salary && <p className="mt-1 text-sm text-red-400">{errors.salary.message}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Skills (comma-separated)</label>
                    <input
                      type="text"
                      {...register('skills', { required: 'Skills are required' })}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      placeholder="React, JavaScript, TypeScript, Node.js"
                    />
                    {errors.skills && <p className="mt-1 text-sm text-red-400">{errors.skills.message}</p>}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Job Description</label>
                  <textarea
                    {...register('description', { required: 'Job description is required' })}
                    rows={4}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                    placeholder="Describe the role, responsibilities, and what you're looking for..."
                  />
                  {errors.description && <p className="mt-1 text-sm text-red-400">{errors.description.message}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Requirements (one per line)</label>
                  <textarea
                    {...register('requirements')}
                    rows={3}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                    placeholder="5+ years React experience&#10;Strong JavaScript skills&#10;Team collaboration"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Benefits (one per line)</label>
                  <textarea
                    {...register('benefits')}
                    rows={3}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                    placeholder="Health insurance&#10;Remote work&#10;401k matching"
                  />
                </div>

                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={() => setShowJobForm(false)}
                    className="flex-1 px-6 py-3 bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                  >
                    Post Job
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RecruiterDashboard;