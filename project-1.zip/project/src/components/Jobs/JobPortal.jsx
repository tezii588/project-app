import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Clock, DollarSign, Filter, Star, Briefcase, Users, Eye } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { fetchJobs, setFilters, selectJob, applyToJob } from '../../store/slices/jobSlice';
import { addApplication } from '../../store/slices/applicationSlice';

const JobPortal = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { jobs, loading, filters } = useSelector(state => state.jobs);
  const { isAuthenticated, user } = useSelector(state => state.auth);
  const { currentResume } = useSelector(state => state.resume);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedJobId, setSelectedJobId] = useState(null);

  useEffect(() => {
    dispatch(fetchJobs(filters));
  }, [dispatch, filters]);

  const handleFilterChange = (key, value) => {
    dispatch(setFilters({ [key]: value }));
  };

  const handleApplyToJob = async (job) => {
    if (!isAuthenticated) {
      toast.error('Please login to apply for jobs');
      navigate('/login');
      return;
    }

    if (user?.role !== 'candidate') {
      toast.error('Only candidates can apply for jobs');
      return;
    }

    try {
      // Apply to job
      await dispatch(applyToJob({
        jobId: job.id,
        candidateId: user.id,
        resumeData: currentResume
      })).unwrap();

      // Add to applications
      dispatch(addApplication({
        id: Date.now(),
        jobId: job.id,
        jobTitle: job.title,
        company: job.company,
        appliedDate: new Date().toISOString().split('T')[0],
        status: 'applied',
        matchScore: calculateMatchScore(job),
        stage: 'Application Submitted',
        nextStep: 'Waiting for review'
      }));

      toast.success(`Successfully applied to ${job.title} at ${job.company}!`);
    } catch (error) {
      toast.error('Failed to apply for job');
    }
  };

  const calculateMatchScore = (job) => {
    // Simple match score calculation based on skills
    const jobSkills = job.skills.map(skill => skill.toLowerCase());
    const userSkills = currentResume.skills.map(skill => skill.toLowerCase());
    
    const matchingSkills = jobSkills.filter(skill => 
      userSkills.some(userSkill => userSkill.includes(skill) || skill.includes(userSkill))
    );
    
    return Math.min(95, Math.max(60, Math.round((matchingSkills.length / jobSkills.length) * 100)));
  };

  const getMatchScoreColor = (score) => {
    if (score >= 90) return 'text-green-400 bg-green-400/10';
    if (score >= 80) return 'text-yellow-400 bg-yellow-400/10';
    return 'text-orange-400 bg-orange-400/10';
  };

  return (
    <section id="jobs" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-6">
            Discover Your
            <span className="bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent"> Dream Job</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Browse thousands of opportunities from top companies, powered by AI matching technology
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 mb-12">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search jobs, companies, or skills..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus: transition-colors duration-200"
              />
            </div>

            {/* Location Filter */}
            <div className="relative">
              <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={filters.location}
                onChange={(e) => handleFilterChange('location', e.target.value)}
                className="pl-12 pr-8 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none transition-colors duration-200 appearance-none"
              >
                <option value="">All Locations</option>
                <option value="San Francisco">San Francisco</option>
                <option value="New York">New York</option>
                <option value="Austin">Austin</option>
                <option value="Remote">Remote</option>
                <option value="Los Angeles">Los Angeles</option>
                <option value="Seattle">Seattle</option>
              </select>
            </div>

            {/* Job Type Filter */}
            <div className="relative">
              <Briefcase className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <select
                value={filters.type}
                onChange={(e) => handleFilterChange('type', e.target.value)}
                className="pl-12 pr-8 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none transition-colors duration-200 appearance-none"
              >
                <option value="">All Types</option>
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Remote">Remote</option>
              </select>
            </div>

            {/* Filter Toggle */}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-3 bg-yellow-400/10 border border-yellow-400/20 rounded-xl text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200"
            >
              <Filter className="w-5 h-5" />
              <span>Filters</span>
            </button>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-white/10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Salary Range</label>
                  <select className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:border-yellow-400 focus:outline-none">
                    <option value="">Any Salary</option>
                    <option value="50k-80k">$50k - $80k</option>
                    <option value="80k-120k">$80k - $120k</option>
                    <option value="120k+">$120k+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Experience Level</label>
                  <select className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:border-yellow-400 focus:outline-none">
                    <option value="">Any Level</option>
                    <option value="entry">Entry Level</option>
                    <option value="mid">Mid Level</option>
                    <option value="senior">Senior Level</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Company Size</label>
                  <select className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:border-yellow-400 focus:outline-none">
                    <option value="">Any Size</option>
                    <option value="startup">Startup</option>
                    <option value="medium">Medium</option>
                    <option value="large">Large</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="text-white">
            <span className="text-lg font-semibold">{jobs.length} jobs found</span>
            {filters.search && <span className="text-gray-400 ml-2">for "{filters.search}"</span>}
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-gray-400 text-sm">Sort by:</span>
            <select className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm focus:border-yellow-400 focus:outline-none">
              <option value="relevance">Relevance</option>
              <option value="date">Date Posted</option>
              <option value="salary">Salary</option>
              <option value="match">Match Score</option>
            </select>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center py-12">
            <div className="w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-gray-400">Loading jobs...</p>
          </div>
        )}

        {/* Job Cards */}
        {!loading && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {jobs.map((job) => {
              const matchScore = isAuthenticated && user?.role === 'candidate' ? calculateMatchScore(job) : null;
              
              return (
                <div key={job.id} className="group bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 hover:border-white/20 transition-all duration-300 p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-xl flex items-center justify-center text-2xl">
                        💼
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white group-hover:text-yellow-400 transition-colors duration-200">
                          {job.title}
                        </h3>
                        <p className="text-gray-300">{job.company}</p>
                      </div>
                    </div>
                    {matchScore && (
                      <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getMatchScoreColor(matchScore)}`}>
                        {matchScore}% match
                      </div>
                    )}
                  </div>

                  {/* Job Details */}
                  <div className="flex flex-wrap items-center gap-4 mb-4 text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <MapPin className="w-4 h-4" />
                      <span>{job.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Briefcase className="w-4 h-4" />
                      <span>{job.type}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <DollarSign className="w-4 h-4" />
                      <span>{job.salary}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{job.posted}</span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-300 mb-4 line-clamp-2">{job.description}</p>

                  {/* Skills */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {job.skills.slice(0, 4).map((skill, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-300 border border-white/20"
                      >
                        {skill}
                      </span>
                    ))}
                    {job.skills.length > 4 && (
                      <span className="px-3 py-1 bg-white/10 rounded-full text-sm text-gray-400 border border-white/20">
                        +{job.skills.length - 4} more
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => setSelectedJobId(selectedJobId === job.id ? null : job.id)}
                      className="flex items-center space-x-1 text-yellow-400 hover:text-yellow-300 transition-colors duration-200"
                    >
                      <Eye className="w-4 h-4" />
                      <span>{selectedJobId === job.id ? 'Hide Details' : 'View Details'}</span>
                    </button>
                    <div className="flex space-x-3">
                      <button className="flex items-center space-x-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white hover:bg-white/20 transition-all duration-200">
                        <Star className="w-4 h-4" />
                        <span>Save</span>
                      </button>
                      <button
                        onClick={() => handleApplyToJob(job)}
                        className="px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-lg text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                      >
                        Apply Now
                      </button>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {selectedJobId === job.id && (
                    <div className="mt-6 pt-6 border-t border-white/10 space-y-4">
                      <div>
                        <h4 className="text-white font-semibold mb-2">Requirements</h4>
                        <ul className="text-gray-300 text-sm space-y-1">
                          {job.requirements?.map((req, index) => (
                            <li key={index} className="flex items-start space-x-2">
                              <span className="text-yellow-400 mt-1">•</span>
                              <span>{req}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="text-white font-semibold mb-2">Benefits</h4>
                        <ul className="text-gray-300 text-sm space-y-1">
                          {job.benefits?.map((benefit, index) => (
                            <li key={index} className="flex items-start space-x-2">
                              <span className="text-green-400 mt-1">•</span>
                              <span>{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Load More */}
        {!loading && jobs.length > 0 && (
          <div className="text-center mt-12">
            <button className="flex items-center space-x-2 mx-auto px-8 py-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200">
              <Users className="w-5 h-5" />
              <span>Load More Jobs</span>
            </button>
          </div>
        )}

        {/* Empty State */}
        {!loading && jobs.length === 0 && (
          <div className="text-center py-12">
            <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No jobs found</h3>
            <p className="text-gray-400 mb-6">Try adjusting your search criteria or filters</p>
            <button
              onClick={() => {
                dispatch(setFilters({ search: '', location: '', type: '' }));
                setShowFilters(false);
              }}
              className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default JobPortal;