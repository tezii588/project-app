import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { ArrowLeft, Download, Eye, Sparkles, User, Briefcase, GraduationCap, Award, Plus, Trash2, Save } from 'lucide-react';
import { toast } from 'react-hot-toast';
import {
  updateResumeField,
  addResumeSection,
  removeResumeSection,
  generateResumeContent,
  saveResume,
  loadResume,
  clearResume
} from '../../store/slices/resumeSlice';

const ResumeBuilder = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const resumeId = searchParams.get('resume');
  
  const { currentResume, generatedContent, loading, error } = useSelector(state => state.resume);
  const { isAuthenticated } = useSelector(state => state.auth);
  
  const [step, setStep] = useState(1);
  const [resumeName, setResumeName] = useState('');

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (resumeId) {
      dispatch(loadResume(parseInt(resumeId)));
    } else {
      dispatch(clearResume());
    }
  }, [dispatch, isAuthenticated, navigate, resumeId]);

  const updateField = (section, field, value, index = null) => {
    dispatch(updateResumeField({ section, field, value, index }));
  };

  const addItem = (section) => {
    const templates = {
      experience: {
        title: '',
        company: '',
        location: '',
        startDate: '',
        endDate: '',
        current: false,
        description: ''
      },
      education: {
        degree: '',
        school: '',
        location: '',
        graduationDate: '',
        gpa: ''
      },
      achievements: '',
      certifications: {
        name: '',
        issuer: '',
        date: '',
        url: ''
      }
    };
    
    dispatch(addResumeSection({ section, item: templates[section] }));
  };

  const removeItem = (section, index) => {
    dispatch(removeResumeSection({ section, index }));
  };

  const handleGenerateResume = async () => {
    try {
      await dispatch(generateResumeContent(currentResume)).unwrap();
      setStep(5);
      toast.success('Resume generated successfully!');
    } catch (error) {
      toast.error('Failed to generate resume');
    }
  };

  const handleSaveResume = () => {
    if (!resumeName.trim()) {
      toast.error('Please enter a resume name');
      return;
    }
    
    dispatch(saveResume({ name: resumeName }));
    toast.success('Resume saved successfully!');
  };

  const steps = [
    { id: 1, title: 'Personal Info', icon: User },
    { id: 2, title: 'Experience', icon: Briefcase },
    { id: 3, title: 'Education', icon: GraduationCap },
    { id: 4, title: 'Skills & More', icon: Award },
    { id: 5, title: 'Generated Resume', icon: Eye }
  ];

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link
              to="/candidate-dashboard"
              className="p-2 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">AI Resume Builder</h1>
              <p className="text-gray-300">Create a professional resume in minutes</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 px-4 py-2 rounded-full bg-yellow-400/10 border border-yellow-400/20 text-yellow-400">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-semibold">AI Powered</span>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6 mb-8">
          <div className="flex items-center justify-between">
            {steps.map((stepItem, index) => {
              const Icon = stepItem.icon;
              const isActive = step === stepItem.id;
              const isComplete = step > stepItem.id;
              
              return (
                <div key={stepItem.id} className="flex items-center">
                  <div className={`flex items-center space-x-3 ${
                    isActive ? 'text-yellow-400' : isComplete ? 'text-green-400' : 'text-gray-400'
                  }`}>
                    <div className={`p-3 rounded-xl border-2 transition-all duration-200 ${
                      isActive 
                        ? 'bg-yellow-400/10 border-yellow-400' 
                        : isComplete 
                        ? 'bg-green-400/10 border-green-400'
                        : 'bg-white/5 border-white/20'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="font-medium hidden sm:block">{stepItem.title}</span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-8 h-0.5 mx-4 ${
                      isComplete ? 'bg-green-400' : 'bg-white/20'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-8">
              {/* Step 1: Personal Info */}
              {step === 1 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white mb-6">Personal Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
                      <input
                        type="text"
                        value={currentResume.personalInfo.fullName}
                        onChange={(e) => updateField('personalInfo', 'fullName', e.target.value)}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                        placeholder="John Doe"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                      <input
                        type="email"
                        value={currentResume.personalInfo.email}
                        onChange={(e) => updateField('personalInfo', 'email', e.target.value)}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                        placeholder="john@example.com"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Phone</label>
                      <input
                        type="tel"
                        value={currentResume.personalInfo.phone}
                        onChange={(e) => updateField('personalInfo', 'phone', e.target.value)}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Location</label>
                      <input
                        type="text"
                        value={currentResume.personalInfo.location}
                        onChange={(e) => updateField('personalInfo', 'location', e.target.value)}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                        placeholder="San Francisco, CA"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">LinkedIn</label>
                      <input
                        type="url"
                        value={currentResume.personalInfo.linkedin}
                        onChange={(e) => updateField('personalInfo', 'linkedin', e.target.value)}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                        placeholder="https://linkedin.com/in/johndoe"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Portfolio</label>
                      <input
                        type="url"
                        value={currentResume.personalInfo.portfolio}
                        onChange={(e) => updateField('personalInfo', 'portfolio', e.target.value)}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                        placeholder="https://johndoe.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Professional Summary</label>
                    <textarea
                      value={currentResume.summary}
                      onChange={(e) => updateField('', 'summary', e.target.value)}
                      rows={4}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none transition-colors duration-200"
                      placeholder="Brief summary of your professional background and key achievements..."
                    />
                  </div>
                </div>
              )}

              {/* Step 2: Experience */}
              {step === 2 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-white">Work Experience</h2>
                    <button
                      onClick={() => addItem('experience')}
                      className="flex items-center space-x-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/20 rounded-lg text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Experience</span>
                    </button>
                  </div>

                  {currentResume.experience.length === 0 && (
                    <div className="text-center py-8">
                      <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400 mb-4">No work experience added yet</p>
                      <button
                        onClick={() => addItem('experience')}
                        className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                      >
                        Add Your First Job
                      </button>
                    </div>
                  )}

                  {currentResume.experience.map((exp, index) => (
                    <div key={index} className="p-6 bg-white/5 rounded-xl border border-white/10">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">Experience #{index + 1}</h3>
                        {currentResume.experience.length > 1 && (
                          <button
                            onClick={() => removeItem('experience', index)}
                            className="p-2 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-lg transition-all duration-200"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <input
                          type="text"
                          value={exp.title || ''}
                          onChange={(e) => updateField('experience', 'title', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="Job Title"
                        />
                        <input
                          type="text"
                          value={exp.company || ''}
                          onChange={(e) => updateField('experience', 'company', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="Company Name"
                        />
                        <input
                          type="text"
                          value={exp.location || ''}
                          onChange={(e) => updateField('experience', 'location', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="Location"
                        />
                        <div className="flex space-x-2">
                          <input
                            type="month"
                            value={exp.startDate || ''}
                            onChange={(e) => updateField('experience', 'startDate', e.target.value, index)}
                            className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none"
                          />
                          <input
                            type="month"
                            value={exp.endDate || ''}
                            onChange={(e) => updateField('experience', 'endDate', e.target.value, index)}
                            disabled={exp.current}
                            className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div className="mb-4">
                        <label className="flex items-center space-x-2 text-gray-300">
                          <input
                            type="checkbox"
                            checked={exp.current || false}
                            onChange={(e) => updateField('experience', 'current', e.target.checked, index)}
                            className="rounded border-white/20 bg-white/10 text-yellow-400 focus:ring-yellow-400"
                          />
                          <span>I currently work here</span>
                        </label>
                      </div>
                      
                      <textarea
                        value={exp.description || ''}
                        onChange={(e) => updateField('experience', 'description', e.target.value, index)}
                        rows={3}
                        className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                        placeholder="Describe your role and achievements..."
                      />
                    </div>
                  ))}
                </div>
              )}

              {/* Step 3: Education */}
              {step === 3 && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-white">Education</h2>
                    <button
                      onClick={() => addItem('education')}
                      className="flex items-center space-x-2 px-4 py-2 bg-yellow-400/10 border border-yellow-400/20 rounded-lg text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Education</span>
                    </button>
                  </div>

                  {currentResume.education.length === 0 && (
                    <div className="text-center py-8">
                      <GraduationCap className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400 mb-4">No education added yet</p>
                      <button
                        onClick={() => addItem('education')}
                        className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                      >
                        Add Education
                      </button>
                    </div>
                  )}

                  {currentResume.education.map((edu, index) => (
                    <div key={index} className="p-6 bg-white/5 rounded-xl border border-white/10">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-white">Education #{index + 1}</h3>
                        {currentResume.education.length > 1 && (
                          <button
                            onClick={() => removeItem('education', index)}
                            className="p-2 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-lg transition-all duration-200"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input
                          type="text"
                          value={edu.degree || ''}
                          onChange={(e) => updateField('education', 'degree', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="Degree"
                        />
                        <input
                          type="text"
                          value={edu.school || ''}
                          onChange={(e) => updateField('education', 'school', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="School Name"
                        />
                        <input
                          type="text"
                          value={edu.location || ''}
                          onChange={(e) => updateField('education', 'location', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="Location"
                        />
                        <input
                          type="month"
                          value={edu.graduationDate || ''}
                          onChange={(e) => updateField('education', 'graduationDate', e.target.value, index)}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:border-yellow-400 focus:outline-none"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Step 4: Skills & More */}
              {step === 4 && (
                <div className="space-y-8">
                  <h2 className="text-2xl font-bold text-white">Skills & Additional Information</h2>
                  
                  {/* Skills */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Skills (comma-separated)</label>
                    <textarea
                      value={currentResume.skills.join(', ')}
                      onChange={(e) => updateField('', 'skills', e.target.value.split(',').map(skill => skill.trim()).filter(skill => skill))}
                      rows={3}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                      placeholder="JavaScript, React, Node.js, Python, SQL..."
                    />
                  </div>

                  {/* Achievements */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <label className="block text-sm font-medium text-gray-300">Achievements</label>
                      <button
                        onClick={() => addItem('achievements')}
                        className="flex items-center space-x-2 px-3 py-1 bg-yellow-400/10 border border-yellow-400/20 rounded-lg text-yellow-400 hover:bg-yellow-400/20 transition-all duration-200 text-sm"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add</span>
                      </button>
                    </div>
                    
                    {currentResume.achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center space-x-2 mb-2">
                        <input
                          type="text"
                          value={achievement}
                          onChange={(e) => {
                            const newAchievements = [...currentResume.achievements];
                            newAchievements[index] = e.target.value;
                            updateField('', 'achievements', newAchievements);
                          }}
                          className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                          placeholder="Achievement description"
                        />
                        <button
                          onClick={() => removeItem('achievements', index)}
                          className="p-2 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-lg transition-all duration-200"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 5: Generated Resume */}
              {step === 5 && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-white">Your AI-Generated Resume</h2>
                  
                  {generatedContent ? (
                    <div className="space-y-6">
                      <div className="bg-white/10 rounded-xl p-6 max-h-96 overflow-y-auto">
                        <pre className="text-sm text-gray-300 whitespace-pre-wrap font-mono">
                          {generatedContent}
                        </pre>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <input
                          type="text"
                          value={resumeName}
                          onChange={(e) => setResumeName(e.target.value)}
                          placeholder="Enter resume name"
                          className="flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:border-yellow-400 focus:outline-none"
                        />
                        <button
                          onClick={handleSaveResume}
                          className="flex items-center space-x-2 px-6 py-3 bg-green-500/10 border border-green-500/20 rounded-xl text-green-400 hover:bg-green-500/20 transition-all duration-200"
                        >
                          <Save className="w-4 h-4" />
                          <span>Save Resume</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Eye className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-400">Generate your resume to see the preview</p>
                    </div>
                  )}
                </div>
              )}

              {/* Navigation */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-white/10">
                <button
                  onClick={() => setStep(Math.max(1, step - 1))}
                  disabled={step === 1}
                  className="px-6 py-3 bg-white/10 border border-white/20 rounded-xl text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/20 transition-all duration-200"
                >
                  Previous
                </button>
                
                {step < 4 ? (
                  <button
                    onClick={() => setStep(step + 1)}
                    className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                  >
                    Next Step
                  </button>
                ) : step === 4 ? (
                  <button
                    onClick={handleGenerateResume}
                    disabled={loading}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200 disabled:opacity-50"
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-slate-900 border-t-transparent rounded-full animate-spin" />
                        <span>Generating...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Generate Resume</span>
                      </>
                    )}
                  </button>
                ) : (
                  <button
                    onClick={() => navigate('/candidate-dashboard')}
                    className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200"
                  >
                    Back to Dashboard
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Preview Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-4">Live Preview</h3>
                
                {step < 5 ? (
                  <div className="text-gray-400 text-center py-8">
                    <Eye className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Complete the form to see your resume preview</p>
                  </div>
                ) : generatedContent ? (
                  <div className="space-y-4">
                    <div className="bg-white/10 rounded-xl p-4 max-h-64 overflow-y-auto">
                      <pre className="text-xs text-gray-300 whitespace-pre-wrap">
                        {generatedContent.substring(0, 500)}...
                      </pre>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white hover:bg-white/20 transition-all duration-200">
                        <Eye className="w-4 h-4" />
                        <span>Preview</span>
                      </button>
                      <button className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-xl text-slate-900 font-semibold hover:scale-105 transition-transform duration-200">
                        <Download className="w-4 h-4" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-gray-400 text-center py-8">
                    <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Generate your resume to see the preview</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeBuilder;