import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

export const fetchApplications = createAsyncThunk(
  'applications/fetchApplications',
  async (candidateId) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Mock applications data
    return [
      {
        id: 1,
        jobId: 1,
        jobTitle: 'Senior React Developer',
        company: 'TechCorp Inc.',
        appliedDate: '2024-01-15',
        status: 'interview_scheduled',
        matchScore: 95,
        stage: 'Technical Interview',
        nextStep: 'Jan 25, 2024 - 2:00 PM',
        feedback: null
      },
      {
        id: 2,
        jobId: 2,
        jobTitle: 'AI/ML Engineer',
        company: 'DataFlow Solutions',
        appliedDate: '2024-01-12',
        status: 'under_review',
        matchScore: 88,
        stage: 'HR Review',
        nextStep: 'Waiting for response',
        feedback: null
      }
    ];
  }
);

export const updateApplicationStatus = createAsyncThunk(
  'applications/updateStatus',
  async ({ applicationId, status, feedback }) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return { applicationId, status, feedback };
  }
);

const applicationSlice = createSlice({
  name: 'applications',
  initialState: {
    applications: [],
    loading: false,
    error: null,
    stats: {
      total: 0,
      pending: 0,
      interviews: 0,
      offers: 0,
      rejected: 0
    }
  },
  reducers: {
    addApplication: (state, action) => {
      state.applications.push(action.payload);
      state.stats.total += 1;
      state.stats.pending += 1;
    },
    updateStats: (state) => {
      const stats = state.applications.reduce((acc, app) => {
        acc.total += 1;
        switch (app.status) {
          case 'applied':
          case 'under_review':
            acc.pending += 1;
            break;
          case 'interview_scheduled':
          case 'interview_completed':
            acc.interviews += 1;
            break;
          case 'offer_extended':
          case 'hired':
            acc.offers += 1;
            break;
          case 'rejected':
            acc.rejected += 1;
            break;
        }
        return acc;
      }, { total: 0, pending: 0, interviews: 0, offers: 0, rejected: 0 });
      
      state.stats = stats;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchApplications.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchApplications.fulfilled, (state, action) => {
        state.loading = false;
        state.applications = action.payload;
        // Update stats
        const stats = action.payload.reduce((acc, app) => {
          acc.total += 1;
          switch (app.status) {
            case 'applied':
            case 'under_review':
              acc.pending += 1;
              break;
            case 'interview_scheduled':
            case 'interview_completed':
              acc.interviews += 1;
              break;
            case 'offer_extended':
            case 'hired':
              acc.offers += 1;
              break;
            case 'rejected':
              acc.rejected += 1;
              break;
          }
          return acc;
        }, { total: 0, pending: 0, interviews: 0, offers: 0, rejected: 0 });
        state.stats = stats;
      })
      .addCase(fetchApplications.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(updateApplicationStatus.fulfilled, (state, action) => {
        const { applicationId, status, feedback } = action.payload;
        const application = state.applications.find(app => app.id === applicationId);
        if (application) {
          application.status = status;
          if (feedback) application.feedback = feedback;
        }
      });
  }
});

export const { addApplication, updateStats } = applicationSlice.actions;
export default applicationSlice.reducer;