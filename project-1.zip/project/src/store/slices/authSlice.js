import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Mock API calls
export const loginUser = createAsyncThunk(
  'auth/loginUser',
  async ({ email, password, role }, { rejectWithValue }) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Hardcoded credentials
      if (role === 'recruiter' && email === 'recruiter@gmail.com' && password === '1234') {
        return {
          id: 'rec_1',
          email: 'recruiter@gmail.com',
          role: 'recruiter',
          name: 'HR Manager',
          company: 'TechCorp Inc.'
        };
      } else if (role === 'candidate') {
        // For candidates, accept any email/password for demo
        return {
          id: 'cand_' + Date.now(),
          email,
          role: 'candidate',
          name: email.split('@')[0],
          skills: [],
          experience: []
        };
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const registerUser = createAsyncThunk(
  'auth/registerUser',
  async ({ email, password, name, role }, { rejectWithValue }) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Only allow candidate registration
      if (role === 'candidate') {
        return {
          id: 'cand_' + Date.now(),
          email,
          role: 'candidate',
          name,
          skills: [],
          experience: []
        };
      } else {
        throw new Error('Registration only available for candidates');
      }
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    isAuthenticated: false,
    loading: false,
    error: null
  },
  reducers: {
    logout: (state) => {
      state.user = null;
      state.isAuthenticated = false;
      state.error = null;
    },
    clearError: (state) => {
      state.error = null;
    },
    updateProfile: (state, action) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload };
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(registerUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        state.isAuthenticated = true;
        state.error = null;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export const { logout, clearError, updateProfile } = authSlice.actions;
export default authSlice.reducer;