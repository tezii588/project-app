import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Mock job data
const mockJobs = [
  {
    id: 1,
    title: 'Senior React Developer',
    company: 'TechCorp Inc.',
    location: 'San Francisco, CA',
    type: 'Full-time',
    salary: '$120k - $150k',
    posted: '2 days ago',
    skills: ['React', 'JavaScript', 'TypeScript', 'Node.js'],
    description: 'We are looking for an experienced React developer to join our growing team...',
    requirements: ['5+ years React experience', 'Strong JavaScript skills', 'Team collaboration'],
    benefits: ['Health insurance', 'Remote work', '401k matching'],
    status: 'active',
    applicants: 24,
    views: 156
  },
  {
    id: 2,
    title: 'AI/ML Engineer',
    company: 'DataFlow Solutions',
    location: 'New York, NY',
    type: 'Full-time',
    salary: '$130k - $170k',
    posted: '1 day ago',
    skills: ['Python', 'TensorFlow', 'Machine Learning', 'AI'],
    description: 'Join our AI team to build cutting-edge machine learning solutions...',
    requirements: ['PhD in ML/AI', 'Python expertise', 'Research experience'],
    benefits: ['Stock options', 'Flexible hours', 'Learning budget'],
    status: 'active',
    applicants: 18,
    views: 203
  }
];

export const fetchJobs = createAsyncThunk(
  'jobs/fetchJobs',
  async (filters = {}) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    let filteredJobs = [...mockJobs];
    
    if (filters.search) {
      filteredJobs = filteredJobs.filter(job => 
        job.title.toLowerCase().includes(filters.search.toLowerCase()) ||
        job.company.toLowerCase().includes(filters.search.toLowerCase())
      );
    }
    
    if (filters.location) {
      filteredJobs = filteredJobs.filter(job => 
        job.location.toLowerCase().includes(filters.location.toLowerCase())
      );
    }
    
    if (filters.type) {
      filteredJobs = filteredJobs.filter(job => job.type === filters.type);
    }
    
    return filteredJobs;
  }
);

export const createJob = createAsyncThunk(
  'jobs/createJob',
  async (jobData) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newJob = {
      id: Date.now(),
      ...jobData,
      posted: 'Just now',
      applicants: 0,
      views: 0,
      status: 'active'
    };
    
    return newJob;
  }
);

export const applyToJob = createAsyncThunk(
  'jobs/applyToJob',
  async ({ jobId, candidateId, resumeData }) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      id: Date.now(),
      jobId,
      candidateId,
      appliedDate: new Date().toISOString(),
      status: 'applied',
      resumeData
    };
  }
);

const jobSlice = createSlice({
  name: 'jobs',
  initialState: {
    jobs: [],
    selectedJob: null,
    loading: false,
    error: null,
    filters: {
      search: '',
      location: '',
      type: ''
    }
  },
  reducers: {
    setFilters: (state, action) => {
      state.filters = { ...state.filters, ...action.payload };
    },
    selectJob: (state, action) => {
      state.selectedJob = action.payload;
    },
    clearSelectedJob: (state) => {
      state.selectedJob = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchJobs.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchJobs.fulfilled, (state, action) => {
        state.loading = false;
        state.jobs = action.payload;
      })
      .addCase(fetchJobs.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(createJob.fulfilled, (state, action) => {
        state.jobs.unshift(action.payload);
      })
      .addCase(applyToJob.fulfilled, (state, action) => {
        // Update job applicant count
        const job = state.jobs.find(j => j.id === action.payload.jobId);
        if (job) {
          job.applicants += 1;
        }
      });
  }
});

export const { setFilters, selectJob, clearSelectedJob } = jobSlice.actions;
export default jobSlice.reducer;