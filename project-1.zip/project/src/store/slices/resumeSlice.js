import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true
});

export const generateResumeContent = createAsyncThunk(
  'resume/generateContent',
  async (resumeData, { rejectWithValue }) => {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a professional resume writer. Create a well-structured, ATS-friendly resume based on the provided information. Format it in clean, professional sections."
          },
          {
            role: "user",
            content: `Please create a professional resume based on this information: ${JSON.stringify(resumeData)}`
          }
        ],
        max_tokens: 1500,
        temperature: 0.7
      });

      return response.choices[0].message.content;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

export const optimizeResume = createAsyncThunk(
  'resume/optimize',
  async ({ resumeData, jobDescription }, { rejectWithValue }) => {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are an AI resume optimizer. Analyze the resume and job description, then provide specific suggestions to improve the resume for this position."
          },
          {
            role: "user",
            content: `Resume: ${JSON.stringify(resumeData)}\n\nJob Description: ${jobDescription}\n\nProvide optimization suggestions.`
          }
        ],
        max_tokens: 800,
        temperature: 0.6
      });

      return response.choices[0].message.content;
    } catch (error) {
      return rejectWithValue(error.message);
    }
  }
);

const resumeSlice = createSlice({
  name: 'resume',
  initialState: {
    currentResume: {
      personalInfo: {
        fullName: '',
        email: '',
        phone: '',
        location: '',
        linkedin: '',
        portfolio: ''
      },
      summary: '',
      experience: [],
      education: [],
      skills: [],
      achievements: [],
      certifications: []
    },
    generatedContent: '',
    optimizationSuggestions: '',
    savedResumes: [],
    loading: false,
    error: null
  },
  reducers: {
    updateResumeField: (state, action) => {
      const { section, field, value, index } = action.payload;
      
      if (index !== undefined) {
        if (!state.currentResume[section][index]) {
          state.currentResume[section][index] = {};
        }
        state.currentResume[section][index][field] = value;
      } else if (section === 'personalInfo') {
        state.currentResume.personalInfo[field] = value;
      } else {
        state.currentResume[field] = value;
      }
    },
    addResumeSection: (state, action) => {
      const { section, item } = action.payload;
      state.currentResume[section].push(item);
    },
    removeResumeSection: (state, action) => {
      const { section, index } = action.payload;
      state.currentResume[section].splice(index, 1);
    },
    saveResume: (state, action) => {
      const resume = {
        id: Date.now(),
        name: action.payload.name || 'Untitled Resume',
        data: { ...state.currentResume },
        generatedContent: state.generatedContent,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      state.savedResumes.push(resume);
    },
    loadResume: (state, action) => {
      const resume = state.savedResumes.find(r => r.id === action.payload);
      if (resume) {
        state.currentResume = { ...resume.data };
        state.generatedContent = resume.generatedContent || '';
      }
    },
    deleteResume: (state, action) => {
      state.savedResumes = state.savedResumes.filter(r => r.id !== action.payload);
    },
    clearResume: (state) => {
      state.currentResume = {
        personalInfo: {
          fullName: '',
          email: '',
          phone: '',
          location: '',
          linkedin: '',
          portfolio: ''
        },
        summary: '',
        experience: [],
        education: [],
        skills: [],
        achievements: [],
        certifications: []
      };
      state.generatedContent = '';
      state.optimizationSuggestions = '';
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(generateResumeContent.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(generateResumeContent.fulfilled, (state, action) => {
        state.loading = false;
        state.generatedContent = action.payload;
      })
      .addCase(generateResumeContent.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(optimizeResume.fulfilled, (state, action) => {
        state.optimizationSuggestions = action.payload;
      });
  }
});

export const {
  updateResumeField,
  addResumeSection,
  removeResumeSection,
  saveResume,
  loadResume,
  deleteResume,
  clearResume
} = resumeSlice.actions;

export default resumeSlice.reducer;