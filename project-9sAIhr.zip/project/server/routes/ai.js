import express from 'express';
import {
  parseResume,
  analyzeJobDescription,
  matchCandidates,
  generateOfferLetter,
  getScreeningRecommendations
} from '../controllers/aiController.js';
import { authenticate } from '../middleware/auth.js';
import { uploadResume, handleUploadError } from '../middleware/upload.js';
import { aiLimiter } from '../middleware/rateLimiter.js';

const router = express.Router();

// All routes require authentication and have AI rate limiting
router.use(authenticate);
router.use(aiLimiter);

// AI-powered features
router.post('/parse-resume', uploadResume, handleUploadError, parseResume);
router.post('/analyze-jd', analyzeJobDescription);
router.post('/match-candidates/:jobId', matchCandidates);
router.post('/generate-offer', generateOfferLetter);
router.get('/screening-recommendations/:candidateId/:jobId', getScreeningRecommendations);

export default router;