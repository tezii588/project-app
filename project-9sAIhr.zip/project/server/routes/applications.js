import express from 'express';
import {
  createApplication,
  getApplicationById,
  updateApplicationStatus,
  updateMatchScore,
  getApplicationStats,
  getRecentActivity
} from '../controllers/applicationController.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Application operations
router.post('/', createApplication);
router.get('/stats', getApplicationStats);
router.get('/activity', getRecentActivity);
router.get('/:id', getApplicationById);
router.put('/:id/status', updateApplicationStatus);
router.put('/:id/match-score', updateMatchScore);

export default router;