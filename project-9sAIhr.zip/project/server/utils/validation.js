import Joi from 'joi';

export const validateSignup = (data) => {
  const schema = Joi.object({
    firstName: Joi.string().min(2).max(50).required(),
    lastName: Joi.string().min(2).max(50).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(8).required(),
    company: Joi.string().max(100).optional(),
    role: Joi.string().valid('recruiter', 'admin').default('recruiter')
  });

  return schema.validate(data);
};

export const validateLogin = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required()
  });

  return schema.validate(data);
};

export const validateJob = (data) => {
  const schema = Joi.object({
    title: Joi.string().min(3).max(200).required(),
    description: Joi.string().min(50).required(),
    department: Joi.string().max(100).required(),
    location: Joi.string().max(100).required(),
    type: Joi.string().valid('full-time', 'part-time', 'contract', 'freelance').required(),
    remote: Joi.string().valid('onsite', 'remote', 'hybrid').required(),
    experience: Joi.string().valid('entry-level', 'mid-level', 'senior-level', 'executive').required(),
    salary: Joi.string().max(100).optional(),
    requirements: Joi.array().items(Joi.string()).optional(),
    benefits: Joi.array().items(Joi.string()).optional()
  });

  return schema.validate(data);
};

export const validateCandidate = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(100).required(),
    email: Joi.string().email().required(),
    phone: Joi.string().max(20).optional(),
    location: Joi.string().max(100).optional(),
    position: Joi.string().max(100).optional(),
    experience: Joi.string().max(50).optional(),
    education: Joi.string().max(200).optional(),
    skills: Joi.array().items(Joi.string()).optional(),
    summary: Joi.string().max(1000).optional(),
    resumeUrl: Joi.string().uri().optional(),
    portfolioUrl: Joi.string().uri().optional(),
    linkedinUrl: Joi.string().uri().optional(),
    githubUrl: Joi.string().uri().optional(),
    expectedSalary: Joi.string().max(100).optional()
  });

  return schema.validate(data);
};

export const validateApplication = (data) => {
  const schema = Joi.object({
    candidateId: Joi.number().integer().positive().required(),
    jobId: Joi.number().integer().positive().required(),
    coverLetter: Joi.string().max(2000).optional(),
    matchScore: Joi.number().min(0).max(100).optional()
  });

  return schema.validate(data);
};