import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Users,
  Briefcase,
  Calendar,
  DollarSign,
  Clock,
  Target,
  Award,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import DashboardLayout from '../components/DashboardLayout';
import StatCard from '../components/StatCard';

const AnalyticsPage = () => {
  const [timeRange, setTimeRange] = useState('6months');
  const [isLoading, setIsLoading] = useState(false);

  // Mock data
  const applicationTrendData = [
    { month: 'Jan', applications: 450, interviews: 89, hires: 12 },
    { month: 'Feb', applications: 380, interviews: 76, hires: 8 },
    { month: 'Mar', applications: 520, interviews: 104, hires: 15 },
    { month: 'Apr', applications: 490, interviews: 98, hires: 14 },
    { month: 'May', applications: 610, interviews: 122, hires: 18 },
    { month: 'Jun', applications: 580, interviews: 116, hires: 20 }
  ];

  const departmentData = [
    { name: 'Engineering', applications: 856, hires: 45, color: '#3B82F6' },
    { name: 'Sales', applications: 432, hires: 28, color: '#10B981' },
    { name: 'Marketing', applications: 298, hires: 16, color: '#F59E0B' },
    { name: 'Design', applications: 234, hires: 12, color: '#8B5CF6' },
    { name: 'Operations', applications: 156, hires: 8, color: '#EF4444' }
  ];

  const sourceData = [
    { name: 'Job Boards', value: 35, color: '#3B82F6' },
    { name: 'LinkedIn', value: 28, color: '#0077B5' },
    { name: 'Referrals', value: 20, color: '#10B981' },
    { name: 'Company Website', value: 12, color: '#F59E0B' },
    { name: 'Other', value: 5, color: '#6B7280' }
  ];

  const timeToHireData = [
    { department: 'Engineering', avgDays: 32 },
    { department: 'Sales', avgDays: 28 },
    { department: 'Marketing', avgDays: 25 },
    { department: 'Design', avgDays: 30 },
    { department: 'Operations', avgDays: 22 }
  ];

  const stats = [
    {
      title: 'Total Applications',
      value: '2,456',
      icon: Users,
      color: 'blue',
      change: '+23%',
      trend: 'up'
    },
    {
      title: 'Active Jobs',
      value: '34',
      icon: Briefcase,
      color: 'teal',
      change: '+12%',
      trend: 'up'
    },
    {
      title: 'Interviews Scheduled',
      value: '128',
      icon: Calendar,
      color: 'purple',
      change: '+8%',
      trend: 'up'
    },
    {
      title: 'Hires This Month',
      value: '18',
      icon: Award,
      color: 'green',
      change: '+35%',
      trend: 'up'
    }
  ];

  const kpiCards = [
    { title: 'Time to Hire', value: '28 days', change: '-5 days', trend: 'up', color: 'blue' },
    { title: 'Cost per Hire', value: '$3,200', change: '-$400', trend: 'up', color: 'green' },
    { title: 'Application Rate', value: '15.2%', change: '+2.1%', trend: 'up', color: 'purple' },
    { title: 'Offer Acceptance', value: '85%', change: '+5%', trend: 'up', color: 'orange' }
  ];

  const refreshData = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Analytics</h1>
            <p className="text-gray-600 mt-2">Track your recruitment performance and metrics</p>
          </div>
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="1month">Last Month</option>
              <option value="3months">Last 3 Months</option>
              <option value="6months">Last 6 Months</option>
              <option value="1year">Last Year</option>
            </select>
            <button
              onClick={refreshData}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            <button className="border border-gray-300 hover:border-gray-400 text-gray-700 px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center">
              <Download className="h-4 w-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {/* Key Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <StatCard key={stat.title} stat={stat} index={index} />
          ))}
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpiCards.map((kpi, index) => (
            <motion.div
              key={kpi.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{kpi.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{kpi.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-medium text-green-600 ml-1">{kpi.change}</span>
                    <span className="text-sm text-gray-600 ml-1">vs last period</span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-${kpi.color}-50 flex items-center justify-center`}>
                  <Target className={`h-6 w-6 text-${kpi.color}-600`} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Application Trends */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Application Trends</h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={applicationTrendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="applications" 
                  stackId="1"
                  stroke="#3B82F6" 
                  fill="#3B82F6"
                  fillOpacity={0.6}
                  name="Applications"
                />
                <Area 
                  type="monotone" 
                  dataKey="interviews" 
                  stackId="2"
                  stroke="#10B981" 
                  fill="#10B981"
                  fillOpacity={0.6}
                  name="Interviews"
                />
                <Area 
                  type="monotone" 
                  dataKey="hires" 
                  stackId="3"
                  stroke="#F59E0B" 
                  fill="#F59E0B"
                  fillOpacity={0.6}
                  name="Hires"
                />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Application Sources */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Application Sources</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sourceData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {sourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Department Performance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Department Performance</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={departmentData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={80} />
                <Tooltip />
                <Legend />
                <Bar dataKey="applications" fill="#3B82F6" name="Applications" />
                <Bar dataKey="hires" fill="#10B981" name="Hires" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Time to Hire */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Average Time to Hire</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={timeToHireData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="department" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value} days`, 'Time to Hire']} />
                <Bar 
                  dataKey="avgDays" 
                  fill="#8B5CF6"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Performance Metrics Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden"
        >
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Department Metrics</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Department
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Applications
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Interviews
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Hires
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Conversion Rate
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg. Time to Hire
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {departmentData.map((dept, index) => {
                  const conversionRate = ((dept.hires / dept.applications) * 100).toFixed(1);
                  const timeToHire = timeToHireData.find(t => t.department === dept.name)?.avgDays || 0;
                  
                  return (
                    <tr key={dept.name} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className={`w-3 h-3 rounded-full mr-3`} style={{ backgroundColor: dept.color }}></div>
                          <span className="text-sm font-medium text-gray-900">{dept.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {dept.applications.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {Math.floor(dept.applications * 0.2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {dept.hires}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {conversionRate}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {timeToHire} days
                      </td>
                    </tr>
                  );
                })}
              
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
};

export default AnalyticsPage;