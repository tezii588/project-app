import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Download,
  Star,
  Award,
  GraduationCap,
  Briefcase,
  User,
  MessageSquare,
  Clock,
  CheckCircle,
  XCircle,
  FileText,
  Linkedin,
  Github,
  Globe
} from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout';

const CandidateProfile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // Mock candidate data - in real app, fetch from API
  const candidate = {
    id: 1,
    name: 'John Smith',
    email: 'john.smith@email.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
    position: 'Senior React Developer',
    currentCompany: 'TechCorp Inc.',
    experience: '5 years',
    education: 'BS Computer Science - Stanford University',
    skills: ['React', 'TypeScript', 'Node.js', 'AWS', 'Docker', 'GraphQL', 'MongoDB', 'Jest'],
    matchScore: 95,
    status: 'screening',
    appliedDate: '2024-01-15',
    expectedSalary: '$120,000 - $140,000',
    resumeUrl: '/resumes/john-smith.pdf',
    portfolioUrl: 'https://johnsmith.dev',
    linkedinUrl: 'https://linkedin.com/in/johnsmith',
    githubUrl: 'https://github.com/johnsmith',
    summary: 'Experienced full-stack developer with expertise in React and Node.js. Led multiple successful projects and mentored junior developers. Passionate about creating scalable web applications and contributing to open-source projects.',
    workExperience: [
      {
        company: 'TechCorp Inc.',
        position: 'Senior Frontend Developer',
        duration: '2022 - Present',
        description: 'Led development of customer-facing web applications using React and TypeScript. Mentored 3 junior developers and implemented CI/CD pipelines.',
        achievements: ['Increased page load speed by 40%', 'Led team of 5 developers', 'Implemented design system']
      },
      {
        company: 'StartupXYZ',
        position: 'Full Stack Developer',
        duration: '2020 - 2022',
        description: 'Developed and maintained web applications using React, Node.js, and MongoDB. Collaborated with designers and product managers.',
        achievements: ['Built 3 major features', 'Reduced API response time by 30%', 'Implemented authentication system']
      }
    ],
    education: [
      {
        institution: 'Stanford University',
        degree: 'Bachelor of Science in Computer Science',
        duration: '2016 - 2020',
        gpa: '3.8/4.0'
      }
    ],
    projects: [
      {
        name: 'E-commerce Platform',
        description: 'Built a full-stack e-commerce platform with React, Node.js, and Stripe integration',
        technologies: ['React', 'Node.js', 'MongoDB', 'Stripe'],
        url: 'https://github.com/johnsmith/ecommerce'
      },
      {
        name: 'Task Management App',
        description: 'Developed a collaborative task management application with real-time updates',
        technologies: ['React', 'Socket.io', 'Express'],
        url: 'https://github.com/johnsmith/taskapp'
      }
    ],
    notes: [
      {
        id: 1,
        author: 'Sarah Wilson',
        date: '2024-01-16',
        content: 'Great technical skills, very articulate in explaining complex concepts.'
      },
      {
        id: 2,
        author: 'Mike Johnson',
        date: '2024-01-15',
        content: 'Strong portfolio and GitHub activity. Impressed with the open-source contributions.'
      }
    ]
  };

  const [activeTab, setActiveTab] = useState('overview');
  const [newNote, setNewNote] = useState('');
  const [showAddNote, setShowAddNote] = useState(false);

  const getStatusColor = (status) => {
    switch (status) {
      case 'new':
        return 'bg-blue-100 text-blue-800';
      case 'screening':
        return 'bg-yellow-100 text-yellow-800';
      case 'interview':
        return 'bg-purple-100 text-purple-800';
      case 'offer':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getMatchScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-yellow-600';
    if (score >= 70) return 'text-orange-600';
    return 'text-red-600';
  };

  const handleStatusChange = (newStatus) => {
    // Update candidate status
    console.log('Updating status to:', newStatus);
  };

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    
    // Add note logic here
    console.log('Adding note:', newNote);
    setNewNote('');
    setShowAddNote(false);
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: User },
    { id: 'experience', label: 'Experience', icon: Briefcase },
    { id: 'projects', label: 'Projects', icon: FileText },
    { id: 'notes', label: 'Notes', icon: MessageSquare }
  ];

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/candidates')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Candidate Profile</h1>
            <p className="text-gray-600 mt-2">Detailed view of candidate information and history</p>
          </div>
        </div>

        {/* Candidate Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex items-start space-x-6">
              <img
                src={candidate.avatar}
                alt={candidate.name}
                className="w-24 h-24 rounded-2xl object-cover"
              />
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <h2 className="text-2xl font-bold text-gray-900">{candidate.name}</h2>
                  <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(candidate.status)}`}>
                    {candidate.status}
                  </span>
                </div>
                <p className="text-lg text-gray-700 mb-3">{candidate.position}</p>
                <div className="flex items-center space-x-4 text-gray-600">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="text-sm">{candidate.location}</span>
                  </div>
                  <div className="flex items-center">
                    <Briefcase className="h-4 w-4 mr-1" />
                    <span className="text-sm">{candidate.experience} experience</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                    <span className={`text-sm font-semibold ${getMatchScoreColor(candidate.matchScore)}`}>
                      {candidate.matchScore}% match
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col space-y-3 mt-6 md:mt-0">
              <div className="flex items-center space-x-2">
                <a
                  href={`mailto:${candidate.email}`}
                  className="bg-blue-50 hover:bg-blue-100 text-blue-600 p-3 rounded-lg transition-colors duration-200"
                  title="Send Email"
                >
                  <Mail className="h-5 w-5" />
                </a>
                <a
                  href={`tel:${candidate.phone}`}
                  className="bg-green-50 hover:bg-green-100 text-green-600 p-3 rounded-lg transition-colors duration-200"
                  title="Call"
                >
                  <Phone className="h-5 w-5" />
                </a>
                <a
                  href={candidate.resumeUrl}
                  download
                  className="bg-gray-50 hover:bg-gray-100 text-gray-600 p-3 rounded-lg transition-colors duration-200"
                  title="Download Resume"
                >
                  <Download className="h-5 w-5" />
                </a>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleStatusChange('interview')}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200"
                >
                  Schedule Interview
                </button>
                <button
                  onClick={() => handleStatusChange('offer')}
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200"
                >
                  Send Offer
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {activeTab === 'overview' && (
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Main Info */}
              <div className="lg:col-span-2 space-y-6">
                {/* Summary */}
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Summary</h3>
                  <p className="text-gray-700 leading-relaxed">{candidate.summary}</p>
                </div>

                {/* Skills */}
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {candidate.skills.map((skill, idx) => (
                      <span key={idx} className="px-3 py-2 bg-blue-50 text-blue-700 rounded-lg font-medium">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Side Info */}
              <div className="space-y-6">
                {/* Contact Info */}
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{candidate.email}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{candidate.phone}</span>
                    </div>
                    {candidate.linkedinUrl && (
                      <div className="flex items-center space-x-3">
                        <Linkedin className="h-4 w-4 text-gray-400" />
                        <a href={candidate.linkedinUrl} className="text-sm text-blue-600 hover:text-blue-700">
                          LinkedIn Profile
                        </a>
                      </div>
                    )}
                    {candidate.githubUrl && (
                      <div className="flex items-center space-x-3">
                        <Github className="h-4 w-4 text-gray-400" />
                        <a href={candidate.githubUrl} className="text-sm text-blue-600 hover:text-blue-700">
                          GitHub Profile
                        </a>
                      </div>
                    )}
                    {candidate.portfolioUrl && (
                      <div className="flex items-center space-x-3">
                        <Globe className="h-4 w-4 text-gray-400" />
                        <a href={candidate.portfolioUrl} className="text-sm text-blue-600 hover:text-blue-700">
                          Portfolio
                        </a>
                      </div>
                    )}
                  </div>
                </div>

                {/* Application Details */}
                <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Application Details</h3>
                  <div className="space-y-3">
                    <div>
                      <span className="text-sm text-gray-500">Applied Date</span>
                      <p className="font-medium text-gray-900">{new Date(candidate.appliedDate).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Expected Salary</span>
                      <p className="font-medium text-gray-900">{candidate.expectedSalary}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Current Company</span>
                      <p className="font-medium text-gray-900">{candidate.currentCompany}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'experience' && (
            <div className="space-y-8">
              {/* Work Experience */}
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Work Experience</h3>
                <div className="space-y-6">
                  {candidate.workExperience.map((job, idx) => (
                    <div key={idx} className="border-l-2 border-blue-200 pl-6 pb-6">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="text-lg font-semibold text-gray-900">{job.position}</h4>
                          <p className="text-blue-600 font-medium">{job.company}</p>
                        </div>
                        <span className="text-sm text-gray-500">{job.duration}</span>
                      </div>
                      <p className="text-gray-700 mb-3">{job.description}</p>
                      <div className="space-y-1">
                        <p className="text-sm font-medium text-gray-900">Key Achievements:</p>
                        <ul className="list-disc list-inside space-y-1">
                          {job.achievements.map((achievement, aidx) => (
                            <li key={aidx} className="text-sm text-gray-700">{achievement}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Education */}
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Education</h3>
                <div className="space-y-4">
                  {candidate.education.map((edu, idx) => (
                    <div key={idx} className="border-l-2 border-green-200 pl-6">
                      <h4 className="text-lg font-semibold text-gray-900">{edu.degree}</h4>
                      <p className="text-green-600 font-medium">{edu.institution}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-sm text-gray-500">{edu.duration}</span>
                        {edu.gpa && (
                          <span className="text-sm text-gray-700">GPA: {edu.gpa}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'projects' && (
            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">Projects</h3>
              <div className="grid md:grid-cols-2 gap-6">
                {candidate.projects.map((project, idx) => (
                  <div key={idx} className="p-4 border border-gray-200 rounded-lg">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">{project.name}</h4>
                    <p className="text-gray-700 mb-3">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {project.technologies.map((tech, tidx) => (
                        <span key={tidx} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                          {tech}
                        </span>
                      ))}
                    </div>
                    {project.url && (
                      <a
                        href={project.url}
                        className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        View Project →
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Notes</h3>
                <button
                  onClick={() => setShowAddNote(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200"
                >
                  Add Note
                </button>
              </div>

              {showAddNote && (
                <div className="mb-6 p-4 border border-gray-200 rounded-lg">
                  <textarea
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Add your note here..."
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                    rows={3}
                  />
                  <div className="flex items-center space-x-2 mt-3">
                    <button
                      onClick={handleAddNote}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200"
                    >
                      Save Note
                    </button>
                    <button
                      onClick={() => setShowAddNote(false)}
                      className="border border-gray-300 hover:border-gray-400 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {candidate.notes.map((note) => (
                  <div key={note.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-900">{note.author}</span>
                      <span className="text-sm text-gray-500">
                        {new Date(note.date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-gray-700">{note.content}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </DashboardLayout>
  );
};

export default CandidateProfile;