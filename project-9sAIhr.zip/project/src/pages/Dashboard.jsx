import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Briefcase, 
  UserCheck, 
  Calendar,
  TrendingUp,
  Clock,
  Star,
  ArrowUp,
  Plus,
  Filter,
  Search
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

import DashboardLayout from '../components/DashboardLayout';
import StatCard from '../components/StatCard';
import RecentActivity from '../components/RecentActivity';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalJobs: 45,
    totalCandidates: 1234,
    activeJobs: 12,
    scheduledInterviews: 8
  });

  const chartData = [
    { name: 'Jan', applications: 400, hired: 24 },
    { name: 'Feb', applications: 300, hired: 13 },
    { name: 'Mar', applications: 500, hired: 32 },
    { name: 'Apr', applications: 280, hired: 18 },
    { name: 'May', applications: 390, hired: 29 },
    { name: 'Jun', applications: 450, hired: 35 }
  ];

  const pieData = [
    { name: 'Applied', value: 45, color: '#3B82F6' },
    { name: 'Screening', value: 25, color: '#14B8A6' },
    { name: 'Interview', value: 20, color: '#F59E0B' },
    { name: 'Offer', value: 10, color: '#10B981' }
  ];

  const topJobs = [
    { id: 1, title: 'Senior React Developer', applications: 45, status: 'active', location: 'Remote' },
    { id: 2, title: 'Product Manager', applications: 32, status: 'active', location: 'New York' },
    { id: 3, title: 'UX Designer', applications: 28, status: 'paused', location: 'San Francisco' },
    { id: 4, title: 'DevOps Engineer', applications: 19, status: 'active', location: 'Austin' }
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'application',
      message: 'New application for Senior React Developer',
      time: '5 minutes ago',
      candidate: 'John Smith'
    },
    {
      id: 2,
      type: 'interview',
      message: 'Interview scheduled with Sarah Johnson',
      time: '1 hour ago',
      candidate: 'Sarah Johnson'
    },
    {
      id: 3,
      type: 'offer',
      message: 'Offer letter sent to Michael Chen',
      time: '2 hours ago',
      candidate: 'Michael Chen'
    },
    {
      id: 4,
      type: 'hire',
      message: 'Emily Rodriguez accepted job offer',
      time: '1 day ago',
      candidate: 'Emily Rodriguez'
    }
  ];

  const statCards = [
    {
      title: 'Total Jobs',
      value: stats.totalJobs,
      icon: Briefcase,
      color: 'blue',
      change: '+12%',
      trend: 'up'
    },
    {
      title: 'Total Candidates',
      value: stats.totalCandidates.toLocaleString(),
      icon: Users,
      color: 'teal',
      change: '+18%',
      trend: 'up'
    },
    {
      title: 'Active Jobs',
      value: stats.activeJobs,
      icon: UserCheck,
      color: 'green',
      change: '+5%',
      trend: 'up'
    },
    {
      title: 'Interviews',
      value: stats.scheduledInterviews,
      icon: Calendar,
      color: 'purple',
      change: '+3%',
      trend: 'up'
    }
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">Welcome back! Here's what's happening with your recruitment.</p>
          </div>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Link
              to="/post-job"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center"
            >
              <Plus className="h-4 w-4 mr-2" />
              Post Job
            </Link>
            <button className="border border-gray-300 hover:border-blue-500 text-gray-700 px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statCards.map((stat, index) => (
            <StatCard key={stat.title} stat={stat} index={index} />
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Applications Trend */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Applications & Hires Trend</h3>
              <div className="flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4 mr-1" />
                <span>+15% this month</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="applications" 
                  stroke="#3B82F6" 
                  strokeWidth={3}
                  dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                  name="Applications"
                />
                <Line 
                  type="monotone" 
                  dataKey="hired" 
                  stroke="#14B8A6" 
                  strokeWidth={3}
                  dot={{ fill: '#14B8A6', strokeWidth: 2, r: 4 }}
                  name="Hired"
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Pipeline Status */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Pipeline Status</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Top Performing Jobs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Top Performing Jobs</h3>
              <Link to="/jobs" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                View All
              </Link>
            </div>
            <div className="space-y-4">
              {topJobs.map((job, index) => (
                <div key={job.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{job.title}</h4>
                    <div className="flex items-center mt-1 space-x-3">
                      <span className="text-sm text-gray-600">{job.applications} applications</span>
                      <span className="text-sm text-gray-500">• {job.location}</span>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        job.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {job.status}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="ml-1 text-sm font-medium text-gray-700">
                      {(4.2 + Math.random() * 0.8).toFixed(1)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
              <Link to="/analytics" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                View All
              </Link>
            </div>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <RecentActivity key={activity.id} activity={activity} />
              ))}
            </div>
          </motion.div>
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="bg-gradient-to-r from-blue-600 to-teal-600 p-6 rounded-2xl text-white"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h3 className="text-xl font-semibold mb-2">Ready to find your next hire?</h3>
              <p className="text-blue-100">Use our AI-powered matching to find the perfect candidates for your open positions.</p>
            </div>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link
                to="/candidates"
                className="bg-white text-blue-600 hover:bg-gray-100 px-6 py-3 rounded-lg font-medium transition-colors duration-200"
              >
                Browse Candidates
              </Link>
              <Link
                to="/post-job"
                className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-6 py-3 rounded-lg font-medium transition-colors duration-200"
              >
                Post New Job
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;