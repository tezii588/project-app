# AI4Hr - AI-Powered Recruitment Platform

A comprehensive recruitment platform that leverages artificial intelligence to streamline the hiring process, from job posting to candidate selection and offer generation.

## 🚀 Features

### Core Functionality
- **Job Management**: Create, edit, and manage job postings with AI-enhanced descriptions
- **Candidate Management**: Comprehensive candidate profiles with skills tracking
- **AI Resume Parsing**: Automatically extract structured data from PDF resumes
- **Smart Matching**: AI-powered candidate-job matching with confidence scores
- **Application Tracking**: Full application lifecycle management
- **Interview Scheduling**: Automated interview scheduling and management
- **Offer Generation**: AI-powered offer letter creation

### AI-Powered Features
- **Resume Parser**: Extract education, skills, and experience from resumes
- **Job Description Analyzer**: Understand job requirements and suggest improvements
- **Candidate Matching**: Rank candidates by fit score using advanced algorithms
- **Screening Recommendations**: AI-generated interview questions and hiring recommendations
- **Automated Workflows**: Streamline repetitive tasks with intelligent automation

### Analytics & Reporting
- **Real-time Dashboard**: Track key recruitment metrics
- **Performance Analytics**: Monitor hiring funnel and conversion rates
- **Department Insights**: Analyze performance by department and role
- **Time-to-Hire Tracking**: Optimize recruitment timelines

### User Management
- **Role-based Access**: Recruiter and Admin roles with appropriate permissions
- **Team Collaboration**: Share candidates and collaborate on hiring decisions
- **Activity Logging**: Track all user actions for audit purposes

## 🛠 Tech Stack

### Frontend
- **React 18** with modern hooks and functional components
- **Tailwind CSS** for responsive, utility-first styling
- **Framer Motion** for smooth animations and transitions
- **React Router** for client-side routing
- **React Hook Form** for form management
- **Recharts** for data visualization
- **Lucide React** for consistent iconography

### Backend
- **Node.js** with Express.js framework
- **PostgreSQL** for robust data storage
- **JWT** for secure authentication
- **OpenAI API** for AI-powered features
- **Multer** for file upload handling
- **Joi** for data validation
- **bcryptjs** for password hashing

### DevOps & Deployment
- **Docker** with multi-container setup
- **Nginx** as reverse proxy and load balancer
- **Redis** for caching and session management
- **Rate limiting** for API protection
- **Health checks** for monitoring

## 📋 Prerequisites

- Node.js 18+ and npm
- PostgreSQL 15+
- OpenAI API key
- Docker and Docker Compose (for containerized deployment)

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/ai4hr-platform.git
cd ai4hr-platform
```

### 2. Environment Setup

#### Frontend Environment
Create `.env` in the root directory:
```env
VITE_API_URL=http://localhost:5000/api
```

#### Backend Environment
Create `server/.env`:
```env
# Database Configuration
DB_HOST=156.67.104.162
DB_PORT=5432
DB_NAME=ai4hrdb
DB_USER=hradmin
DB_PASSWORD=sysivwelcome@321

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-here
JWT_EXPIRES_IN=7d

# OpenAI Configuration
OPENAI_API_KEY=your-openai-api-key-here

# Server Configuration
PORT=5000
NODE_ENV=development
```

### 3. Database Setup
```bash
# Connect to PostgreSQL and run the initialization script
psql -h 156.67.104.162 -U hradmin -d ai4hrdb -f database/init.sql
```

### 4. Install Dependencies

#### Frontend
```bash
npm install
```

#### Backend
```bash
cd server
npm install
cd ..
```

### 5. Start Development Servers

#### Start Backend
```bash
cd server
npm run dev
```

#### Start Frontend (in a new terminal)
```bash
npm run dev
```

The application will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- Health Check: http://localhost:5000/health

## 🐳 Docker Deployment

### Development with Docker
```bash
# Build and start all services
docker-compose up --build

# Run in background
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Production Deployment
```bash
# Build for production
docker-compose -f docker-compose.prod.yml up --build -d

# Scale services
docker-compose -f docker-compose.prod.yml up --scale backend=3 -d
```

## 📚 API Documentation

### Authentication Endpoints
- `POST /api/auth/signup` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile

### Job Management
- `GET /api/jobs` - List all jobs
- `POST /api/jobs` - Create new job
- `GET /api/jobs/:id` - Get job details
- `PUT /api/jobs/:id` - Update job
- `DELETE /api/jobs/:id` - Delete job
- `GET /api/jobs/:id/applications` - Get job applications

### Candidate Management
- `GET /api/candidates` - List all candidates
- `POST /api/candidates` - Create new candidate
- `GET /api/candidates/:id` - Get candidate details
- `PUT /api/candidates/:id` - Update candidate
- `DELETE /api/candidates/:id` - Delete candidate

### AI Features
- `POST /api/ai/parse-resume` - Parse resume PDF
- `POST /api/ai/analyze-jd` - Analyze job description
- `POST /api/ai/match-candidates/:jobId` - Match candidates to job
- `POST /api/ai/generate-offer` - Generate offer letter
- `GET /api/ai/screening-recommendations/:candidateId/:jobId` - Get screening recommendations

### Application Management
- `GET /api/applications` - List applications
- `POST /api/applications` - Create application
- `PUT /api/applications/:id/status` - Update application status
- `GET /api/applications/stats` - Get application statistics

## 🧪 Testing

### Backend Tests
```bash
cd server
npm test
```

### Frontend Tests
```bash
npm test
```

### Run All Tests
```bash
npm run test:all
```

## 🔒 Security Features

- **JWT Authentication** with secure token handling
- **Rate Limiting** to prevent API abuse
- **Input Validation** using Joi schemas
- **SQL Injection Protection** with parameterized queries
- **CORS Configuration** for cross-origin security
- **Helmet.js** for security headers
- **Password Hashing** with bcrypt
- **File Upload Validation** with type and size limits

## 📊 Performance Optimizations

- **Database Indexing** for fast queries
- **Connection Pooling** for database efficiency
- **Compression** for reduced payload sizes
- **Caching** with Redis for frequently accessed data
- **Lazy Loading** for improved frontend performance
- **Code Splitting** for optimized bundle sizes

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Email: support@ai4hr.com
- Documentation: [docs.ai4hr.com](https://docs.ai4hr.com)

## 🗺 Roadmap

### Phase 1 (Current)
- ✅ Core recruitment workflow
- ✅ AI resume parsing
- ✅ Candidate matching
- ✅ Basic analytics

### Phase 2 (Next)
- 🔄 Advanced AI features
- 🔄 Video interview integration
- 🔄 Mobile application
- 🔄 Advanced reporting

### Phase 3 (Future)
- 📋 Machine learning model training
- 📋 Predictive analytics
- 📋 Integration marketplace
- 📋 White-label solutions

---

Built with ❤️ by the AI4Hr team