import Candidate from '../models/Candidate.js';
import Application from '../models/Application.js';
import { validateCandidate } from '../utils/validation.js';

export const createCandidate = async (req, res) => {
  try {
    const { error } = validateCandidate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    // Check if candidate already exists
    const existingCandidate = await Candidate.findByEmail(req.body.email);
    if (existingCandidate) {
      return res.status(400).json({
        success: false,
        message: 'Candidate with this email already exists'
      });
    }

    const candidate = await Candidate.create(req.body);

    res.status(201).json({
      success: true,
      message: 'Candidate created successfully',
      candidate
    });
  } catch (error) {
    console.error('Create candidate error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getCandidates = async (req, res) => {
  try {
    const filters = {};
    
    if (req.query.search) filters.search = req.query.search;
    if (req.query.location) filters.location = req.query.location;
    if (req.query.experience) filters.experience = req.query.experience;

    const candidates = await Candidate.getAll(filters);

    res.json({
      success: true,
      candidates
    });
  } catch (error) {
    console.error('Get candidates error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getCandidateById = async (req, res) => {
  try {
    const { id } = req.params;
    const candidate = await Candidate.findById(id);

    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }

    // Get candidate's applications
    const applications = await Application.getByCandidateId(id);

    res.json({
      success: true,
      candidate: {
        ...candidate,
        applications
      }
    });
  } catch (error) {
    console.error('Get candidate by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const updateCandidate = async (req, res) => {
  try {
    const { id } = req.params;
    
    const existingCandidate = await Candidate.findById(id);
    if (!existingCandidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }

    const allowedFields = [
      'name', 'phone', 'location', 'position', 'experience', 'education',
      'skills', 'summary', 'portfolio_url', 'linkedin_url', 'github_url',
      'expected_salary'
    ];

    const updateData = {};
    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) {
        updateData[field] = req.body[field];
      }
    });

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    const updatedCandidate = await Candidate.update(id, updateData);

    res.json({
      success: true,
      message: 'Candidate updated successfully',
      candidate: updatedCandidate
    });
  } catch (error) {
    console.error('Update candidate error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const deleteCandidate = async (req, res) => {
  try {
    const { id } = req.params;
    
    const existingCandidate = await Candidate.findById(id);
    if (!existingCandidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }

    await Candidate.delete(id);

    res.json({
      success: true,
      message: 'Candidate deleted successfully'
    });
  } catch (error) {
    console.error('Delete candidate error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getCandidateStats = async (req, res) => {
  try {
    const stats = await Candidate.getStats();

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get candidate stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};