-- AI4Hr Database Schema
-- PostgreSQL Database Initialization Script

-- Create database (run this separately if needed)
-- CREATE DATABASE ai4hrdb;

-- Connect to the database
\c ai4hrdb;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    company VARCHAR(100),
    role VARCHAR(20) DEFAULT 'recruiter' CHECK (role IN ('recruiter', 'admin')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login TIMESTAMP WITH TIME ZONE
);

-- Jobs table
CREATE TABLE IF NOT EXISTS jobs (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    department VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('full-time', 'part-time', 'contract', 'freelance')),
    remote VARCHAR(20) NOT NULL CHECK (remote IN ('onsite', 'remote', 'hybrid')),
    experience VARCHAR(20) NOT NULL CHECK (experience IN ('entry-level', 'mid-level', 'senior-level', 'executive')),
    salary VARCHAR(100),
    requirements JSONB DEFAULT '[]',
    benefits JSONB DEFAULT '[]',
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'paused', 'closed')),
    recruiter_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Candidates table
CREATE TABLE IF NOT EXISTS candidates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    location VARCHAR(100),
    position VARCHAR(100),
    experience VARCHAR(50),
    education VARCHAR(200),
    skills JSONB DEFAULT '[]',
    summary TEXT,
    resume_url VARCHAR(500),
    portfolio_url VARCHAR(500),
    linkedin_url VARCHAR(500),
    github_url VARCHAR(500),
    expected_salary VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Applications table
CREATE TABLE IF NOT EXISTS applications (
    id SERIAL PRIMARY KEY,
    candidate_id INTEGER REFERENCES candidates(id) ON DELETE CASCADE,
    job_id INTEGER REFERENCES jobs(id) ON DELETE CASCADE,
    cover_letter TEXT,
    match_score DECIMAL(5,2) DEFAULT 0 CHECK (match_score >= 0 AND match_score <= 100),
    status VARCHAR(20) DEFAULT 'new' CHECK (status IN ('new', 'screening', 'interview', 'offer', 'hired', 'rejected')),
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_by INTEGER REFERENCES users(id),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(candidate_id, job_id)
);

-- Interviews table
CREATE TABLE IF NOT EXISTS interviews (
    id SERIAL PRIMARY KEY,
    application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,
    interviewer_id INTEGER REFERENCES users(id),
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
    duration_minutes INTEGER DEFAULT 60,
    type VARCHAR(20) DEFAULT 'video' CHECK (type IN ('phone', 'video', 'in-person')),
    status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'rescheduled')),
    notes TEXT,
    feedback JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Offers table
CREATE TABLE IF NOT EXISTS offers (
    id SERIAL PRIMARY KEY,
    application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,
    salary VARCHAR(100) NOT NULL,
    start_date DATE,
    benefits JSONB DEFAULT '[]',
    terms TEXT,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'withdrawn')),
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    responded_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Notes table for candidate/application notes
CREATE TABLE IF NOT EXISTS notes (
    id SERIAL PRIMARY KEY,
    application_id INTEGER REFERENCES applications(id) ON DELETE CASCADE,
    author_id INTEGER REFERENCES users(id),
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INTEGER,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_jobs_recruiter_id ON jobs(recruiter_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_department ON jobs(department);
CREATE INDEX IF NOT EXISTS idx_jobs_created_at ON jobs(created_at);

CREATE INDEX IF NOT EXISTS idx_candidates_email ON candidates(email);
CREATE INDEX IF NOT EXISTS idx_candidates_created_at ON candidates(created_at);

CREATE INDEX IF NOT EXISTS idx_applications_candidate_id ON applications(candidate_id);
CREATE INDEX IF NOT EXISTS idx_applications_job_id ON applications(job_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_applications_match_score ON applications(match_score);
CREATE INDEX IF NOT EXISTS idx_applications_applied_at ON applications(applied_at);

CREATE INDEX IF NOT EXISTS idx_interviews_application_id ON interviews(application_id);
CREATE INDEX IF NOT EXISTS idx_interviews_scheduled_at ON interviews(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_interviews_status ON interviews(status);

CREATE INDEX IF NOT EXISTS idx_offers_application_id ON offers(application_id);
CREATE INDEX IF NOT EXISTS idx_offers_status ON offers(status);

CREATE INDEX IF NOT EXISTS idx_notes_application_id ON notes(application_id);
CREATE INDEX IF NOT EXISTS idx_notes_created_at ON notes(created_at);

CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs(created_at);

-- Create triggers for updating updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_candidates_updated_at BEFORE UPDATE ON candidates
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON applications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_interviews_updated_at BEFORE UPDATE ON interviews
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_offers_updated_at BEFORE UPDATE ON offers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notes_updated_at BEFORE UPDATE ON notes
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert sample data for development
INSERT INTO users (first_name, last_name, email, password, company, role) VALUES
('Admin', 'User', 'admin@ai4hr.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS', 'AI4Hr Technologies', 'admin'),
('John', 'Smith', 'john.smith@company.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS', 'TechCorp Inc.', 'recruiter'),
('Sarah', 'Johnson', 'sarah.johnson@company.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS', 'StartupXYZ', 'recruiter')
ON CONFLICT (email) DO NOTHING;

-- Note: Password is 'password123' hashed with bcrypt
-- In production, users should change their passwords immediately

-- Insert sample jobs
INSERT INTO jobs (title, description, department, location, type, remote, experience, salary, requirements, benefits, recruiter_id) VALUES
(
    'Senior React Developer',
    'We are looking for a Senior React Developer to join our growing engineering team. You will be responsible for developing and maintaining our web applications using modern React technologies.',
    'Engineering',
    'San Francisco, CA',
    'full-time',
    'hybrid',
    'senior-level',
    '$120,000 - $150,000',
    '["5+ years React experience", "TypeScript", "Node.js", "AWS", "Git"]',
    '["Health Insurance", "401k", "Remote Work", "Stock Options"]',
    2
),
(
    'Product Manager',
    'Lead product strategy and development for our core platform. Work closely with engineering, design, and business teams to deliver exceptional user experiences.',
    'Product',
    'New York, NY',
    'full-time',
    'onsite',
    'mid-level',
    '$130,000 - $160,000',
    '["3+ years PM experience", "Technical background", "Leadership skills", "Data analysis"]',
    '["Health Insurance", "Stock Options", "Flexible PTO", "Learning Budget"]',
    2
),
(
    'UX Designer',
    'Create beautiful and intuitive user experiences for our products. Collaborate with product managers and engineers to design user-centered solutions.',
    'Design',
    'Remote',
    'full-time',
    'remote',
    'mid-level',
    '$100,000 - $130,000',
    '["4+ years UX experience", "Figma/Sketch", "User Research", "Prototyping"]',
    '["Health Insurance", "Design Budget", "Learning Stipend", "Flexible Hours"]',
    3
)
ON CONFLICT DO NOTHING;

-- Insert sample candidates
INSERT INTO candidates (name, email, phone, location, position, experience, education, skills, summary, expected_salary) VALUES
(
    'Alice Johnson',
    'alice.johnson@email.com',
    '+1 (555) 123-4567',
    'San Francisco, CA',
    'Senior Frontend Developer',
    '6 years',
    'BS Computer Science - UC Berkeley',
    '["React", "TypeScript", "JavaScript", "CSS", "HTML", "Node.js", "GraphQL"]',
    'Experienced frontend developer with a passion for creating beautiful and performant web applications. Led multiple successful projects and mentored junior developers.',
    '$125,000 - $145,000'
),
(
    'Bob Chen',
    'bob.chen@email.com',
    '+1 (555) 234-5678',
    'Seattle, WA',
    'Product Manager',
    '4 years',
    'MBA - Stanford University',
    '["Product Strategy", "Data Analysis", "Agile", "Leadership", "SQL", "A/B Testing"]',
    'Strategic product manager with proven track record of launching successful products and driving user growth. Strong analytical and leadership skills.',
    '$135,000 - $155,000'
),
(
    'Carol Davis',
    'carol.davis@email.com',
    '+1 (555) 345-6789',
    'Austin, TX',
    'UX Designer',
    '5 years',
    'BFA Design - Art Institute',
    '["Figma", "Sketch", "User Research", "Prototyping", "Design Systems", "Adobe Creative Suite"]',
    'Creative UX designer passionate about solving complex user problems through thoughtful design. Experience in both B2B and B2C products.',
    '$105,000 - $125,000'
)
ON CONFLICT (email) DO NOTHING;

-- Insert sample applications
INSERT INTO applications (candidate_id, job_id, cover_letter, match_score, status) VALUES
(1, 1, 'I am very excited about this opportunity to join your engineering team...', 92, 'screening'),
(2, 2, 'With my product management experience, I believe I would be a great fit...', 88, 'interview'),
(3, 3, 'I am passionate about creating user-centered designs and would love to contribute...', 85, 'new')
ON CONFLICT (candidate_id, job_id) DO NOTHING;

COMMIT;

-- Display success message
SELECT 'AI4Hr database initialized successfully!' as message;