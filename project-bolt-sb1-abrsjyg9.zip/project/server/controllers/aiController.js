import OpenAI from 'openai';
import pdfParse from 'pdf-parse';
import Job from '../models/Job.js';
import Candidate from '../models/Candidate.js';
import Application from '../models/Application.js';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

export const parseResume = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No resume file uploaded'
      });
    }

    // Parse PDF content
    const pdfData = await pdfParse(req.file.buffer);
    const resumeText = pdfData.text;

    // Use OpenAI to extract structured data
    const prompt = `
      Extract the following information from this resume text and return it as a JSON object:
      - name (full name)
      - email
      - phone
      - location (city, state/country)
      - position (current or desired job title)
      - experience (years of experience as a string like "5 years")
      - education (highest degree and institution)
      - skills (array of technical skills)
      - summary (brief professional summary, 2-3 sentences)

      Resume text:
      ${resumeText}

      Return only valid JSON without any additional text or formatting.
    `;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 1000
    });

    const extractedData = JSON.parse(completion.choices[0].message.content);

    res.json({
      success: true,
      message: 'Resume parsed successfully',
      data: extractedData,
      rawText: resumeText
    });
  } catch (error) {
    console.error('Parse resume error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to parse resume'
    });
  }
};

export const analyzeJobDescription = async (req, res) => {
  try {
    const { jobDescription } = req.body;

    if (!jobDescription) {
      return res.status(400).json({
        success: false,
        message: 'Job description is required'
      });
    }

    const prompt = `
      Analyze this job description and extract the following information as a JSON object:
      - requiredSkills (array of technical skills required)
      - preferredSkills (array of nice-to-have skills)
      - experienceLevel (entry-level, mid-level, senior-level, or executive)
      - department (likely department like Engineering, Marketing, Sales, etc.)
      - keyResponsibilities (array of main job responsibilities)
      - qualifications (array of education/certification requirements)
      - benefits (array of mentioned benefits or perks)

      Job Description:
      ${jobDescription}

      Return only valid JSON without any additional text or formatting.
    `;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 1000
    });

    const analysis = JSON.parse(completion.choices[0].message.content);

    res.json({
      success: true,
      message: 'Job description analyzed successfully',
      analysis
    });
  } catch (error) {
    console.error('Analyze job description error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to analyze job description'
    });
  }
};

export const matchCandidates = async (req, res) => {
  try {
    const { jobId } = req.params;

    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }

    // Get all candidates
    const candidates = await Candidate.getAll();

    // Calculate match scores for each candidate
    const matchedCandidates = [];

    for (const candidate of candidates) {
      try {
        const prompt = `
          Calculate a match score (0-100) between this job and candidate based on:
          - Skills alignment
          - Experience level match
          - Education relevance
          - Location compatibility

          Job Requirements:
          Title: ${job.title}
          Department: ${job.department}
          Required Skills: ${JSON.stringify(job.requirements)}
          Experience Level: ${job.experience}
          Location: ${job.location}

          Candidate Profile:
          Name: ${candidate.name}
          Position: ${candidate.position}
          Skills: ${JSON.stringify(candidate.skills)}
          Experience: ${candidate.experience}
          Education: ${candidate.education}
          Location: ${candidate.location}

          Return only a JSON object with:
          - matchScore (number 0-100)
          - strengths (array of matching points)
          - gaps (array of missing requirements)
          - recommendation (brief recommendation text)
        `;

        const completion = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.3,
          max_tokens: 500
        });

        const matchResult = JSON.parse(completion.choices[0].message.content);

        matchedCandidates.push({
          candidate,
          ...matchResult
        });

        // Update or create application with match score
        const existingApplications = await Application.getByJobId(jobId);
        const existingApplication = existingApplications.find(app => app.candidate_id === candidate.id);

        if (existingApplication) {
          await Application.updateMatchScore(existingApplication.id, matchResult.matchScore);
        }
      } catch (error) {
        console.error(`Error matching candidate ${candidate.id}:`, error);
        // Continue with other candidates
      }
    }

    // Sort by match score
    matchedCandidates.sort((a, b) => b.matchScore - a.matchScore);

    res.json({
      success: true,
      message: 'Candidates matched successfully',
      matches: matchedCandidates.slice(0, 20) // Return top 20 matches
    });
  } catch (error) {
    console.error('Match candidates error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to match candidates'
    });
  }
};

export const generateOfferLetter = async (req, res) => {
  try {
    const { candidateId, jobId, offerDetails } = req.body;

    const candidate = await Candidate.findById(candidateId);
    const job = await Job.findById(jobId);

    if (!candidate || !job) {
      return res.status(404).json({
        success: false,
        message: 'Candidate or job not found'
      });
    }

    const prompt = `
      Generate a professional offer letter with the following details:

      Company: AI4Hr Technologies
      Candidate: ${candidate.name}
      Position: ${job.title}
      Department: ${job.department}
      Salary: ${offerDetails.salary || job.salary}
      Start Date: ${offerDetails.startDate}
      Benefits: ${JSON.stringify(job.benefits)}

      Include:
      - Professional greeting
      - Job details and responsibilities
      - Compensation and benefits
      - Start date and reporting structure
      - Next steps for acceptance
      - Professional closing

      Format as a formal business letter.
    `;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 1500
    });

    const offerLetter = completion.choices[0].message.content;

    res.json({
      success: true,
      message: 'Offer letter generated successfully',
      offerLetter
    });
  } catch (error) {
    console.error('Generate offer letter error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate offer letter'
    });
  }
};

export const getScreeningRecommendations = async (req, res) => {
  try {
    const { candidateId, jobId } = req.params;

    const candidate = await Candidate.findById(candidateId);
    const job = await Job.findById(jobId);

    if (!candidate || !job) {
      return res.status(404).json({
        success: false,
        message: 'Candidate or job not found'
      });
    }

    const prompt = `
      Provide screening recommendations for this candidate-job match:

      Job: ${job.title} at ${job.department}
      Requirements: ${JSON.stringify(job.requirements)}

      Candidate: ${candidate.name}
      Skills: ${JSON.stringify(candidate.skills)}
      Experience: ${candidate.experience}
      Summary: ${candidate.summary}

      Provide recommendations as JSON:
      - overallRecommendation (hire, interview, reject)
      - keyStrengths (array of candidate strengths)
      - concerns (array of potential concerns)
      - interviewQuestions (array of 5 relevant interview questions)
      - nextSteps (recommended next actions)
      - confidenceScore (0-100 confidence in recommendation)
    `;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.3,
      max_tokens: 1000
    });

    const recommendations = JSON.parse(completion.choices[0].message.content);

    res.json({
      success: true,
      message: 'Screening recommendations generated successfully',
      recommendations
    });
  } catch (error) {
    console.error('Get screening recommendations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate screening recommendations'
    });
  }
};