import Application from '../models/Application.js';
import Job from '../models/Job.js';
import Candidate from '../models/Candidate.js';
import { validateApplication } from '../utils/validation.js';

export const createApplication = async (req, res) => {
  try {
    const { error } = validateApplication(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const { candidateId, jobId } = req.body;

    // Verify job and candidate exist
    const job = await Job.findById(jobId);
    const candidate = await Candidate.findById(candidateId);

    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }

    if (!candidate) {
      return res.status(404).json({
        success: false,
        message: 'Candidate not found'
      });
    }

    // Check if application already exists
    const existingApplications = await Application.getByJobId(jobId);
    const existingApplication = existingApplications.find(app => app.candidate_id === candidateId);

    if (existingApplication) {
      return res.status(400).json({
        success: false,
        message: 'Candidate has already applied for this job'
      });
    }

    const application = await Application.create(req.body);

    res.status(201).json({
      success: true,
      message: 'Application created successfully',
      application
    });
  } catch (error) {
    console.error('Create application error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getApplicationById = async (req, res) => {
  try {
    const { id } = req.params;
    const application = await Application.findById(id);

    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found'
      });
    }

    res.json({
      success: true,
      application
    });
  } catch (error) {
    console.error('Get application by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const updateApplicationStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['new', 'screening', 'interview', 'offer', 'hired', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status'
      });
    }

    const application = await Application.findById(id);
    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found'
      });
    }

    const updatedApplication = await Application.updateStatus(id, status, req.user.userId);

    res.json({
      success: true,
      message: 'Application status updated successfully',
      application: updatedApplication
    });
  } catch (error) {
    console.error('Update application status error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const updateMatchScore = async (req, res) => {
  try {
    const { id } = req.params;
    const { matchScore } = req.body;

    if (typeof matchScore !== 'number' || matchScore < 0 || matchScore > 100) {
      return res.status(400).json({
        success: false,
        message: 'Match score must be a number between 0 and 100'
      });
    }

    const application = await Application.findById(id);
    if (!application) {
      return res.status(404).json({
        success: false,
        message: 'Application not found'
      });
    }

    const updatedApplication = await Application.updateMatchScore(id, matchScore);

    res.json({
      success: true,
      message: 'Match score updated successfully',
      application: updatedApplication
    });
  } catch (error) {
    console.error('Update match score error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getApplicationStats = async (req, res) => {
  try {
    const recruiterId = req.user.role === 'admin' ? null : req.user.userId;
    const stats = await Application.getStats(recruiterId);

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get application stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getRecentActivity = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const recruiterId = req.user.role === 'admin' ? null : req.user.userId;
    
    const activities = await Application.getRecentActivity(limit, recruiterId);

    res.json({
      success: true,
      activities
    });
  } catch (error) {
    console.error('Get recent activity error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};