import Job from '../models/Job.js';
import Application from '../models/Application.js';
import { validateJob } from '../utils/validation.js';

export const createJob = async (req, res) => {
  try {
    const { error } = validateJob(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }

    const jobData = {
      ...req.body,
      recruiterId: req.user.userId
    };

    const job = await Job.create(jobData);

    res.status(201).json({
      success: true,
      message: 'Job created successfully',
      job
    });
  } catch (error) {
    console.error('Create job error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getJobs = async (req, res) => {
  try {
    const filters = {};
    
    // If user is not admin, only show their jobs
    if (req.user.role !== 'admin') {
      filters.recruiterId = req.user.userId;
    }

    // Apply query filters
    if (req.query.status) filters.status = req.query.status;
    if (req.query.department) filters.department = req.query.department;
    if (req.query.search) filters.search = req.query.search;

    const jobs = await Job.getAll(filters);

    res.json({
      success: true,
      jobs
    });
  } catch (error) {
    console.error('Get jobs error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getJobById = async (req, res) => {
  try {
    const { id } = req.params;
    const job = await Job.findById(id);

    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }

    // Check if user has permission to view this job
    if (req.user.role !== 'admin' && job.recruiter_id !== req.user.userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    res.json({
      success: true,
      job
    });
  } catch (error) {
    console.error('Get job by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const updateJob = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if job exists and user has permission
    const existingJob = await Job.findById(id);
    if (!existingJob) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }

    if (req.user.role !== 'admin' && existingJob.recruiter_id !== req.user.userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const allowedFields = [
      'title', 'description', 'department', 'location', 'type', 'remote',
      'experience', 'salary', 'requirements', 'benefits', 'status'
    ];

    const updateData = {};
    allowedFields.forEach(field => {
      if (req.body[field] !== undefined) {
        updateData[field] = req.body[field];
      }
    });

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    const updatedJob = await Job.update(id, updateData);

    res.json({
      success: true,
      message: 'Job updated successfully',
      job: updatedJob
    });
  } catch (error) {
    console.error('Update job error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const deleteJob = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if job exists and user has permission
    const existingJob = await Job.findById(id);
    if (!existingJob) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }

    if (req.user.role !== 'admin' && existingJob.recruiter_id !== req.user.userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    await Job.delete(id);

    res.json({
      success: true,
      message: 'Job deleted successfully'
    });
  } catch (error) {
    console.error('Delete job error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getJobApplications = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Check if job exists and user has permission
    const job = await Job.findById(id);
    if (!job) {
      return res.status(404).json({
        success: false,
        message: 'Job not found'
      });
    }

    if (req.user.role !== 'admin' && job.recruiter_id !== req.user.userId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const filters = {};
    if (req.query.status) filters.status = req.query.status;
    if (req.query.minMatchScore) filters.minMatchScore = parseInt(req.query.minMatchScore);

    const applications = await Application.getByJobId(id, filters);

    res.json({
      success: true,
      applications
    });
  } catch (error) {
    console.error('Get job applications error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

export const getJobStats = async (req, res) => {
  try {
    const recruiterId = req.user.role === 'admin' ? null : req.user.userId;
    const stats = await Job.getStats(recruiterId);

    res.json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Get job stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};