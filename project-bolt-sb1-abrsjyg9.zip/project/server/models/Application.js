import pool from '../config/database.js';

class Application {
  static async create(applicationData) {
    const {
      candidateId,
      jobId,
      coverLetter,
      matchScore = 0,
      status = 'new'
    } = applicationData;

    const query = `
      INSERT INTO applications (
        candidate_id, job_id, cover_letter, match_score, status, applied_at, created_at, updated_at
      )
      VALUES ($1, $2, $3, $4, $5, NOW(), NOW(), NOW())
      RETURNING *
    `;

    const values = [candidateId, jobId, coverLetter, matchScore, status];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async findById(id) {
    const query = `
      SELECT a.*, c.name as candidate_name, c.email as candidate_email, c.phone as candidate_phone,
             c.location as candidate_location, c.position as candidate_position, c.skills as candidate_skills,
             c.resume_url, j.title as job_title, j.department as job_department
      FROM applications a
      JOIN candidates c ON a.candidate_id = c.id
      JOIN jobs j ON a.job_id = j.id
      WHERE a.id = $1
    `;
    
    const result = await pool.query(query, [id]);
    if (result.rows[0]) {
      const application = result.rows[0];
      application.candidate_skills = JSON.parse(application.candidate_skills || '[]');
    }
    return result.rows[0];
  }

  static async getByJobId(jobId, filters = {}) {
    let query = `
      SELECT a.*, c.name as candidate_name, c.email as candidate_email, c.phone as candidate_phone,
             c.location as candidate_location, c.position as candidate_position, c.skills as candidate_skills,
             c.experience as candidate_experience, c.education as candidate_education,
             c.summary as candidate_summary, c.resume_url, c.portfolio_url, c.linkedin_url, c.github_url
      FROM applications a
      JOIN candidates c ON a.candidate_id = c.id
      WHERE a.job_id = $1
    `;

    const values = [jobId];
    const conditions = [];

    if (filters.status) {
      conditions.push(`a.status = $${values.length + 1}`);
      values.push(filters.status);
    }

    if (filters.minMatchScore) {
      conditions.push(`a.match_score >= $${values.length + 1}`);
      values.push(filters.minMatchScore);
    }

    if (conditions.length > 0) {
      query += ' AND ' + conditions.join(' AND ');
    }

    query += ' ORDER BY a.match_score DESC, a.applied_at DESC';

    const result = await pool.query(query, values);
    return result.rows.map(application => {
      application.candidate_skills = JSON.parse(application.candidate_skills || '[]');
      return application;
    });
  }

  static async getByCandidateId(candidateId) {
    const query = `
      SELECT a.*, j.title as job_title, j.department as job_department, j.location as job_location,
             j.type as job_type, j.salary as job_salary
      FROM applications a
      JOIN jobs j ON a.job_id = j.id
      WHERE a.candidate_id = $1
      ORDER BY a.applied_at DESC
    `;

    const result = await pool.query(query, [candidateId]);
    return result.rows;
  }

  static async updateStatus(id, status, reviewedBy = null) {
    const query = `
      UPDATE applications 
      SET status = $1, reviewed_by = $2, reviewed_at = NOW(), updated_at = NOW()
      WHERE id = $3
      RETURNING *
    `;

    const result = await pool.query(query, [status, reviewedBy, id]);
    return result.rows[0];
  }

  static async updateMatchScore(id, matchScore) {
    const query = `
      UPDATE applications 
      SET match_score = $1, updated_at = NOW()
      WHERE id = $2
      RETURNING *
    `;

    const result = await pool.query(query, [matchScore, id]);
    return result.rows[0];
  }

  static async getStats(recruiterId = null) {
    let query = `
      SELECT 
        COUNT(*) as total_applications,
        COUNT(CASE WHEN a.status = 'new' THEN 1 END) as new_applications,
        COUNT(CASE WHEN a.status = 'screening' THEN 1 END) as screening_applications,
        COUNT(CASE WHEN a.status = 'interview' THEN 1 END) as interview_applications,
        COUNT(CASE WHEN a.status = 'offer' THEN 1 END) as offer_applications,
        COUNT(CASE WHEN a.status = 'hired' THEN 1 END) as hired_applications,
        COUNT(CASE WHEN a.status = 'rejected' THEN 1 END) as rejected_applications,
        AVG(a.match_score) as avg_match_score
      FROM applications a
    `;

    const values = [];
    if (recruiterId) {
      query += ' JOIN jobs j ON a.job_id = j.id WHERE j.recruiter_id = $1';
      values.push(recruiterId);
    }

    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async getRecentActivity(limit = 10, recruiterId = null) {
    let query = `
      SELECT a.*, c.name as candidate_name, j.title as job_title,
             u.first_name as reviewer_first_name, u.last_name as reviewer_last_name
      FROM applications a
      JOIN candidates c ON a.candidate_id = c.id
      JOIN jobs j ON a.job_id = j.id
      LEFT JOIN users u ON a.reviewed_by = u.id
    `;

    const values = [];
    if (recruiterId) {
      query += ' WHERE j.recruiter_id = $1';
      values.push(recruiterId);
    }

    query += ' ORDER BY a.updated_at DESC LIMIT $' + (values.length + 1);
    values.push(limit);

    const result = await pool.query(query, values);
    return result.rows;
  }
}

export default Application;