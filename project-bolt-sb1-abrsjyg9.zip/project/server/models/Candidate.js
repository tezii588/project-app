import pool from '../config/database.js';

class Candidate {
  static async create(candidateData) {
    const {
      name,
      email,
      phone,
      location,
      position,
      experience,
      education,
      skills,
      summary,
      resumeUrl,
      portfolioUrl,
      linkedinUrl,
      githubUrl,
      expectedSalary
    } = candidateData;

    const query = `
      INSERT INTO candidates (
        name, email, phone, location, position, experience, education,
        skills, summary, resume_url, portfolio_url, linkedin_url, github_url,
        expected_salary, created_at, updated_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW(), NOW())
      RETURNING *
    `;

    const values = [
      name, email, phone, location, position, experience, education,
      JSON.stringify(skills), summary, resumeUrl, portfolioUrl, linkedinUrl,
      githubUrl, expectedSalary
    ];

    const result = await pool.query(query, values);
    const candidate = result.rows[0];
    candidate.skills = JSON.parse(candidate.skills || '[]');
    return candidate;
  }

  static async findById(id) {
    const query = 'SELECT * FROM candidates WHERE id = $1';
    const result = await pool.query(query, [id]);
    if (result.rows[0]) {
      const candidate = result.rows[0];
      candidate.skills = JSON.parse(candidate.skills || '[]');
    }
    return result.rows[0];
  }

  static async findByEmail(email) {
    const query = 'SELECT * FROM candidates WHERE email = $1';
    const result = await pool.query(query, [email]);
    if (result.rows[0]) {
      const candidate = result.rows[0];
      candidate.skills = JSON.parse(candidate.skills || '[]');
    }
    return result.rows[0];
  }

  static async getAll(filters = {}) {
    let query = `
      SELECT c.*, 
             COALESCE(AVG(a.match_score), 0) as avg_match_score,
             COUNT(a.id) as application_count
      FROM candidates c
      LEFT JOIN applications a ON c.id = a.candidate_id
    `;

    const conditions = [];
    const values = [];

    if (filters.search) {
      conditions.push(`(c.name ILIKE $${values.length + 1} OR c.position ILIKE $${values.length + 1} OR c.email ILIKE $${values.length + 1})`);
      values.push(`%${filters.search}%`);
    }

    if (filters.location) {
      conditions.push(`c.location ILIKE $${values.length + 1}`);
      values.push(`%${filters.location}%`);
    }

    if (filters.experience) {
      conditions.push(`c.experience ILIKE $${values.length + 1}`);
      values.push(`%${filters.experience}%`);
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    query += ' GROUP BY c.id ORDER BY avg_match_score DESC, c.created_at DESC';

    const result = await pool.query(query, values);
    return result.rows.map(candidate => {
      candidate.skills = JSON.parse(candidate.skills || '[]');
      return candidate;
    });
  }

  static async update(id, updateData) {
    const fields = [];
    const values = [];
    let paramCount = 1;

    Object.keys(updateData).forEach(key => {
      if (updateData[key] !== undefined) {
        if (key === 'skills') {
          fields.push(`${key} = $${paramCount}`);
          values.push(JSON.stringify(updateData[key]));
        } else {
          fields.push(`${key} = $${paramCount}`);
          values.push(updateData[key]);
        }
        paramCount++;
      }
    });

    if (fields.length === 0) {
      throw new Error('No fields to update');
    }

    fields.push(`updated_at = NOW()`);
    values.push(id);

    const query = `
      UPDATE candidates 
      SET ${fields.join(', ')}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const result = await pool.query(query, values);
    if (result.rows[0]) {
      const candidate = result.rows[0];
      candidate.skills = JSON.parse(candidate.skills || '[]');
    }
    return result.rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM candidates WHERE id = $1 RETURNING id';
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async getStats() {
    const query = `
      SELECT 
        COUNT(*) as total_candidates,
        COUNT(CASE WHEN created_at >= NOW() - INTERVAL '30 days' THEN 1 END) as new_candidates_30d,
        COUNT(CASE WHEN created_at >= NOW() - INTERVAL '7 days' THEN 1 END) as new_candidates_7d
      FROM candidates
    `;

    const result = await pool.query(query);
    return result.rows[0];
  }
}

export default Candidate;