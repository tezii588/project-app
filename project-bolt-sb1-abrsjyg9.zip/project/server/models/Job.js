import pool from '../config/database.js';

class Job {
  static async create(jobData) {
    const {
      title,
      description,
      department,
      location,
      type,
      remote,
      experience,
      salary,
      requirements,
      benefits,
      recruiterId
    } = jobData;

    const query = `
      INSERT INTO jobs (
        title, description, department, location, type, remote, experience, 
        salary, requirements, benefits, recruiter_id, status, created_at, updated_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'active', NOW(), NOW())
      RETURNING *
    `;

    const values = [
      title, description, department, location, type, remote, experience,
      salary, JSON.stringify(requirements), JSON.stringify(benefits), recruiterId
    ];

    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async findById(id) {
    const query = `
      SELECT j.*, u.first_name, u.last_name, u.email as recruiter_email,
             COUNT(a.id) as application_count
      FROM jobs j
      LEFT JOIN users u ON j.recruiter_id = u.id
      LEFT JOIN applications a ON j.id = a.job_id
      WHERE j.id = $1
      GROUP BY j.id, u.first_name, u.last_name, u.email
    `;
    
    const result = await pool.query(query, [id]);
    if (result.rows[0]) {
      const job = result.rows[0];
      job.requirements = JSON.parse(job.requirements || '[]');
      job.benefits = JSON.parse(job.benefits || '[]');
    }
    return result.rows[0];
  }

  static async getAll(filters = {}) {
    let query = `
      SELECT j.*, u.first_name, u.last_name,
             COUNT(a.id) as application_count
      FROM jobs j
      LEFT JOIN users u ON j.recruiter_id = u.id
      LEFT JOIN applications a ON j.id = a.job_id
    `;

    const conditions = [];
    const values = [];

    if (filters.recruiterId) {
      conditions.push(`j.recruiter_id = $${values.length + 1}`);
      values.push(filters.recruiterId);
    }

    if (filters.status) {
      conditions.push(`j.status = $${values.length + 1}`);
      values.push(filters.status);
    }

    if (filters.department) {
      conditions.push(`j.department = $${values.length + 1}`);
      values.push(filters.department);
    }

    if (filters.search) {
      conditions.push(`(j.title ILIKE $${values.length + 1} OR j.description ILIKE $${values.length + 1})`);
      values.push(`%${filters.search}%`);
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    query += ' GROUP BY j.id, u.first_name, u.last_name ORDER BY j.created_at DESC';

    const result = await pool.query(query, values);
    return result.rows.map(job => {
      job.requirements = JSON.parse(job.requirements || '[]');
      job.benefits = JSON.parse(job.benefits || '[]');
      return job;
    });
  }

  static async update(id, updateData) {
    const fields = [];
    const values = [];
    let paramCount = 1;

    Object.keys(updateData).forEach(key => {
      if (updateData[key] !== undefined) {
        if (key === 'requirements' || key === 'benefits') {
          fields.push(`${key} = $${paramCount}`);
          values.push(JSON.stringify(updateData[key]));
        } else {
          fields.push(`${key} = $${paramCount}`);
          values.push(updateData[key]);
        }
        paramCount++;
      }
    });

    if (fields.length === 0) {
      throw new Error('No fields to update');
    }

    fields.push(`updated_at = NOW()`);
    values.push(id);

    const query = `
      UPDATE jobs 
      SET ${fields.join(', ')}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const result = await pool.query(query, values);
    if (result.rows[0]) {
      const job = result.rows[0];
      job.requirements = JSON.parse(job.requirements || '[]');
      job.benefits = JSON.parse(job.benefits || '[]');
    }
    return result.rows[0];
  }

  static async delete(id) {
    const query = 'DELETE FROM jobs WHERE id = $1 RETURNING id';
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async getStats(recruiterId = null) {
    let query = `
      SELECT 
        COUNT(*) as total_jobs,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_jobs,
        COUNT(CASE WHEN status = 'paused' THEN 1 END) as paused_jobs,
        COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed_jobs
      FROM jobs
    `;

    const values = [];
    if (recruiterId) {
      query += ' WHERE recruiter_id = $1';
      values.push(recruiterId);
    }

    const result = await pool.query(query, values);
    return result.rows[0];
  }
}

export default Job;