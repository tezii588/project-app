import express from 'express';
import {
  createJob,
  getJobs,
  getJobById,
  updateJob,
  deleteJob,
  getJobApplications,
  getJobStats
} from '../controllers/jobController.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Job CRUD operations
router.post('/', createJob);
router.get('/', getJobs);
router.get('/stats', getJobStats);
router.get('/:id', getJobById);
router.put('/:id', updateJob);
router.delete('/:id', deleteJob);

// Job applications
router.get('/:id/applications', getJobApplications);

export default router;