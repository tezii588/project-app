import React from 'react';
import { Users, Calendar, FileText, UserCheck } from 'lucide-react';

const RecentActivity = ({ activity }) => {
  const getIcon = (type) => {
    switch (type) {
      case 'application':
        return Users;
      case 'interview':
        return Calendar;
      case 'offer':
        return FileText;
      case 'hire':
        return UserCheck;
      default:
        return Users;
    }
  };

  const getColor = (type) => {
    switch (type) {
      case 'application':
        return 'bg-blue-100 text-blue-600';
      case 'interview':
        return 'bg-purple-100 text-purple-600';
      case 'offer':
        return 'bg-orange-100 text-orange-600';
      case 'hire':
        return 'bg-green-100 text-green-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const Icon = getIcon(activity.type);

  return (
    <div className="flex items-start space-x-3">
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getColor(activity.type)}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-gray-900">{activity.message}</p>
        <div className="flex items-center space-x-2 mt-1">
          <p className="text-xs text-gray-500">{activity.time}</p>
          {activity.candidate && (
            <>
              <span className="text-xs text-gray-300">•</span>
              <p className="text-xs text-gray-600">{activity.candidate}</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;