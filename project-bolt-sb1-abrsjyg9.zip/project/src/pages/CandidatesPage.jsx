import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Search,
  Filter,
  Star,
  MapPin,
  Calendar,
  Download,
  Eye,
  Mail,
  Phone,
  User,
  GraduationCap,
  Briefcase,
  Award,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout';

const CandidatesPage = () => {
  const [searchParams] = useSearchParams();
  const jobFilter = searchParams.get('job');
  
  const [candidates, setCandidates] = useState([
    {
      id: 1,
      name: 'John Smith',
      email: 'john.smith@email.com',
      phone: '+1 (555) 123-4567',
      location: 'San Francisco, CA',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      position: 'Senior React Developer',
      experience: '5 years',
      education: 'BS Computer Science',
      skills: ['React', 'TypeScript', 'Node.js', 'AWS'],
      matchScore: 95,
      status: 'new',
      appliedDate: '2024-01-15',
      salary: '$120,000',
      resumeUrl: '/resumes/john-smith.pdf',
      summary: 'Experienced full-stack developer with expertise in React and Node.js. Led multiple successful projects and mentored junior developers.',
      jobId: 1
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      email: 'sarah.johnson@email.com',
      phone: '+1 (555) 234-5678',
      location: 'New York, NY',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      position: 'Product Manager',
      experience: '4 years',
      education: 'MBA Business Administration',
      skills: ['Product Strategy', 'Agile', 'Data Analysis', 'Leadership'],
      matchScore: 88,
      status: 'screening',
      appliedDate: '2024-01-14',
      salary: '$130,000',
      resumeUrl: '/resumes/sarah-johnson.pdf',
      summary: 'Strategic product manager with proven track record of launching successful products and driving user growth.',
      jobId: 2
    },
    {
      id: 3,
      name: 'Michael Chen',
      email: 'michael.chen@email.com',
      phone: '+1 (555) 345-6789',
      location: 'Seattle, WA',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      position: 'UX Designer',
      experience: '3 years',
      education: 'BFA Design',
      skills: ['Figma', 'User Research', 'Prototyping', 'Design Systems'],
      matchScore: 82,
      status: 'interview',
      appliedDate: '2024-01-12',
      salary: '$95,000',
      resumeUrl: '/resumes/michael-chen.pdf',
      summary: 'Creative UX designer passionate about creating intuitive user experiences and design systems.',
      jobId: 3
    },
    {
      id: 4,
      name: 'Emily Rodriguez',
      email: 'emily.rodriguez@email.com',
      phone: '+1 (555) 456-7890',
      location: 'Austin, TX',
      avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      position: 'DevOps Engineer',
      experience: '6 years',
      education: 'MS Computer Science',
      skills: ['AWS', 'Kubernetes', 'Docker', 'Terraform'],
      matchScore: 91,
      status: 'offer',
      appliedDate: '2024-01-10',
      salary: '$125,000',
      resumeUrl: '/resumes/emily-rodriguez.pdf',
      summary: 'Experienced DevOps engineer specializing in cloud infrastructure and automation.',
      jobId: 4
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [experienceFilter, setExperienceFilter] = useState('all');
  const [sortBy, setSortBy] = useState('match-score');

  const filteredCandidates = candidates
    .filter(candidate => {
      const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           candidate.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           candidate.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesStatus = statusFilter === 'all' || candidate.status === statusFilter;
      const matchesExperience = experienceFilter === 'all' || candidate.experience.includes(experienceFilter);
      const matchesJob = !jobFilter || candidate.jobId.toString() === jobFilter;
      
      return matchesSearch && matchesStatus && matchesExperience && matchesJob;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'match-score':
          return b.matchScore - a.matchScore;
        case 'name':
          return a.name.localeCompare(b.name);
        case 'date':
          return new Date(b.appliedDate) - new Date(a.appliedDate);
        default:
          return 0;
      }
    });

  const getStatusColor = (status) => {
    switch (status) {
      case 'new':
        return 'bg-blue-100 text-blue-800';
      case 'screening':
        return 'bg-yellow-100 text-yellow-800';
      case 'interview':
        return 'bg-purple-100 text-purple-800';
      case 'offer':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getMatchScoreColor = (score) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-yellow-600';
    if (score >= 70) return 'text-orange-600';
    return 'text-red-600';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleStatusChange = (candidateId, newStatus) => {
    setCandidates(prev => prev.map(candidate => 
      candidate.id === candidateId 
        ? { ...candidate, status: newStatus }
        : candidate
    ));
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Candidates</h1>
            <p className="text-gray-600 mt-2">Review and manage candidate applications</p>
          </div>
          <div className="flex items-center space-x-3 mt-4 md:mt-0">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="match-score">Sort by Match Score</option>
              <option value="name">Sort by Name</option>
              <option value="date">Sort by Application Date</option>
            </select>
          </div>
        </div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100"
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search candidates by name, position, or skills..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-3 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">All Status</option>
                <option value="new">New</option>
                <option value="screening">Screening</option>
                <option value="interview">Interview</option>
                <option value="offer">Offer</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>

            {/* Experience Filter */}
            <div>
              <select
                value={experienceFilter}
                onChange={(e) => setExperienceFilter(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">All Experience</option>
                <option value="1">Entry Level (1-2 years)</option>
                <option value="3">Mid Level (3-5 years)</option>
                <option value="6">Senior Level (6+ years)</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Candidates Grid */}
        <div className="grid gap-6">
          {filteredCandidates.map((candidate, index) => (
            <motion.div
              key={candidate.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                {/* Candidate Info */}
                <div className="flex items-start space-x-4 flex-1">
                  <img
                    src={candidate.avatar}
                    alt={candidate.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-xl font-semibold text-gray-900">{candidate.name}</h3>
                      <span className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(candidate.status)}`}>
                        {candidate.status}
                      </span>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                        <span className={`text-sm font-semibold ${getMatchScoreColor(candidate.matchScore)}`}>
                          {candidate.matchScore}% match
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-lg text-gray-700 mb-2">{candidate.position}</p>
                    <p className="text-sm text-gray-600 mb-3">{candidate.summary}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
                      <div className="flex items-center text-gray-600">
                        <MapPin className="h-4 w-4 mr-2" />
                        <span className="text-sm">{candidate.location}</span>
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Briefcase className="h-4 w-4 mr-2" />
                        <span className="text-sm">{candidate.experience} experience</span>
                      </div>
                      <div className="flex items-center text-gray-600">
                        <GraduationCap className="h-4 w-4 mr-2" />
                        <span className="text-sm">{candidate.education}</span>
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span className="text-sm">Applied {formatDate(candidate.appliedDate)}</span>
                      </div>
                    </div>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-2">
                      {candidate.skills.map((skill, idx) => (
                        <span key={idx} className="px-3 py-1 bg-blue-50 text-blue-700 text-xs rounded-full">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col space-y-2 mt-4 lg:mt-0 lg:ml-6">
                  <div className="flex items-center space-x-2">
                    <Link
                      to={`/candidate/${candidate.id}`}
                      className="bg-blue-50 hover:bg-blue-100 text-blue-600 p-2 rounded-lg transition-colors duration-200"
                      title="View Profile"
                    >
                      <Eye className="h-4 w-4" />
                    </Link>
                    <a
                      href={`mailto:${candidate.email}`}
                      className="bg-green-50 hover:bg-green-100 text-green-600 p-2 rounded-lg transition-colors duration-200"
                      title="Send Email"
                    >
                      <Mail className="h-4 w-4" />
                    </a>
                    <a
                      href={candidate.resumeUrl}
                      download
                      className="bg-gray-50 hover:bg-gray-100 text-gray-600 p-2 rounded-lg transition-colors duration-200"
                      title="Download Resume"
                    >
                      <Download className="h-4 w-4" />
                    </a>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleStatusChange(candidate.id, 'interview')}
                      className="bg-purple-50 hover:bg-purple-100 text-purple-600 px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200"
                    >
                      Schedule Interview
                    </button>
                    <button
                      onClick={() => handleStatusChange(candidate.id, 'rejected')}
                      className="bg-red-50 hover:bg-red-100 text-red-600 p-2 rounded-lg transition-colors duration-200"
                    >
                      <XCircle className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredCandidates.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <User className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No candidates found</h3>
            <p className="text-gray-600">Try adjusting your search or filter criteria</p>
          </motion.div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default CandidatesPage;