import api from './api';

export const aiService = {
  // Parse resume and extract information
  parseResume: async (file) => {
    const formData = new FormData();
    formData.append('resume', file);
    
    try {
      const response = await api.post('/ai/parse-resume', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to parse resume');
    }
  },

  // Analyze job description
  analyzeJobDescription: async (jobDescription) => {
    try {
      const response = await api.post('/ai/analyze-jd', { jobDescription });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to analyze job description');
    }
  },

  // Match candidates to job
  matchCandidates: async (jobId) => {
    try {
      const response = await api.post(`/ai/match-candidates/${jobId}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to match candidates');
    }
  },

  // Generate offer letter
  generateOfferLetter: async (candidateId, jobId, offerDetails) => {
    try {
      const response = await api.post('/ai/generate-offer', {
        candidateId,
        jobId,
        offerDetails
      });
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to generate offer letter');
    }
  },

  // Get AI recommendations for candidate screening
  getScreeningRecommendations: async (candidateId, jobId) => {
    try {
      const response = await api.get(`/ai/screening-recommendations/${candidateId}/${jobId}`);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.message || 'Failed to get screening recommendations');
    }
  }
};